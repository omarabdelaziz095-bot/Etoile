import { StaffUser, StaffRole, StaffPermission } from '../types';

export const ALL_STAFF_PERMISSIONS: {
  id: StaffPermission;
  label: { ar: string; en: string };
  description: { ar: string; en: string };
  category: string;
}[] = [
  {
    id: 'orders',
    label: { ar: 'موجز الطلبات والفواتير', en: 'Orders Stream & Receipts' },
    description: {
      ar: 'استعراض وقبول وتحديث حالة الطلبات المباشرة وطباعة الفواتير الحرارية',
      en: 'View, accept, update live order statuses, and print thermal receipts',
    },
    category: 'operations',
  },
  {
    id: 'kitchen',
    label: { ar: 'شاشة المطبخ KDS', en: 'Kitchen Display (KDS)' },
    description: {
      ar: 'شاشة خاصة بمحطات الطهي والتحضير لمتابعة بونات الطلبات الجارية',
      en: 'Dedicated prep station screen for kitchen staff and chef timers',
    },
    category: 'operations',
  },
  {
    id: 'analytics',
    label: { ar: 'المبيعات والتقارير المالية', en: 'Sales & POS Analytics' },
    description: {
      ar: 'مراقبة الإيرادات، مبيعات الأصناف، الضرائب، والأداء اليومي',
      en: 'Monitor store revenue, item velocity, tax reports, and shift totals',
    },
    category: 'management',
  },
  {
    id: 'inventory',
    label: { ar: 'إدارة وتعديل المنيو', en: 'Menu Inventory' },
    description: {
      ar: 'تعديل أسعار المنتجات، فتح وإغلاق توفر الأصناف، وتحديث القائمة',
      en: 'Update item prices, toggle product availability, and manage catalog',
    },
    category: 'inventory',
  },
  {
    id: 'stock',
    label: { ar: 'إدارة المخزون والتوريدات', en: 'Stock & Warehouse Manager' },
    description: {
      ar: 'جرد الكميات، تسجيل حركات التوريد والتالف، وتنبيهات النواقص',
      en: 'Track stock quantities, log restock/waste, and low-stock alerts',
    },
    category: 'inventory',
  },
  {
    id: 'ai_studio',
    label: { ar: 'استوديو الحلو الذكي', en: 'AI Pastry Studio' },
    description: {
      ar: 'توليد وتصميم صور ومقترحات الحلويات باستخدام نماذج الذكاء الاصطناعي',
      en: 'Generate pastry concept designs and food showcase visuals via AI',
    },
    category: 'creative',
  },
  {
    id: 'users',
    label: { ar: 'إدارة المستخدمين والصلاحيات', en: 'Staff & Access Control' },
    description: {
      ar: 'إنشاء وتعديل حسابات الموظفين وتعيين رموز PIN والصلاحيات بدقة',
      en: 'Manage staff accounts, set 4-digit PINs, and grant granular access',
    },
    category: 'management',
  },
];

export const ROLE_PRESETS: Record<
  StaffRole,
  {
    title: { ar: string; en: string };
    defaultPermissions: StaffPermission[];
    color: string;
  }
> = {
  admin: {
    title: { ar: 'مدير عام الفرع', en: 'General Store Manager' },
    defaultPermissions: ['orders', 'kitchen', 'analytics', 'inventory', 'stock', 'ai_studio', 'users'],
    color: '#B4963C', // Gold
  },
  cashier: {
    title: { ar: 'كاشير الصالة والتيك أواي', en: 'Front Desk Cashier' },
    defaultPermissions: ['orders', 'kitchen'],
    color: '#0284c7', // Sky Blue
  },
  kitchen: {
    title: { ar: 'رئيس قسم الحلواني والمطبخ', en: 'Head Pastry & Kitchen Chef' },
    defaultPermissions: ['kitchen', 'orders'],
    color: '#ea580c', // Orange
  },
  stock_manager: {
    title: { ar: 'أمين المخازن والتوريدات', en: 'Inventory & Stock Controller' },
    defaultPermissions: ['stock', 'inventory'],
    color: '#16a34a', // Green
  },
  accountant: {
    title: { ar: 'مراقب مالي ومدقق حسابات', en: 'Financial Auditor & Accountant' },
    defaultPermissions: ['analytics', 'orders'],
    color: '#7c3aed', // Purple
  },
  custom: {
    title: { ar: 'صلاحيات مخصصة', en: 'Custom Assigned Role' },
    defaultPermissions: ['orders'],
    color: '#64748b', // Slate
  },
};

// Initial default staff users with varying access permissions
export const DEFAULT_STAFF_USERS: StaffUser[] = [
  {
    id: 'staff-admin-01',
    name: {
      ar: 'أحمد ممدوح',
      en: 'Ahmed Mamdouh',
    },
    pin: '9283', // Preserved primary PIN
    role: 'admin',
    roleTitle: {
      ar: 'مدير عام الفرع (صلاحية كاملة)',
      en: 'General Store Manager (Full Access)',
    },
    permissions: ['orders', 'kitchen', 'analytics', 'inventory', 'stock', 'ai_studio', 'users'],
    avatarColor: '#B4963C',
    phone: '01012345678',
    isActive: true,
    createdAt: 1700000000000,
  },
  {
    id: 'staff-cashier-02',
    name: {
      ar: 'سارة النجار',
      en: 'Sara El-Naggar',
    },
    pin: '1122',
    role: 'cashier',
    roleTitle: {
      ar: 'كاشير الصالة والتيك أواي',
      en: 'Front Desk Cashier',
    },
    permissions: ['orders', 'kitchen'],
    avatarColor: '#0284c7',
    phone: '01123456789',
    isActive: true,
    createdAt: 1700000001000,
  },
  {
    id: 'staff-kitchen-03',
    name: {
      ar: 'شيف مصطفى السيد',
      en: 'Chef Mostafa El-Sayed',
    },
    pin: '3344',
    role: 'kitchen',
    roleTitle: {
      ar: 'رئيس قسم الحلواني والشيفات',
      en: 'Head Pastry & Kitchen Chef',
    },
    permissions: ['kitchen', 'orders'],
    avatarColor: '#ea580c',
    phone: '01234567890',
    isActive: true,
    createdAt: 1700000002000,
  },
  {
    id: 'staff-stock-04',
    name: {
      ar: 'كريم فؤاد',
      en: 'Karim Fouad',
    },
    pin: '5566',
    role: 'stock_manager',
    roleTitle: {
      ar: 'أمين المخازن والتوريدات',
      en: 'Inventory & Stock Controller',
    },
    permissions: ['stock', 'inventory'],
    avatarColor: '#16a34a',
    phone: '01098765432',
    isActive: true,
    createdAt: 1700000003000,
  },
  {
    id: 'staff-audit-05',
    name: {
      ar: 'طارق حامد',
      en: 'Tarek Hamed',
    },
    pin: '7788',
    role: 'accountant',
    roleTitle: {
      ar: 'مراقب مالي ومدقق حسابات',
      en: 'Financial Auditor & Accountant',
    },
    permissions: ['analytics', 'orders'],
    avatarColor: '#7c3aed',
    phone: '01511223344',
    isActive: true,
    createdAt: 1700000004000,
  },
];

const STORAGE_KEY = 'etoile_staff_users_v1';
const CURRENT_USER_KEY = 'etoile_current_staff_user_v1';

export function getStaffUsers(): StaffUser[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      saveStaffUsers(DEFAULT_STAFF_USERS);
      return DEFAULT_STAFF_USERS;
    }
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed) && parsed.length > 0) {
      // Ensure primary admin with PIN 9283 is present
      const hasPrimaryAdmin = parsed.some((u: StaffUser) => u.pin === '9283');
      if (!hasPrimaryAdmin) {
        parsed.unshift(DEFAULT_STAFF_USERS[0]);
        saveStaffUsers(parsed);
      }
      return parsed;
    }
    return DEFAULT_STAFF_USERS;
  } catch {
    return DEFAULT_STAFF_USERS;
  }
}

export function saveStaffUsers(users: StaffUser[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(users));
  } catch (err) {
    console.error('Failed to save staff users to localStorage:', err);
  }
}

export function authenticateStaffPIN(pin: string): StaffUser | null {
  const users = getStaffUsers();
  const match = users.find((u) => u.isActive && u.pin.trim() === pin.trim());
  if (match) {
    const updatedUser = { ...match, lastLoginAt: Date.now() };
    updateStaffUser(match.id, { lastLoginAt: updatedUser.lastLoginAt });
    setCurrentStaffUser(updatedUser);
    return updatedUser;
  }
  return null;
}

export function getCurrentStaffUser(): StaffUser | null {
  try {
    const raw = sessionStorage.getItem(CURRENT_USER_KEY) || localStorage.getItem(CURRENT_USER_KEY);
    if (raw) {
      const user = JSON.parse(raw) as StaffUser;
      // Validate that user still exists in staff list
      const all = getStaffUsers();
      const current = all.find((u) => u.id === user.id && u.isActive);
      return current || all[0];
    }
    // Default to the first admin if none set
    const all = getStaffUsers();
    return all.find((u) => u.pin === '9283') || all[0] || null;
  } catch {
    return null;
  }
}

export function setCurrentStaffUser(user: StaffUser | null): void {
  try {
    if (user) {
      sessionStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
      localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user));
    } else {
      sessionStorage.removeItem(CURRENT_USER_KEY);
      localStorage.removeItem(CURRENT_USER_KEY);
    }
  } catch {}
}

export function createStaffUser(
  data: Omit<StaffUser, 'id' | 'createdAt'>
): { success: boolean; user?: StaffUser; error?: string } {
  const users = getStaffUsers();

  // Validate PIN length and numbers
  if (!/^\d{4}$/.test(data.pin)) {
    return { success: false, error: 'PIN code must be exactly 4 digits' };
  }

  // Check unique PIN
  if (users.some((u) => u.pin === data.pin)) {
    return { success: false, error: 'A staff member with this PIN code already exists' };
  }

  const newUser: StaffUser = {
    ...data,
    id: `staff-${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
    createdAt: Date.now(),
  };

  const updated = [...users, newUser];
  saveStaffUsers(updated);
  return { success: true, user: newUser };
}

export function updateStaffUser(
  id: string,
  updates: Partial<StaffUser>
): { success: boolean; user?: StaffUser; error?: string } {
  const users = getStaffUsers();
  const idx = users.findIndex((u) => u.id === id);
  if (idx === -1) {
    return { success: false, error: 'User not found' };
  }

  // If PIN is updated, check uniqueness
  if (updates.pin) {
    if (!/^\d{4}$/.test(updates.pin)) {
      return { success: false, error: 'PIN code must be exactly 4 digits' };
    }
    const duplicate = users.find((u) => u.id !== id && u.pin === updates.pin);
    if (duplicate) {
      return { success: false, error: 'A staff member with this PIN code already exists' };
    }
  }

  const updatedUser: StaffUser = {
    ...users[idx],
    ...updates,
  };

  users[idx] = updatedUser;
  saveStaffUsers(users);

  // If current logged-in user was updated, refresh storage
  const current = getCurrentStaffUser();
  if (current?.id === id) {
    setCurrentStaffUser(updatedUser);
  }

  return { success: true, user: updatedUser };
}

export function deleteStaffUser(id: string): { success: boolean; error?: string } {
  const users = getStaffUsers();
  const target = users.find((u) => u.id === id);
  if (!target) {
    return { success: false, error: 'User not found' };
  }

  // Guard: Cannot delete primary admin (PIN 9283) or the only user
  if (target.pin === '9283') {
    return { success: false, error: 'Primary Branch Admin (PIN 9283) cannot be deleted' };
  }

  if (users.length <= 1) {
    return { success: false, error: 'Cannot delete the last remaining staff account' };
  }

  const filtered = users.filter((u) => u.id !== id);
  saveStaffUsers(filtered);

  // If deleted user was currently active, switch to first admin
  const current = getCurrentStaffUser();
  if (current?.id === id) {
    setCurrentStaffUser(filtered[0]);
  }

  return { success: true };
}

export function resetDefaultStaffUsers(): StaffUser[] {
  saveStaffUsers(DEFAULT_STAFF_USERS);
  setCurrentStaffUser(DEFAULT_STAFF_USERS[0]);
  return DEFAULT_STAFF_USERS;
}

export function hasPermission(user: StaffUser | null, permission: StaffPermission): boolean {
  if (!user || !user.isActive) return false;
  // Admin role automatically has all permissions
  if (user.role === 'admin') return true;
  return user.permissions.includes(permission);
}
