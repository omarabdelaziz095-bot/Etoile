import { initializeApp, getApps, getApp, FirebaseApp } from 'firebase/app';
import { getAnalytics, isSupported } from 'firebase/analytics';
import { getDatabase, ref, set, update, onValue, Database, DataSnapshot } from 'firebase/database';
import { Order, MenuItem, OrderStatus } from '../types';
import { INITIAL_MENU_ITEMS } from '../data/etoileMenuData';

export const FIREBASE_CONFIG = {
  apiKey: 'AIzaSyCtoFnJAibXS9YmJOjLC4VDz3illbnHo8I',
  authDomain: 'resto-ad.firebaseapp.com',
  databaseURL: 'https://resto-ad-default-rtdb.firebaseio.com',
  projectId: 'resto-ad',
  storageBucket: 'resto-ad.firebasestorage.app',
  messagingSenderId: '933835354701',
  appId: '1:933835354701:web:c69826c0e65009a8166204',
  measurementId: 'G-4HEYK8TJEY',
};

// Initialize Firebase App singleton safely
let app: FirebaseApp;
let database: Database | null = null;
let isConnected = false;

try {
  app = getApps().length > 0 ? getApp() : initializeApp(FIREBASE_CONFIG);
  database = getDatabase(app);
  
  // Initialize Google Analytics safely if supported in the current environment
  if (typeof window !== 'undefined') {
    isSupported()
      .then((supported) => {
        if (supported) {
          getAnalytics(app);
        }
      })
      .catch(() => {
        // Analytics unsupported or blocked (e.g. adblocker/iframe), ignore silently
      });
  }
} catch (e) {
  console.warn('Firebase initialization error, fallback active:', e);
}

const LOCAL_STORAGE_ORDERS_KEY = 'etoile_orders_v1';
const LOCAL_STORAGE_LAST_INVOICE_KEY = 'etoile_last_invoice_v1';
const LOCAL_STORAGE_MENU_KEY = 'etoile_menu_inventory_v1';

// Seed initial orders if empty in local store for demo & testing
function getLocalOrders(): Order[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_ORDERS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    console.error('Local storage read error:', e);
  }
  return [];
}

function saveLocalOrders(orders: Order[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_ORDERS_KEY, JSON.stringify(orders));
  } catch (e) {
    console.error('Local storage save error:', e);
  }
}

// Generate sequential 4-digit invoice number starting from #1001
export async function getNextInvoiceNumber(): Promise<{ invoiceNumber: string; sequence: number }> {
  let nextSeq = 1001;

  try {
    const storedSeq = localStorage.getItem(LOCAL_STORAGE_LAST_INVOICE_KEY);
    if (storedSeq) {
      nextSeq = Math.max(1001, parseInt(storedSeq, 10) + 1);
    }

    // Try fetching latest sequence from Firebase REST or DB
    if (database) {
      try {
        const res = await fetch(`${FIREBASE_CONFIG.databaseURL}/metadata/lastSequence.json`);
        if (res.ok) {
          const remoteSeq = await res.json();
          if (typeof remoteSeq === 'number' && remoteSeq >= 1000) {
            nextSeq = Math.max(nextSeq, remoteSeq + 1);
          }
        }
      } catch (err) {
        // Quiet fallback
      }
    }
  } catch (e) {
    console.warn('Error reading invoice sequence, continuing with local:', e);
  }

  // Update last sequence
  try {
    localStorage.setItem(LOCAL_STORAGE_LAST_INVOICE_KEY, nextSeq.toString());
    if (database) {
      fetch(`${FIREBASE_CONFIG.databaseURL}/metadata/lastSequence.json`, {
        method: 'PUT',
        body: JSON.stringify(nextSeq),
      }).catch(() => {});
    }
  } catch (e) {}

  return {
    sequence: nextSeq,
    invoiceNumber: `#${nextSeq}`,
  };
}

export interface CashierSignal {
  id: string;
  type: 'new_order' | 'call_waiter' | 'kitchen_ready' | 'order_updated' | 'stock_alert';
  orderId?: string;
  invoiceNumber?: string;
  tableNumber?: string;
  message: string;
  timestamp: number;
}

// Global broadcast channel for instant zero-latency cross-tab signals
let posBroadcastChannel: BroadcastChannel | null = null;
try {
  if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
    posBroadcastChannel = new BroadcastChannel('etoile_pos_signals_v1');
  }
} catch (e) {}

/**
 * Normalizes any incoming order payload from Firebase RTDB (including legacy/external schemas)
 * so that all POS panels, thermal receipts, and kitchen slips format flawlessly.
 */
export function normalizeOrder(raw: any): Order {
  if (!raw || typeof raw !== 'object') {
    return {
      id: `ord_${Date.now()}`,
      invoiceNumber: '#1000',
      sequenceNumber: 1000,
      diningMode: 'dine_in',
      items: [],
      subtotal: 0,
      tax: 0,
      total: 0,
      status: 'completed',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };
  }

  // Detect ID
  const id = String(raw.id || `ord_${raw.t || Date.now()}`);

  // Detect invoice number (supports: raw.no, raw.invoiceNumber, raw.num)
  let invoiceNumber = raw.invoiceNumber;
  if (!invoiceNumber && raw.no) {
    invoiceNumber = String(raw.no).startsWith('#') ? String(raw.no) : `#${raw.no}`;
  }
  if (!invoiceNumber) {
    invoiceNumber = `#${id.slice(-4)}`;
  }

  const sequenceNumber =
    raw.sequenceNumber || parseInt(invoiceNumber.replace(/\D/g, '') || '1001', 10);

  // Status mapping:
  // Compact RTDB schema: 1 -> 'new', 2 -> 'preparing', 3 -> 'completed', 4 -> 'cancelled'
  let status: OrderStatus = 'new';
  if (raw.status === 'new' || raw.status === 'preparing' || raw.status === 'completed' || raw.status === 'cancelled') {
    status = raw.status;
  } else if (raw.s === 1 || raw.s === '1') {
    status = 'new';
  } else if (raw.s === 2 || raw.s === '2') {
    status = 'preparing';
  } else if (raw.s === 3 || raw.s === '3') {
    status = 'completed';
  } else if (raw.s === 4 || raw.s === '4') {
    status = 'cancelled';
  }

  // Dining Mode: 'dine' -> 'dine_in', 'take' -> 'takeaway'
  let diningMode: 'dine_in' | 'takeaway' = 'dine_in';
  if (raw.diningMode === 'dine_in' || raw.diningMode === 'takeaway') {
    diningMode = raw.diningMode;
  } else if (raw.type === 'dine' || raw.type === 'dine_in') {
    diningMode = 'dine_in';
  } else if (raw.type === 'take' || raw.type === 'takeaway' || raw.type === 'delivery') {
    diningMode = 'takeaway';
  }

  // Items array normalization (supports { n, o, p, q } as well as standard fields)
  let items: import('../types').OrderLineItem[] = [];
  if (Array.isArray(raw.items)) {
    items = raw.items.map((it: any, index: number) => {
      const quantity = Math.max(1, Number(it.q ?? it.quantity ?? 1));
      const unitPrice = Number(it.p ?? it.unitPrice ?? 0);
      const totalPrice = Number(it.totalPrice ?? quantity * unitPrice);
      const nameStr =
        it.n ||
        (typeof it.title === 'string'
          ? it.title
          : it.title?.ar || it.title?.en || `صنف #${index + 1}`);
      const selectedSize = it.o || it.selectedSize || undefined;

      return {
        itemId: String(it.itemId || it.id || `item_${index}`),
        title:
          typeof it.title === 'object' && it.title?.ar
            ? it.title
            : { ar: nameStr, en: nameStr },
        quantity,
        unitPrice,
        totalPrice,
        selectedSize: selectedSize || undefined,
        notes: it.notes || it.note || undefined,
      };
    });
  }

  const total = Number(raw.total ?? items.reduce((sum, it) => sum + it.totalPrice, 0));
  const subtotal = Number(raw.subtotal ?? Math.round(total / 1.14));
  const tax = Number(raw.tax ?? (total - subtotal));

  const createdAt = Number(raw.createdAt || raw.t || Date.now());
  const updatedAt = Number(raw.updatedAt || raw.t || createdAt);

  return {
    id,
    invoiceNumber,
    sequenceNumber,
    diningMode,
    tableNumber: raw.tableNumber || raw.table || undefined,
    customerName: raw.customerName || raw.name || undefined,
    customerPhone: raw.customerPhone || raw.phone || undefined,
    specialNotes: raw.specialNotes || raw.note || undefined,
    items,
    subtotal,
    tax,
    total,
    status,
    createdAt,
    updatedAt,
  };
}

/**
 * Broadcasts an instant signal via Firebase RTDB onValue + BroadcastChannel
 */
export async function sendCashierSignal(
  signalData: Omit<CashierSignal, 'id' | 'timestamp'>
): Promise<CashierSignal> {
  const signal: CashierSignal = {
    ...signalData,
    id: `sig_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: Date.now(),
  };

  // 1. Post to local BroadcastChannel for instant 0ms tab-to-tab detection
  try {
    if (posBroadcastChannel) {
      posBroadcastChannel.postMessage(signal);
    }
  } catch (e) {}

  // 2. Write to Firebase RTDB for instant cross-device detection via onValue
  if (database) {
    try {
      const signalRef = ref(database, 'signals/latest');
      await set(signalRef, signal);
    } catch (e) {
      // Quiet REST fallback
      fetch(`${FIREBASE_CONFIG.databaseURL}/signals/latest.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(signal),
      }).catch(() => {});
    }
  } else {
    fetch(`${FIREBASE_CONFIG.databaseURL}/signals/latest.json`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(signal),
    }).catch(() => {});
  }

  return signal;
}

/**
 * Subscribes in real-time to instant signals via Firebase RTDB onValue
 */
export function subscribeToSignals(callback: (signal: CashierSignal) => void): () => void {
  let unsubscribeFirebase: (() => void) | null = null;

  // 1. Firebase RTDB real-time onValue listener
  if (database) {
    try {
      const signalRef = ref(database, 'signals/latest');
      unsubscribeFirebase = onValue(signalRef, (snapshot) => {
        if (snapshot.exists()) {
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            callback(val as CashierSignal);
          }
        }
      });
    } catch (e) {
      console.warn('Could not attach signal onValue listener:', e);
    }
  }

  // 2. BroadcastChannel listener for local instantaneous multi-tab triggers
  const handleBroadcast = (evt: MessageEvent) => {
    if (evt.data && evt.data.type) {
      callback(evt.data as CashierSignal);
    }
  };

  if (posBroadcastChannel) {
    posBroadcastChannel.addEventListener('message', handleBroadcast);
  }

  return () => {
    if (unsubscribeFirebase) unsubscribeFirebase();
    if (posBroadcastChannel) {
      posBroadcastChannel.removeEventListener('message', handleBroadcast);
    }
  };
}

// Submit a new customer order to Firebase RTDB & local storage with instant signal
export async function submitOrder(
  orderData: Omit<
    Order,
    'id' | 'invoiceNumber' | 'sequenceNumber' | 'createdAt' | 'updatedAt' | 'status'
  >
): Promise<Order> {
  const { sequence, invoiceNumber } = await getNextInvoiceNumber();
  const orderId = `ord_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const now = Date.now();

  const newOrder: Order = {
    ...orderData,
    id: orderId,
    invoiceNumber,
    sequenceNumber: sequence,
    status: 'new',
    createdAt: now,
    updatedAt: now,
  };

  // Compatible dual-schema payload for universal POS & printer support
  const rtdbPayload = {
    ...newOrder,
    no: invoiceNumber.replace('#', ''),
    s: 1, // 1 = new
    t: now,
    table: newOrder.tableNumber || '',
    type: newOrder.diningMode === 'dine_in' ? 'dine' : 'takeaway',
    name: newOrder.customerName || '',
    phone: newOrder.customerPhone || '',
    note: newOrder.specialNotes || '',
    items: newOrder.items.map((it) => ({
      ...it,
      n: it.title.ar || it.title.en,
      o: it.selectedSize || '',
      p: it.unitPrice,
      q: it.quantity,
    })),
  };

  // 1. Save in local storage
  const currentOrders = getLocalOrders();
  saveLocalOrders([newOrder, ...currentOrders]);

  // 2. Sync to local backend Express REST & SSE stream for instant cross-device delivery
  try {
    fetch('/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newOrder),
    }).catch(() => {});
  } catch (e) {}

  // 3. Dispatch in-window and cross-tab events for instantaneous (0ms) zero-refresh updates
  try {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('etoile_order_event', { detail: { type: 'new_order', order: newOrder } })
      );
    }
    if (posBroadcastChannel) {
      posBroadcastChannel.postMessage({ type: 'new_order', order: newOrder });
    }
  } catch (e) {}

  // 4. Sync to Firebase Realtime Database
  if (database) {
    try {
      const orderRef = ref(database, `orders/${orderId}`);
      await set(orderRef, rtdbPayload);
    } catch (firebaseErr) {
      try {
        await fetch(`${FIREBASE_CONFIG.databaseURL}/orders/${orderId}.json`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(rtdbPayload),
        });
      } catch (restErr) {}
    }
  } else {
    try {
      await fetch(`${FIREBASE_CONFIG.databaseURL}/orders/${orderId}.json`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(rtdbPayload),
      });
    } catch (e) {}
  }

  // 5. Emit instant signal
  sendCashierSignal({
    type: 'new_order',
    orderId: newOrder.id,
    invoiceNumber: newOrder.invoiceNumber,
    tableNumber: newOrder.tableNumber,
    message: `طلب جديد: ${newOrder.invoiceNumber}`,
  }).catch(() => {});

  return newOrder;
}

// Update order status: 'new' -> 'preparing' -> 'completed' -> 'cancelled'
export async function updateOrderStatus(orderId: string, status: OrderStatus): Promise<void> {
  const now = Date.now();
  const s = status === 'new' ? 1 : status === 'preparing' ? 2 : status === 'completed' ? 3 : 4;

  // 1. Update local
  const currentOrders = getLocalOrders();
  const updatedOrders = currentOrders.map((o) =>
    o.id === orderId ? { ...o, status, updatedAt: now } : o
  );
  saveLocalOrders(updatedOrders);

  // 2. Sync to local backend Express REST & SSE stream
  try {
    fetch(`/api/orders/${orderId}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status, s }),
    }).catch(() => {});
  } catch (e) {}

  // 3. Dispatch in-window and cross-tab events for instantaneous zero-refresh updates
  try {
    if (typeof window !== 'undefined') {
      window.dispatchEvent(
        new CustomEvent('etoile_order_event', {
          detail: { type: 'order_updated', orderId, status },
        })
      );
    }
    if (posBroadcastChannel) {
      posBroadcastChannel.postMessage({ type: 'order_updated', orderId, status });
    }
  } catch (e) {}

  // 4. Update Firebase
  const updates = { status, s, updatedAt: now };
  if (database) {
    try {
      const orderRef = ref(database, `orders/${orderId}`);
      await update(orderRef, updates);
    } catch (e) {
      try {
        await fetch(`${FIREBASE_CONFIG.databaseURL}/orders/${orderId}.json`, {
          method: 'PATCH',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(updates),
        });
      } catch (restErr) {}
    }
  }

  // 5. Emit instant signal
  sendCashierSignal({
    type: 'order_updated',
    orderId,
    message: `تحديث الفاتورة: ${status}`,
  }).catch(() => {});
}

// Real-time Order Stream Listener for Cashier POS
// Combines SSE, Firebase RTDB onValue, BroadcastChannel, and in-window events
// to guarantee 100% instant detection with ZERO page refresh required.
export function subscribeToOrders(
  callback: (orders: Order[], isConnected: boolean) => void
): () => void {
  let unsubscribeFirebaseOrders: (() => void) | null = null;
  let unsubscribeFirebaseConn: (() => void) | null = null;
  let eventSource: EventSource | null = null;
  let intervalId: any = null;

  const notifyOrders = (remoteOrders?: any[]) => {
    const local = getLocalOrders();
    const mapById = new Map<string, Order>();

    // Start with local
    local.forEach((o) => mapById.set(o.id, o));

    // Merge remote normalized orders
    if (remoteOrders && Array.isArray(remoteOrders)) {
      remoteOrders.forEach((raw) => {
        const norm = normalizeOrder(raw);
        mapById.set(norm.id, norm);
      });
    }

    const merged = Array.from(mapById.values()).sort((a, b) => b.createdAt - a.createdAt);
    saveLocalOrders(merged);
    callback(merged, true);
  };

  const handleData = (ordersMap: Record<string, any> | null) => {
    let rawList: any[] = [];
    if (ordersMap && typeof ordersMap === 'object') {
      rawList = Object.values(ordersMap);
    }
    notifyOrders(rawList);
  };

  // 1. Instant Real-time Server-Sent Events (SSE) Stream from Express Backend
  try {
    if (typeof window !== 'undefined' && typeof EventSource !== 'undefined') {
      eventSource = new EventSource('/api/orders/stream');

      eventSource.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          if (data.type === 'initial' || data.type === 'orders') {
            notifyOrders(data.orders || []);
          } else if (data.type === 'new_order' || data.type === 'order_updated') {
            if (data.orders) {
              notifyOrders(data.orders);
            } else if (data.order) {
              notifyOrders([data.order]);
            }
          }
        } catch (e) {}
      };

      eventSource.onerror = () => {
        // SSE transient error, will auto-reconnect
      };
    }
  } catch (e) {}

  // 2. Firebase RTDB real-time onValue listener on orders node
  if (database) {
    try {
      const ordersRef = ref(database, 'orders');
      unsubscribeFirebaseOrders = onValue(
        ordersRef,
        (snapshot: DataSnapshot) => {
          isConnected = true;
          const val = snapshot.val();
          handleData(val);
        },
        (error) => {
          console.warn('Firebase orders onValue fallback active:', error);
          isConnected = false;
          notifyOrders();
        }
      );

      // Listen to connection state
      const connRef = ref(database, '.info/connected');
      unsubscribeFirebaseConn = onValue(connRef, (snap) => {
        const isOnline = snap.val() === true;
        isConnected = isOnline;
      });
    } catch (e) {
      console.warn('Failed to attach Firebase listener:', e);
    }
  }

  // 3. In-window custom event listener (instant 0ms detection within same browser window)
  const handleWindowOrderEvent = (evt: Event) => {
    const custom = evt as CustomEvent;
    if (custom.detail?.order) {
      notifyOrders([custom.detail.order]);
    } else {
      notifyOrders();
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('etoile_order_event', handleWindowOrderEvent);
  }

  // 4. Cross-tab BroadcastChannel listener (instant 0ms detection across tabs)
  const handleBroadcastMessage = (evt: MessageEvent) => {
    if (evt.data?.order) {
      notifyOrders([evt.data.order]);
    } else {
      notifyOrders();
    }
  };

  if (posBroadcastChannel) {
    posBroadcastChannel.addEventListener('message', handleBroadcastMessage);
  }

  // 5. Browser storage event for cross-tab legacy support
  const handleStorageChange = (e: StorageEvent) => {
    if (e.key === LOCAL_STORAGE_ORDERS_KEY) {
      notifyOrders();
    }
  };

  if (typeof window !== 'undefined') {
    window.addEventListener('storage', handleStorageChange);
  }

  // 6. Fast background poll every 2.5 seconds to ensure orders never stall
  const pollBackend = async () => {
    try {
      const res = await fetch('/api/orders');
      if (res.ok) {
        const data = await res.json();
        if (data.orders) {
          notifyOrders(data.orders);
        }
      }
    } catch (e) {
      notifyOrders();
    }
  };

  // Immediate local call
  notifyOrders();

  // Poll fallback
  intervalId = setInterval(pollBackend, 2500);

  return () => {
    if (eventSource) eventSource.close();
    if (unsubscribeFirebaseOrders) unsubscribeFirebaseOrders();
    if (unsubscribeFirebaseConn) unsubscribeFirebaseConn();
    if (intervalId) clearInterval(intervalId);
    if (typeof window !== 'undefined') {
      window.removeEventListener('etoile_order_event', handleWindowOrderEvent);
      window.removeEventListener('storage', handleStorageChange);
    }
    if (posBroadcastChannel) {
      posBroadcastChannel.removeEventListener('message', handleBroadcastMessage);
    }
  };
}

// Real-time Menu Inventory Listener via Firebase RTDB onValue
export function subscribeToMenu(
  callback: (items: MenuItem[]) => void
): () => void {
  let unsubscribeFirebaseMenu: (() => void) | null = null;

  if (database) {
    try {
      const menuRef = ref(database, 'menu');
      unsubscribeFirebaseMenu = onValue(menuRef, (snapshot) => {
        if (snapshot.exists()) {
          const val = snapshot.val();
          if (val && typeof val === 'object') {
            const currentMenu = getStoredMenu();
            const updated = currentMenu.map((item) => {
              const remote = val[item.id];
              if (remote) {
                return { ...item, ...remote };
              }
              return item;
            });
            saveStoredMenu(updated);
            callback(updated);
          }
        }
      });
    } catch (e) {}
  }

  return () => {
    if (unsubscribeFirebaseMenu) unsubscribeFirebaseMenu();
  };
}

const LOCAL_STORAGE_STOCK_LOGS_KEY = 'etoile_stock_logs_v1';

// Provide initial realistic stock amounts for demo items
function getDefaultInitialStock(id: string, index: number): { stockQuantity: number; lowStockThreshold: number; trackStock: boolean } {
  // Give a few items low stock or 0 to showcase stock alerts
  if (id === 'disc-02' || id === 'sav-02') {
    return { stockQuantity: 2, lowStockThreshold: 5, trackStock: true };
  }
  if (id === 'ice-03') {
    return { stockQuantity: 0, lowStockThreshold: 5, trackStock: true };
  }
  if (id === 'ori-03') {
    return { stockQuantity: 4, lowStockThreshold: 5, trackStock: true };
  }
  const qty = 15 + ((index * 7) % 25);
  return {
    stockQuantity: qty,
    lowStockThreshold: 5,
    trackStock: true,
  };
}

// Menu Items Real-time inventory sync
export function getStoredMenu(): MenuItem[] {
  let items: MenuItem[] = INITIAL_MENU_ITEMS;
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_MENU_KEY);
    if (raw) {
      items = JSON.parse(raw);
    }
  } catch (e) {}

  // Normalize items to ensure stock properties exist
  const normalized = items.map((item, idx) => {
    const defaults = getDefaultInitialStock(item.id, idx);
    const stockQuantity = item.stockQuantity !== undefined ? item.stockQuantity : defaults.stockQuantity;
    const lowStockThreshold = item.lowStockThreshold !== undefined ? item.lowStockThreshold : defaults.lowStockThreshold;
    const trackStock = item.trackStock !== undefined ? item.trackStock : defaults.trackStock;
    const stockUnit = item.stockUnit || (item.category === 'oriental' ? 'علبة' : item.category === 'ice_cream' ? 'عبوة' : 'قطعة');

    return {
      ...item,
      trackStock,
      stockQuantity,
      lowStockThreshold,
      stockUnit,
    };
  });

  return normalized;
}

export function saveStoredMenu(items: MenuItem[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_MENU_KEY, JSON.stringify(items));
  } catch (e) {}
}

export async function toggleMenuItemAvailability(itemId: string, available: boolean): Promise<MenuItem[]> {
  const current = getStoredMenu();
  const updated = current.map(item => item.id === itemId ? { ...item, available } : item);
  saveStoredMenu(updated);

  if (database) {
    try {
      const itemRef = ref(database, `menu/${itemId}`);
      await update(itemRef, { available });
    } catch (e) {}
  }
  return updated;
}

export async function updateMenuItemDetails(itemId: string, updates: Partial<MenuItem>): Promise<MenuItem[]> {
  const current = getStoredMenu();
  const updated = current.map(item => item.id === itemId ? { ...item, ...updates } : item);
  saveStoredMenu(updated);

  if (database) {
    try {
      const itemRef = ref(database, `menu/${itemId}`);
      await update(itemRef, updates);
    } catch (e) {}
  }
  return updated;
}

export async function addCustomMenuItem(newItem: MenuItem): Promise<MenuItem[]> {
  const current = getStoredMenu();
  const normalizedNewItem: MenuItem = {
    ...newItem,
    trackStock: newItem.trackStock ?? true,
    stockQuantity: newItem.stockQuantity ?? 20,
    lowStockThreshold: newItem.lowStockThreshold ?? 5,
    stockUnit: newItem.stockUnit || 'قطعة',
  };
  const updated = [normalizedNewItem, ...current];
  saveStoredMenu(updated);

  if (database) {
    try {
      const itemRef = ref(database, `menu/${newItem.id}`);
      await set(itemRef, normalizedNewItem);
    } catch (e) {}
  }
  return updated;
}

// ------------------------------------------------------------------
// STOCK / INVENTORY MANAGEMENT FUNCTIONS
// ------------------------------------------------------------------

export function getStockAdjustmentLogs(): import('../types').StockAdjustmentLog[] {
  try {
    const raw = localStorage.getItem(LOCAL_STORAGE_STOCK_LOGS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return [];
}

export function saveStockAdjustmentLogs(logs: import('../types').StockAdjustmentLog[]): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_STOCK_LOGS_KEY, JSON.stringify(logs.slice(0, 200)));
  } catch (e) {}
}

export function recordStockLog(log: Omit<import('../types').StockAdjustmentLog, 'id' | 'timestamp'>): void {
  const currentLogs = getStockAdjustmentLogs();
  const newLog: import('../types').StockAdjustmentLog = {
    ...log,
    id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
    timestamp: Date.now(),
  };
  saveStockAdjustmentLogs([newLog, ...currentLogs]);
}

/**
 * Updates stock quantity for a specific menu item, syncs with RTDB and logs adjustment
 */
export async function updateItemStock(
  itemId: string,
  newStock: number,
  reason: import('../types').StockAdjustmentReason = 'manual_adjustment',
  note?: string
): Promise<MenuItem[]> {
  const current = getStoredMenu();
  const target = current.find((i) => i.id === itemId);
  if (!target) return current;

  const validNewStock = Math.max(0, Math.floor(newStock));
  const previousStock = target.stockQuantity ?? 0;
  const delta = validNewStock - previousStock;

  // Auto toggle availability if stock drops to 0 or rises from 0
  let newAvailable = target.available;
  if (validNewStock === 0 && target.trackStock) {
    newAvailable = false;
  } else if (validNewStock > 0 && !target.available && target.trackStock) {
    newAvailable = true;
  }

  const updated = current.map((item) =>
    item.id === itemId
      ? {
          ...item,
          stockQuantity: validNewStock,
          available: newAvailable,
          lastRestockedAt: delta > 0 ? Date.now() : item.lastRestockedAt,
        }
      : item
  );

  saveStoredMenu(updated);

  if (delta !== 0) {
    recordStockLog({
      itemId,
      itemTitle: target.title,
      delta,
      previousStock,
      newStock: validNewStock,
      reason,
      note,
    });
  }

  if (database) {
    try {
      const itemRef = ref(database, `menu/${itemId}`);
      await update(itemRef, {
        stockQuantity: validNewStock,
        available: newAvailable,
        lastRestockedAt: delta > 0 ? Date.now() : target.lastRestockedAt ?? null,
      });
    } catch (e) {}
  }

  return updated;
}

/**
 * Update stock tracking settings (e.g. threshold, unit, trackStock toggle)
 */
export async function updateItemStockSettings(
  itemId: string,
  settings: {
    trackStock?: boolean;
    lowStockThreshold?: number;
    stockUnit?: string;
  }
): Promise<MenuItem[]> {
  const current = getStoredMenu();
  const updated = current.map((item) =>
    item.id === itemId
      ? {
          ...item,
          ...settings,
        }
      : item
  );

  saveStoredMenu(updated);

  if (database) {
    try {
      const itemRef = ref(database, `menu/${itemId}`);
      await update(itemRef, settings);
    } catch (e) {}
  }

  return updated;
}

/**
 * Batch restock multiple items in one transaction
 */
export async function batchRestockItems(
  restockList: Array<{ itemId: string; addUnits: number }>,
  note?: string
): Promise<MenuItem[]> {
  const current = getStoredMenu();
  const updated = [...current];

  for (const entry of restockList) {
    if (entry.addUnits <= 0) continue;
    const idx = updated.findIndex((i) => i.id === entry.itemId);
    if (idx !== -1) {
      const prevStock = updated[idx].stockQuantity ?? 0;
      const newStock = prevStock + entry.addUnits;
      updated[idx] = {
        ...updated[idx],
        stockQuantity: newStock,
        available: true,
        lastRestockedAt: Date.now(),
      };

      recordStockLog({
        itemId: entry.itemId,
        itemTitle: updated[idx].title,
        delta: entry.addUnits,
        previousStock: prevStock,
        newStock,
        reason: 'restock',
        note: note || 'توريد دفعة مخزون جديدة',
      });

      if (database) {
        try {
          const itemRef = ref(database, `menu/${entry.itemId}`);
          update(itemRef, {
            stockQuantity: newStock,
            available: true,
            lastRestockedAt: Date.now(),
          });
        } catch (e) {}
      }
    }
  }

  saveStoredMenu(updated);
  return updated;
}

/**
 * Deduct stock automatically when order is accepted/processed
 */
export async function deductStockForOrder(order: import('../types').Order): Promise<MenuItem[]> {
  const current = getStoredMenu();
  const updated = [...current];

  for (const line of order.items) {
    const idx = updated.findIndex((i) => i.id === line.itemId);
    if (idx !== -1) {
      const item = updated[idx];
      if (item.trackStock) {
        const prev = item.stockQuantity ?? 0;
        const newStock = Math.max(0, prev - line.quantity);
        const delta = newStock - prev;

        updated[idx] = {
          ...item,
          stockQuantity: newStock,
          available: newStock > 0 ? item.available : false,
        };

        recordStockLog({
          itemId: item.id,
          itemTitle: item.title,
          delta,
          previousStock: prev,
          newStock,
          reason: 'order_sale',
          note: `فاتورة #${order.invoiceNumber}`,
        });

        if (database) {
          try {
            const itemRef = ref(database, `menu/${item.id}`);
            update(itemRef, {
              stockQuantity: newStock,
              available: newStock > 0 ? item.available : false,
            });
          } catch (e) {}
        }
      }
    }
  }

  saveStoredMenu(updated);
  return updated;
}
