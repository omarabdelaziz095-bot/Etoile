/**
 * POS Thermal Receipt, Kitchen Slip, and Report Printing Service
 * Uses a dedicated #pos-print-mount container directly in the DOM
 * coupled with strict @media print rules that hide the rest of the application.
 * This guarantees 100% reliable printing without blank white pages, clipping,
 * or modal backdrop interference.
 */

import { Order, MenuItem, Language } from '../types';

/**
 * Universal print executor: injects clean receipt HTML into the dedicated #pos-print-mount
 * and invokes window.print().
 */
function executeUniversalPrint(
  contentHtml: string,
  documentTitle = 'Receipt',
  format: 'thermal' | 'a4' = 'thermal'
): void {
  // 1. Get or create the dedicated print mount element
  let mount = document.getElementById('pos-print-mount');
  if (!mount) {
    mount = document.createElement('div');
    mount.id = 'pos-print-mount';
    document.body.appendChild(mount);
  }

  // 2. Set format and content
  mount.setAttribute('data-format', format);
  mount.setAttribute('dir', 'rtl');
  mount.innerHTML = contentHtml;

  // 3. Update document title temporarily for printer header/file naming
  const prevTitle = document.title;
  document.title = documentTitle;

  // 4. Cleanup after print
  const cleanup = () => {
    document.title = prevTitle;
    if (mount) {
      mount.innerHTML = '';
    }
    window.removeEventListener('afterprint', cleanup);
  };

  window.addEventListener('afterprint', cleanup, { once: true });

  // 5. Trigger print after layout calculation
  // Using requestAnimationFrame + small delay ensures browser renders the DOM fully
  requestAnimationFrame(() => {
    setTimeout(() => {
      try {
        window.print();
      } catch (err) {
        console.warn('window.print error:', err);
      } finally {
        // Fallback cleanup in case afterprint does not fire in some browsers/extensions
        setTimeout(cleanup, 2500);
      }
    }, 80);
  });
}

/**
 * Generates the clean HTML markup for an 80mm thermal receipt
 */
export function generateReceiptMarkup(order: Order, language: Language = 'ar'): string {
  const isAr = language === 'ar';
  const formattedDate = new Date(order.createdAt).toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
  const formattedTime = new Date(order.createdAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  const diningLabel =
    order.diningMode === 'dine_in'
      ? (isAr ? `صالة (طاولة: ${order.tableNumber || '-'})` : `Dine-In (Table: ${order.tableNumber || '-'})`)
      : (isAr ? `تيك أواي (${order.customerName || 'عميل'})` : `Takeaway (${order.customerName || 'Guest'})`);

  const itemsHtml = order.items
    .map(
      (item) => `
    <tr style="border-bottom: 1px dotted #888;">
      <td style="text-align: right; padding: 4px 0; font-weight: 900; width: 34px; font-family: monospace; font-size: 13px;">${item.quantity}×</td>
      <td style="text-align: right; padding: 4px 6px;">
        <div style="font-weight: 700; font-size: 12px; color: #000;">${item.title.ar || item.title.en}</div>
        ${item.selectedSize ? `<div style="font-size: 10px; color: #444; font-weight: 600;">[ ${item.selectedSize} ]</div>` : ''}
        ${item.notes ? `<div style="font-size: 10px; color: #444; font-style: italic;">ملاحظة: ${item.notes}</div>` : ''}
      </td>
      <td style="text-align: left; padding: 4px 0; font-family: monospace; font-weight: 900; font-size: 12px; width: 65px; color: #000;">
        ${item.totalPrice} ج.م
      </td>
    </tr>
  `
    )
    .join('');

  return `
    <div style="width: 100%; max-width: 74mm; margin: 0 auto; padding: 2mm 1mm; font-family: 'Cairo', system-ui, -apple-system, monospace, sans-serif; font-size: 11px; line-height: 1.35; color: #000; direction: rtl; text-align: start;">
      {/* Brand Header */}
      <div style="text-align: center; border-bottom: 1px dashed #000; padding-bottom: 8px; margin-bottom: 8px;">
        <div style="font-size: 20px; font-weight: 900; letter-spacing: 0.5px; color: #000;">حلواني إيتوال</div>
        <div style="font-size: 12px; font-weight: 800; color: #222; margin-top: 1px;">Étoile Patisserie & Bakery</div>
        <div style="font-size: 10px; font-weight: 600; color: #333; margin-top: 2px;">صناع السعادة منذ 1999 • فرع القاهرة الرئيسي</div>
        <div style="font-size: 10px; font-weight: 700; color: #000; margin-top: 2px;">الخط الساخن: 16312 • س.ت: 48920</div>
        <div style="font-size: 9px; color: #444; margin-top: 1px;">رقم التسجيل الضريبي: 512-884-301</div>
      </div>

      {/* Invoice Meta Table */}
      <table style="width: 100%; border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; font-size: 11px; border-collapse: collapse;">
        <tr>
          <td style="font-weight: 800; padding: 2px 0;">رقم الفاتورة:</td>
          <td style="text-align: left; font-size: 15px; font-weight: 900; font-family: monospace; color: #000;">${order.invoiceNumber}</td>
        </tr>
        <tr>
          <td style="padding: 2px 0; color: #333;">التاريخ والوقت:</td>
          <td style="text-align: left; font-size: 10px; font-family: monospace; color: #333;">${formattedDate} ${formattedTime}</td>
        </tr>
        <tr>
          <td style="font-weight: 800; padding: 2px 0;">طريقة الطلب:</td>
          <td style="text-align: left; font-weight: 800; color: #000;">${diningLabel}</td>
        </tr>
        ${order.customerPhone ? `<tr><td style="padding: 2px 0;">رقم الهاتف:</td><td style="text-align: left; font-family: monospace; font-weight: 700;">${order.customerPhone}</td></tr>` : ''}
        ${order.specialNotes ? `<tr><td colspan="2" style="font-size: 10px; padding-top: 4px; color: #111; font-weight: 600;"><strong>ملاحظات:</strong> ${order.specialNotes}</td></tr>` : ''}
      </table>

      {/* Line Items Table */}
      <table style="width: 100%; border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; font-size: 11px; border-collapse: collapse;">
        <thead>
          <tr style="border-bottom: 1px solid #000;">
            <th style="text-align: right; width: 34px; padding-bottom: 3px; font-weight: 900;">الكمية</th>
            <th style="text-align: right; padding-bottom: 3px; font-weight: 900;">الصنف</th>
            <th style="text-align: left; width: 65px; padding-bottom: 3px; font-weight: 900;">الإجمالي</th>
          </tr>
        </thead>
        <tbody>
          ${itemsHtml}
        </tbody>
      </table>

      {/* Financial Summary */}
      <table style="width: 100%; border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 6px; font-size: 11px; border-collapse: collapse;">
        <tr>
          <td style="padding: 2px 0; color: #333;">المجموع الفرعي:</td>
          <td style="text-align: left; font-family: monospace; font-weight: 700;">${order.subtotal} ج.م</td>
        </tr>
        <tr>
          <td style="padding: 2px 0; color: #333;">ضريبة القيمة المضافة (14% VAT):</td>
          <td style="text-align: left; font-family: monospace; font-weight: 700;">${order.tax} ج.م</td>
        </tr>
        <tr style="border-top: 1px solid #000; font-size: 14px; font-weight: 900;">
          <td style="padding-top: 4px; color: #000;">الإجمالي المطلوب:</td>
          <td style="text-align: left; font-family: monospace; padding-top: 4px; color: #000;">${order.total} ج.م</td>
        </tr>
      </table>

      {/* Barcode & Footer Notice */}
      <div style="text-align: center; padding-top: 6px; font-size: 10px;">
        <div style="font-family: monospace; letter-spacing: 2px; font-size: 12px; border: 1px solid #000; padding: 3px 8px; margin: 4px auto; display: inline-block; font-weight: 900; background: #fafafa;">
          * ${order.invoiceNumber.replace('#', '')} *
        </div>
        <p style="font-weight: 800; margin-top: 3px; color: #000;">نتمنى لكم تجربة سعيدة ولذيذة دائماً!</p>
        <p style="color: #444; margin-top: 1px; font-size: 9px;">الموقع الإلكتروني: etoileeg.online</p>
      </div>
    </div>
  `;
}

/**
 * 1. Print Standard 80mm POS Thermal Receipt
 */
export function printThermalReceipt(order: Order, language: Language = 'ar'): void {
  const markup = generateReceiptMarkup(order, language);
  executeUniversalPrint(markup, `Receipt_${order.invoiceNumber}`, 'thermal');
}

/**
 * 2. Print Kitchen Preparation Slip (KDS)
 */
export function printKitchenSlip(order: Order, language: Language = 'ar'): void {
  const isAr = language === 'ar';
  const orderTime = new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const minutesAgo = Math.floor((Date.now() - order.createdAt) / 60000);

  const itemsHtml = order.items
    .map(
      (item, idx) => `
    <div style="border: 1.5px solid #000; border-radius: 4px; padding: 6px 8px; margin-bottom: 6px; background: #fff;">
      <div style="display: flex; justify-content: space-between; align-items: baseline;">
        <span style="font-size: 18px; font-weight: 900; font-family: monospace; color: #000;">${item.quantity}×</span>
        <span style="font-size: 15px; font-weight: 900; flex: 1; margin-right: 8px; color: #000;">${item.title.ar || item.title.en}</span>
        <span style="font-size: 11px; font-family: monospace; color: #555;">#${idx + 1}</span>
      </div>
      ${item.selectedSize ? `<div style="font-size: 12px; font-weight: 800; margin-top: 2px; color: #000;">[ الحجم: ${item.selectedSize} ]</div>` : ''}
      ${item.notes ? `<div style="font-size: 11px; margin-top: 2px; color: #111; font-weight: 600;">⚠️ ملاحظة: ${item.notes}</div>` : ''}
    </div>
  `
    )
    .join('');

  const markup = `
    <div style="width: 100%; max-width: 74mm; margin: 0 auto; padding: 2mm 1mm; font-family: 'Cairo', system-ui, -apple-system, monospace, sans-serif; font-size: 12px; line-height: 1.3; color: #000; direction: rtl; text-align: start;">
      <div style="text-align: center; border-bottom: 2px solid #000; padding-bottom: 6px; margin-bottom: 8px;">
        <div style="display: inline-block; background: #000; color: #fff; padding: 2px 10px; border-radius: 4px; font-weight: 900; font-size: 13px; margin-bottom: 4px;">
          بون المطبخ • KITCHEN ORDER
        </div>
        <div style="font-size: 26px; font-weight: 900; font-family: monospace; letter-spacing: 1px; color: #000;">
          ${order.invoiceNumber}
        </div>
        <div style="font-weight: 800; font-size: 14px; margin-top: 2px; color: #000;">
          ${order.diningMode === 'dine_in' ? `طاولة رقم: ${order.tableNumber || '-'}` : `تيك أواي: ${order.customerName || 'عميل'}`}
        </div>
      </div>

      <div style="border-bottom: 1px dashed #000; padding-bottom: 6px; margin-bottom: 8px; font-size: 12px;">
        <div style="display: flex; justify-content: space-between; padding: 2px 0;">
          <span>وقت الطلب:</span>
          <span style="font-family: monospace; font-weight: 900;">${orderTime} (${minutesAgo} دقيقة مضت)</span>
        </div>
        <div style="display: flex; justify-content: space-between; padding: 2px 0;">
          <span>عدد الأصناف:</span>
          <span style="font-weight: 900;">${order.items.reduce((acc, it) => acc + it.quantity, 0)} صنف</span>
        </div>
      </div>

      ${order.specialNotes ? `
        <div style="border: 2px dashed #000; background: #f2f2f2; padding: 6px; margin-bottom: 8px; font-size: 12px; font-weight: 900;">
          ⚠️ ملاحظة خاصة: ${order.specialNotes}
        </div>
      ` : ''}

      <div style="margin-bottom: 10px;">
        <div style="font-size: 11px; font-weight: 900; margin-bottom: 4px; color: #000;">أصناف التحضير:</div>
        ${itemsHtml}
      </div>

      <div style="text-align: center; border-top: 1px dashed #000; padding-top: 6px; font-size: 10px; font-weight: 700;">
        حلواني إيتوال • نظام المطبخ الذكي KDS
      </div>
    </div>
  `;

  executeUniversalPrint(markup, `KitchenSlip_${order.invoiceNumber}`, 'thermal');
}

/**
 * 3. Print Comprehensive Stock Inventory Sheet
 */
export function printStockInventorySheet(menuItems: MenuItem[], language: Language = 'ar'): void {
  const isAr = language === 'ar';
  const now = new Date().toLocaleString(isAr ? 'ar-EG' : 'en-US');

  const rowsHtml = menuItems
    .map(
      (item, idx) => `
    <tr style="border-bottom: 1px solid #ddd; ${item.trackStock && (item.stockQuantity ?? 0) <= (item.lowStockThreshold ?? 5) ? 'background-color: #fff4e5;' : ''}">
      <td style="padding: 5px; text-align: center; font-family: monospace;">${idx + 1}</td>
      <td style="padding: 5px; font-family: monospace; font-weight: bold;">${item.id}</td>
      <td style="padding: 5px; font-weight: 700;">${item.title.ar}</td>
      <td style="padding: 5px; color: #444;">${item.category}</td>
      <td style="padding: 5px; text-align: center; font-family: monospace; font-weight: 900; font-size: 13px;">${item.trackStock ? item.stockQuantity ?? 0 : '-'}</td>
      <td style="padding: 5px; text-align: center;">${item.stockUnit || 'قطعة'}</td>
      <td style="padding: 5px; text-align: center; font-family: monospace;">${item.trackStock ? item.lowStockThreshold ?? 5 : '-'}</td>
      <td style="padding: 5px; text-align: left; font-family: monospace;">${item.price} ج.م</td>
      <td style="padding: 5px; text-align: left; font-family: monospace; font-weight: bold;">
        ${item.trackStock ? ((item.stockQuantity ?? 0) * item.price).toLocaleString() : '-'} ج.م
      </td>
      <td style="padding: 5px; text-align: center;">
        ${!item.available ? '<span style="color: red; font-weight: bold;">مجمد</span>' : (item.trackStock && (item.stockQuantity ?? 0) <= 0) ? '<span style="color: red; font-weight: bold;">نفد</span>' : '<span style="color: green; font-weight: bold;">متاح</span>'}
      </td>
    </tr>
  `
    )
    .join('');

  const totalTracked = menuItems.filter((i) => i.trackStock).length;
  const lowCount = menuItems.filter((i) => i.trackStock && (i.stockQuantity ?? 0) <= (i.lowStockThreshold ?? 5)).length;
  const totalVal = menuItems.reduce((sum, i) => sum + (i.trackStock ? (i.stockQuantity ?? 0) * i.price : 0), 0);

  const markup = `
    <div style="width: 100%; font-family: 'Cairo', system-ui, -apple-system, sans-serif; font-size: 11px; color: #000; direction: rtl; text-align: start; padding: 10px;">
      <div style="display: flex; justify-content: space-between; align-items: center; border-bottom: 2px solid #B4963C; padding-bottom: 12px; margin-bottom: 15px;">
        <div>
          <div style="font-size: 20px; font-weight: 900; color: #B4963C;">حلواني إيتوال • كشف جرد المخزون العام</div>
          <div style="font-size: 11px; color: #444; margin-top: 2px;">Étoile Patisserie & Bakery - Official Stock Inventory Sheet</div>
        </div>
        <div style="text-align: left; font-size: 10px; color: #444;">
          <div>تاريخ الطباعة: ${now}</div>
          <div>الفرع: الإدارة المركزية / جميع الأقسام</div>
        </div>
      </div>

      <div style="display: flex; gap: 15px; margin-bottom: 15px; background: #faf8f3; border: 1px solid #e6dec5; padding: 10px 15px; border-radius: 8px;">
        <div style="flex: 1;">
          <div style="font-size: 10px; color: #666; font-weight: bold;">إجمالي أصناف المنيو</div>
          <div style="font-size: 16px; font-weight: 900; color: #000; margin-top: 2px;">${menuItems.length} صنف</div>
        </div>
        <div style="flex: 1;">
          <div style="font-size: 10px; color: #666; font-weight: bold;">الأصناف المتتبعة</div>
          <div style="font-size: 16px; font-weight: 900; color: #000; margin-top: 2px;">${totalTracked} صنف</div>
        </div>
        <div style="flex: 1;">
          <div style="font-size: 10px; color: #666; font-weight: bold;">أصناف منخفضة / قاربت على النفاد</div>
          <div style="font-size: 16px; font-weight: 900; color: #c53030; margin-top: 2px;">${lowCount} صنف</div>
        </div>
        <div style="flex: 1;">
          <div style="font-size: 10px; color: #666; font-weight: bold;">القيمة الإجمالية للمخزون</div>
          <div style="font-size: 16px; font-weight: 900; color: #B4963C; margin-top: 2px;">${totalVal.toLocaleString()} ج.م</div>
        </div>
      </div>

      <table style="width: 100%; border-collapse: collapse; font-size: 10.5px;">
        <thead>
          <tr>
            <th style="width: 25px; text-align: center; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">#</th>
            <th style="width: 70px; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">الكود</th>
            <th style="background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; text-align: right; font-weight: 800;">اسم الصنف</th>
            <th style="background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; text-align: right; font-weight: 800;">القسم</th>
            <th style="text-align: center; width: 60px; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">الرصيد</th>
            <th style="text-align: center; width: 50px; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">الوحدة</th>
            <th style="text-align: center; width: 50px; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">الحد الأدنى</th>
            <th style="text-align: left; width: 60px; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">السعر</th>
            <th style="text-align: left; width: 85px; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">إجمالي القيمة</th>
            <th style="text-align: center; width: 55px; background: #f2ede1; border-bottom: 2px solid #B4963C; padding: 8px 6px; font-weight: 800;">الحالة</th>
          </tr>
        </thead>
        <tbody>
          ${rowsHtml}
        </tbody>
      </table>

      <div style="margin-top: 20px; display: flex; justify-content: space-between; border-top: 1px solid #ccc; padding-top: 10px; font-size: 10px; color: #555;">
        <div>توقيع أمين المخزن: _____________________</div>
        <div>توقيع مدير الفرع: _____________________</div>
        <div>حلواني إيتوال © ${new Date().getFullYear()}</div>
      </div>
    </div>
  `;

  executeUniversalPrint(markup, `Stock_Inventory_${new Date().toISOString().slice(0, 10)}`, 'a4');
}

/**
 * 4. Open Standalone Printable Window / Tab as a convenient preview & PDF export
 */
export function openPrintableReceiptWindow(order: Order, language: Language = 'ar'): void {
  const markup = generateReceiptMarkup(order, language);
  const printWindow = window.open('', '_blank', 'width=420,height=680');
  if (!printWindow) {
    // Popup blocked, fallback to universal in-page print
    printThermalReceipt(order, language);
    return;
  }

  const fullHtml = `
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
      <meta charset="UTF-8">
      <title>إيصال_${order.invoiceNumber}</title>
      <link rel="preconnect" href="https://fonts.googleapis.com">
      <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
      <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap" rel="stylesheet">
      <style>
        @page {
          size: 80mm auto;
          margin: 2mm;
        }
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        body {
          background: #ffffff;
          color: #000000;
          padding: 3mm 2mm;
          font-family: 'Cairo', system-ui, sans-serif;
          display: flex;
          justify-content: center;
        }
        @media print {
          body {
            padding: 0;
          }
        }
      </style>
    </head>
    <body>
      ${markup}
      <script>
        window.onload = function() {
          setTimeout(function() {
            window.focus();
            window.print();
          }, 200);
        };
      </script>
    </body>
    </html>
  `;

  printWindow.document.open();
  printWindow.document.write(fullHtml);
  printWindow.document.close();
}
