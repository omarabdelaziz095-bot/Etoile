import { Order, OrderStatus } from '../types';

const STORAGE_KEY = 'etoile_customer_recent_orders';

/**
 * Retrieve recent customer orders stored on this device from localStorage
 */
export const getCustomerRecentOrders = (): Order[] => {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed;
    }
    return [];
  } catch (err) {
    console.error('Failed to load recent orders from localStorage:', err);
    return [];
  }
};

/**
 * Save a newly placed order to localStorage (prepended as latest)
 */
export const saveCustomerRecentOrder = (order: Order): void => {
  if (typeof window === 'undefined') return;
  try {
    const existing = getCustomerRecentOrders();
    // Prevent duplicate entries for the same order ID or invoiceNumber
    const filtered = existing.filter(
      (o) => o.id !== order.id && o.invoiceNumber !== order.invoiceNumber
    );
    const updated = [order, ...filtered].slice(0, 50); // Store up to last 50 orders
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to save recent order to localStorage:', err);
  }
};

/**
 * Update an order's status or details in local storage
 */
export const updateCustomerRecentOrderStatus = (orderId: string, status: OrderStatus): void => {
  if (typeof window === 'undefined') return;
  try {
    const existing = getCustomerRecentOrders();
    const updated = existing.map((o) => (o.id === orderId ? { ...o, status } : o));
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to update recent order status:', err);
  }
};

/**
 * Remove an order from local storage
 */
export const removeCustomerRecentOrder = (orderId: string): void => {
  if (typeof window === 'undefined') return;
  try {
    const existing = getCustomerRecentOrders();
    const updated = existing.filter((o) => o.id !== orderId);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
  } catch (err) {
    console.error('Failed to remove recent order:', err);
  }
};

/**
 * Clear all recent orders from this device
 */
export const clearCustomerRecentOrders = (): void => {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.error('Failed to clear recent orders:', err);
  }
};
