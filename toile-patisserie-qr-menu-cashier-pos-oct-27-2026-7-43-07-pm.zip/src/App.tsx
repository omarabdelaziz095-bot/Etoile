/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Phone,
  MapPin,
  Globe,
  Utensils,
  Flame,
  Award,
  Shield,
} from 'lucide-react';
import {
  Language,
  MenuItem,
  CartItem,
  Order,
  ItemSizeVariation,
  StaffUser,
  StaffPermission,
} from './types';
import {
  ETOILE_CATEGORIES,
  ETOILE_BRAND,
} from './data/etoileMenuData';
import {
  getStoredMenu,
  subscribeToOrders,
  subscribeToSignals,
  subscribeToMenu,
  deductStockForOrder,
  CashierSignal,
} from './services/firebaseService';
import { audioService } from './services/audioService';
import {
  getCurrentStaffUser,
  hasPermission,
} from './services/staffUserService';

// Customer Menu Components
import { Header } from './components/CustomerMenu/Header';
import { CategoryTabs } from './components/CustomerMenu/CategoryTabs';
import { SearchBar } from './components/CustomerMenu/SearchBar';
import { ProductCard } from './components/CustomerMenu/ProductCard';
import { FloatingCartBar } from './components/CustomerMenu/FloatingCartBar';
import { CartModal } from './components/CustomerMenu/CartModal';
import { OrderConfirmationModal } from './components/CustomerMenu/OrderConfirmationModal';
import { BranchContactDrawer } from './components/CustomerMenu/BranchContactDrawer';
import { AIChatDrawer } from './components/CustomerMenu/AIChatDrawer';
import { StaffLoginModal } from './components/CustomerMenu/StaffLoginModal';
import { RecentOrdersView } from './components/CustomerMenu/RecentOrdersView';
import {
  getCustomerRecentOrders,
  saveCustomerRecentOrder,
  clearCustomerRecentOrders,
} from './services/customerOrdersService';

// Cashier POS Components
import { POSHeader, POSViewTab } from './components/CashierPOS/POSHeader';
import { OrderStream } from './components/CashierPOS/OrderStream';
import { ThermalReceiptModal } from './components/CashierPOS/ThermalReceiptModal';
import { KitchenDisplayModal } from './components/CashierPOS/KitchenDisplayModal';
import { POSAnalytics } from './components/CashierPOS/POSAnalytics';
import { MenuInventoryManager } from './components/CashierPOS/MenuInventoryManager';
import { StockManager } from './components/CashierPOS/StockManager';
import { AIImageStudioModal } from './components/CashierPOS/AIImageStudioModal';
import { StaffUserManager } from './components/CashierPOS/StaffUserManager';

export default function App() {
  // Language State
  const [language, setLanguage] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('etoile_lang');
      return saved === 'en' ? 'en' : 'ar';
    } catch {
      return 'ar';
    }
  });

  // Check if current URL is targeting Cashier POS
  const checkIsPOSUrl = () => {
    if (typeof window === 'undefined') return false;
    const urlParams = new URLSearchParams(window.location.search);
    return (
      urlParams.get('view') === 'cashier' ||
      urlParams.get('pos') === 'true' ||
      window.location.hash.includes('pos') ||
      window.location.hash.includes('cashier') ||
      window.location.pathname.includes('/pos') ||
      window.location.pathname.endsWith('/pos.html')
    );
  };

  const [activeView, setActiveView] = useState<'customer' | 'cashier'>(() => {
    return checkIsPOSUrl() ? 'cashier' : 'customer';
  });

  // Listen to popstate & hashchange to allow direct URL navigation
  useEffect(() => {
    const handleLocationCheck = () => {
      if (checkIsPOSUrl()) {
        setActiveView('cashier');
      }
    };

    window.addEventListener('popstate', handleLocationCheck);
    window.addEventListener('hashchange', handleLocationCheck);
    return () => {
      window.removeEventListener('popstate', handleLocationCheck);
      window.removeEventListener('hashchange', handleLocationCheck);
    };
  }, []);

  // Keep HTML lang & dir synced
  useEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    try {
      localStorage.setItem('etoile_lang', language);
    } catch {}
  }, [language]);

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === 'ar' ? 'en' : 'ar'));
  };

  // Switch to POS and update URL hash so it's shareable and bookmarkable
  const handleOpenPOS = () => {
    setActiveView('cashier');
    try {
      window.history.pushState(null, '', '/?view=cashier#pos');
    } catch {}
  };

  // Exit POS and return to customer menu
  const handleExitPOS = () => {
    setActiveView('customer');
    try {
      window.history.pushState(null, '', '/');
    } catch {}
  };

  // Check if Cashier POS button should be hidden on customer menu (Default: true in production/customer view)
  const [isPOSButtonHidden, setIsPOSButtonHidden] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('etoile_hide_pos_btn');
      return saved !== 'false'; // Default to true (hidden) for clean customer experience
    } catch {
      return true;
    }
  });

  const handleToggleHidePOS = (hidden: boolean) => {
    setIsPOSButtonHidden(hidden);
    try {
      localStorage.setItem('etoile_hide_pos_btn', hidden ? 'true' : 'false');
    } catch {}
  };

  // Menu State
  const [menuItems, setMenuItems] = useState<MenuItem[]>(() => getStoredMenu());
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string | null>(null);

  // Cart State
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [confirmedOrder, setConfirmedOrder] = useState<Order | null>(null);

  // Modals & Drawers State
  const [isBranchesOpen, setIsBranchesOpen] = useState(false);
  const [isAIChatOpen, setIsAIChatOpen] = useState(false);
  const [isStaffLoginOpen, setIsStaffLoginOpen] = useState(false);

  // Cashier POS State & Staff Authentication
  const [currentStaffUser, setCurrentStaffUser] = useState<StaffUser | null>(() => getCurrentStaffUser());
  const [orders, setOrders] = useState<Order[]>([]);
  const [isFirebaseConnected, setIsFirebaseConnected] = useState(true);
  const [currentPOSTab, setCurrentPOSTab] = useState<POSViewTab>('orders');
  const [activeThermalReceiptOrder, setActiveThermalReceiptOrder] = useState<Order | null>(null);
  const [activeKitchenDisplayOrder, setActiveKitchenDisplayOrder] = useState<Order | null>(null);

  const [activeSignalToast, setActiveSignalToast] = useState<CashierSignal | null>(null);

  const tabPermissionsMap: Record<POSViewTab, StaffPermission> = {
    orders: 'orders',
    kitchen: 'kitchen',
    analytics: 'analytics',
    inventory: 'inventory',
    stock: 'stock',
    ai_studio: 'ai_studio',
    users: 'users',
  };

  const handleStaffLoginSuccess = (user: StaffUser) => {
    setCurrentStaffUser(user);
    // If the currently active tab is not permitted for this user, switch to the first authorized tab
    if (!hasPermission(user, tabPermissionsMap[currentPOSTab])) {
      const allTabs: POSViewTab[] = ['orders', 'kitchen', 'stock', 'inventory', 'analytics', 'ai_studio', 'users'];
      const firstAllowed = allTabs.find((t) => hasPermission(user, tabPermissionsMap[t]));
      if (firstAllowed) {
        setCurrentPOSTab(firstAllowed);
      }
    }
    handleOpenPOS();
  };

  // Real-time Orders, Signals, and Menu subscriptions via Firebase RTDB onValue
  useEffect(() => {
    // 1. Orders stream
    const unsubscribeOrders = subscribeToOrders((updatedOrders, connected) => {
      setOrders(updatedOrders);
      setIsFirebaseConnected(connected);
    });

    // 2. Real-time Signals detected instantly without page reload
    const unsubscribeSignals = subscribeToSignals((signal) => {
      if (signal.type === 'new_order') {
        audioService.playNewOrderAlert();
      } else if (signal.type === 'kitchen_ready') {
        audioService.playKitchenBell();
      }
      setActiveSignalToast(signal);
      setTimeout(() => {
        setActiveSignalToast((prev) => (prev?.id === signal.id ? null : prev));
      }, 6000);
    });

    // 3. Real-time Menu Inventory sync
    const unsubscribeMenu = subscribeToMenu((updatedMenu) => {
      setMenuItems(updatedMenu);
    });

    return () => {
      unsubscribeOrders();
      unsubscribeSignals();
      unsubscribeMenu();
    };
  }, []);

  // Cart Calculations
  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const totalCartPrice = cartItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);

  // Cart Helper functions
  const handleAddToCart = (item: MenuItem, selectedSize?: ItemSizeVariation) => {
    const sizeId = selectedSize ? selectedSize.id : 'default';
    const cartItemId = `${item.id}_${sizeId}`;
    const price = selectedSize ? selectedSize.price : item.price;

    setCartItems((prev) => {
      const existing = prev.find((ci) => ci.id === cartItemId);
      if (existing) {
        return prev.map((ci) =>
          ci.id === cartItemId ? { ...ci, quantity: ci.quantity + 1 } : ci
        );
      }
      return [
        ...prev,
        {
          id: cartItemId,
          menuItem: item,
          quantity: 1,
          selectedSize,
          unitPrice: price,
        },
      ];
    });
  };

  const handleIncrement = (item: MenuItem, selectedSize?: ItemSizeVariation) => {
    handleAddToCart(item, selectedSize);
  };

  const handleDecrement = (item: MenuItem, selectedSize?: ItemSizeVariation) => {
    const sizeId = selectedSize ? selectedSize.id : 'default';
    const cartItemId = `${item.id}_${sizeId}`;

    setCartItems((prev) => {
      const existing = prev.find((ci) => ci.id === cartItemId);
      if (!existing) return prev;
      if (existing.quantity <= 1) {
        return prev.filter((ci) => ci.id !== cartItemId);
      }
      return prev.map((ci) =>
        ci.id === cartItemId ? { ...ci, quantity: ci.quantity - 1 } : ci
      );
    });
  };

  const handleRemoveCartItem = (cartItemId: string) => {
    setCartItems((prev) => prev.filter((ci) => ci.id !== cartItemId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  // Recent Orders State (loaded from localStorage on this device)
  const [recentOrders, setRecentOrders] = useState<Order[]>(() => getCustomerRecentOrders());

  // Merge recent orders with live status updates from Firebase orders stream
  const mergedRecentOrders = recentOrders.map((rec) => {
    const live = orders.find((o) => o.id === rec.id || o.invoiceNumber === rec.invoiceNumber);
    return live ? { ...rec, status: live.status } : rec;
  });

  // Reorder past order items
  const handleReorderPastOrder = (pastOrder: Order) => {
    const newCartItems: CartItem[] = [];
    pastOrder.items.forEach((line) => {
      const existingItem = menuItems.find((mi) => mi.id === line.itemId);
      const menuItem: MenuItem = existingItem || {
        id: line.itemId,
        title: line.title,
        description: { ar: '', en: '' },
        price: line.unitPrice,
        category: 'oriental',
        rating: 5,
        ratingCount: 1,
        available: true,
        image: '',
        prepTimeMinutes: 15,
        sizes: [],
      };
      const size = menuItem.sizes?.find((s: ItemSizeVariation) => s.name[language] === line.selectedSize);
      const sizeId = size ? size.id : 'default';
      newCartItems.push({
        id: `${menuItem.id}_${sizeId}`,
        menuItem,
        quantity: line.quantity,
        selectedSize: size,
        unitPrice: line.unitPrice,
        specialInstructions: line.notes,
      });
    });
    setCartItems(newCartItems);
    setIsCartOpen(true);
  };

  // Clear customer order history
  const handleClearCustomerOrders = () => {
    clearCustomerRecentOrders();
    setRecentOrders([]);
  };

  // Handle rating item
  const handleRateItem = (itemId: string, rating: number) => {
    setMenuItems((prev) =>
      prev.map((item) => {
        if (item.id === itemId) {
          const newCount = item.ratingCount + 1;
          const newAvg = Number(((item.rating * item.ratingCount + rating) / newCount).toFixed(1));
          return { ...item, rating: newAvg, ratingCount: newCount };
        }
        return item;
      })
    );
  };

  // Filter Menu Items
  const filteredMenuItems = menuItems.filter((item) => {
    // 1. Category Filter
    if (selectedCategory !== 'all' && item.category !== selectedCategory) {
      return false;
    }

    // 2. Search Query Filter
    if (searchQuery.trim()) {
      const query = searchQuery.toLowerCase().trim();
      const matchAr = item.title.ar.toLowerCase().includes(query) || item.description.ar.toLowerCase().includes(query);
      const matchEn = item.title.en.toLowerCase().includes(query) || item.description.en.toLowerCase().includes(query);
      const matchSub = item.subCategory?.toLowerCase().includes(query);
      if (!matchAr && !matchEn && !matchSub) return false;
    }

    // 3. Quick Chips Filter
    if (activeFilter === 'discount') {
      if (!item.originalPrice && item.badge?.type !== 'discount' && item.category !== 'discounts') {
        return false;
      }
    } else if (activeFilter === 'top_rated') {
      if (item.rating < 4.9) return false;
    } else if (activeFilter === 'bestseller') {
      if (item.badge?.type !== 'bestseller') return false;
    } else if (activeFilter === 'under_100') {
      if (item.price >= 100) return false;
    }

    return true;
  });

  const isAr = language === 'ar';
  const newOrdersCount = orders.filter((o) => o.status === 'new').length;

  return (
    <div className="min-h-screen bg-[#FAFAF8] text-stone-900 flex flex-col selection:bg-[#B4963C] selection:text-white w-full overflow-x-hidden">
      {/* ========================================================
          VIEW: CASHIER POS & ORDER MANAGEMENT DASHBOARD
      ======================================================== */}
      {activeView === 'cashier' ? (
        <div className="flex-1 flex flex-col bg-[#FAFAF8] w-full">
          <POSHeader
            currentTab={currentPOSTab}
            onChangeTab={setCurrentPOSTab}
            newOrdersCount={newOrdersCount}
            isFirebaseConnected={isFirebaseConnected}
            onExitPOS={handleExitPOS}
            language={language}
            onToggleLanguage={toggleLanguage}
            currentStaffUser={currentStaffUser}
            onSwitchUser={() => setIsStaffLoginOpen(true)}
          />

          {/* Real-time Signal Notification Banner (onValue Instant Detection) */}
          {activeSignalToast && (
            <div className="bg-rose-600 text-white px-4 py-3 shadow-md flex items-center justify-between animate-fadeIn z-30">
              <div className="max-w-7xl mx-auto w-full flex items-center justify-between gap-3 text-xs sm:text-sm font-bold">
                <div className="flex items-center gap-2">
                  <span className="w-2.5 h-2.5 rounded-full bg-white animate-ping"></span>
                  <span>🔔 {activeSignalToast.message}</span>
                  {activeSignalToast.invoiceNumber && (
                    <span className="font-mono bg-white/20 px-2 py-0.5 rounded-md">
                      {activeSignalToast.invoiceNumber}
                    </span>
                  )}
                  {activeSignalToast.tableNumber && (
                    <span>• {isAr ? `طاولة ${activeSignalToast.tableNumber}` : `Table ${activeSignalToast.tableNumber}`}</span>
                  )}
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={() => {
                      setCurrentPOSTab('orders');
                      setActiveSignalToast(null);
                    }}
                    className="px-3 py-1 bg-white text-rose-700 hover:bg-stone-100 rounded-lg text-xs font-bold transition cursor-pointer shadow-xs"
                  >
                    {isAr ? 'عرض في جدول الطلبات' : 'View in Orders'}
                  </button>
                  <button
                    onClick={() => setActiveSignalToast(null)}
                    className="p-1 hover:bg-white/20 rounded-md transition text-white/80 hover:text-white cursor-pointer"
                  >
                    ✕
                  </button>
                </div>
              </div>
            </div>
          )}

          <main className="flex-1 max-w-7xl w-full mx-auto p-3 sm:p-5 md:p-6">
            {/* Permission Guard: Check if current logged-in staff is authorized */}
            {!hasPermission(currentStaffUser, tabPermissionsMap[currentPOSTab]) ? (
              <div className="bg-white rounded-3xl p-8 sm:p-12 text-center border border-stone-200 shadow-xs max-w-lg mx-auto my-8 space-y-4 animate-fadeIn">
                <div className="w-16 h-16 rounded-2xl bg-amber-50 text-[#B4963C] flex items-center justify-center mx-auto border border-[#B4963C]/20 shadow-xs">
                  <Shield className="w-8 h-8 stroke-[2]" />
                </div>
                <div className="space-y-1">
                  <h3 className="text-lg font-black text-stone-900 font-serif">
                    {isAr ? 'عفواً، لا تمتلك صلاحية الوصول لهذا القسم' : 'Access Restricted for Current User'}
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-500 leading-relaxed">
                    {isAr
                      ? `حسابك الحالي "${currentStaffUser?.name.ar || ''}" (${currentStaffUser?.roleTitle.ar || ''}) غير مصرح له بفتح هذا التبويب. يرجى مراجعة مدير الفرع أو تسجيل الدخول بحساب مصرح.`
                      : `Your account "${currentStaffUser?.name.en || ''}" (${currentStaffUser?.roleTitle.en || ''}) is not authorized to access this section.`}
                  </p>
                </div>
                <div className="pt-2">
                  <button
                    onClick={() => setIsStaffLoginOpen(true)}
                    className="px-5 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl text-xs sm:text-sm font-bold transition shadow-md shadow-[#B4963C]/20 cursor-pointer"
                  >
                    {isAr ? 'تبديل الحساب / تسجيل الدخول كمدير' : 'Switch Staff Account / Login as Admin'}
                  </button>
                </div>
              </div>
            ) : (
              <>
                {currentPOSTab === 'orders' && (
                  <OrderStream
                    orders={orders}
                    language={language}
                    onOpenThermalReceipt={setActiveThermalReceiptOrder}
                    onOpenKitchenDisplay={setActiveKitchenDisplayOrder}
                  />
                )}

                {currentPOSTab === 'kitchen' && (
                  <div className="space-y-4">
                    <div className="flex items-center justify-between bg-white p-5 rounded-2xl border border-stone-200 shadow-sm">
                      <div>
                        <h2 className="text-lg font-black text-stone-900">
                          {isAr ? 'شاشة المطبخ KDS - الطلبات الجارية' : 'Kitchen Display System (KDS)'}
                        </h2>
                        <p className="text-xs text-stone-500 mt-0.5">
                          {isAr ? 'متابعة بونات التحضير وأوقات التجهيز' : 'Active kitchen tickets and cook timers'}
                        </p>
                      </div>
                    </div>
                    <OrderStream
                      orders={orders.filter((o) => o.status === 'new' || o.status === 'preparing')}
                      language={language}
                      onOpenThermalReceipt={setActiveThermalReceiptOrder}
                      onOpenKitchenDisplay={setActiveKitchenDisplayOrder}
                    />
                  </div>
                )}

                {currentPOSTab === 'analytics' && (
                  <POSAnalytics orders={orders} language={language} />
                )}

                {currentPOSTab === 'inventory' && (
                  <MenuInventoryManager
                    menuItems={menuItems}
                    onUpdateMenu={setMenuItems}
                    language={language}
                    isPOSButtonHiddenOnCustomerMenu={isPOSButtonHidden}
                    onToggleHidePOSButton={handleToggleHidePOS}
                  />
                )}

                {currentPOSTab === 'stock' && (
                  <StockManager
                    menuItems={menuItems}
                    onUpdateMenu={setMenuItems}
                    language={language}
                  />
                )}

                {currentPOSTab === 'ai_studio' && (
                  <AIImageStudioModal language={language} />
                )}

                {currentPOSTab === 'users' && (
                  <StaffUserManager
                    currentUser={currentStaffUser}
                    onUserChanged={(updatedUser) => setCurrentStaffUser(updatedUser)}
                    language={language}
                  />
                )}
              </>
            )}
          </main>

          {/* Thermal Receipt Modal (80mm print) */}
          {activeThermalReceiptOrder && (
            <ThermalReceiptModal
              order={activeThermalReceiptOrder}
              onClose={() => setActiveThermalReceiptOrder(null)}
              language={language}
            />
          )}

          {/* Kitchen Display Modal */}
          {activeKitchenDisplayOrder && (
            <KitchenDisplayModal
              order={activeKitchenDisplayOrder}
              onClose={() => setActiveKitchenDisplayOrder(null)}
              onMarkReady={(order) => {
                setActiveKitchenDisplayOrder(null);
                setActiveThermalReceiptOrder(order);
              }}
              language={language}
            />
          )}
        </div>
      ) : (
        /* ========================================================
            VIEW: CUSTOMER INTERACTIVE QR MENU
        ======================================================== */
        <div className="flex-1 flex flex-col">
          {/* Header (100% Customer Facing) */}
          <Header
            language={language}
            onToggleLanguage={toggleLanguage}
            onOpenBranches={() => setIsBranchesOpen(true)}
            onOpenAIChat={() => setIsAIChatOpen(true)}
            onOpenStaffModal={() => setIsStaffLoginOpen(true)}
            onOpenRecentOrders={() => setSelectedCategory('recent_orders')}
            recentOrdersCount={recentOrders.length}
          />

          {/* Hero Banner with Étoile Pastry Showcase in Luxury Light & Gold Theme */}
          <div className="relative overflow-hidden bg-gradient-to-b from-white via-[#FAF7F0] to-[#FAFAF8] border-b border-[#B4963C]/20 w-full">
            <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-6 sm:py-10 md:py-12 flex flex-col md:flex-row items-center justify-between gap-6 sm:gap-8">
              <div className="space-y-3 sm:space-y-4 text-center md:text-start max-w-xl">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#B4963C]/10 border border-[#B4963C]/30 text-[#876E27] text-xs font-bold shadow-xs">
                  <Sparkles className="w-3.5 h-3.5 text-[#B4963C]" />
                  <span>{isAr ? 'منيو فروع حلواني إيتوال المباشر' : 'Official Étoile Direct QR Menu'}</span>
                </div>

                <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-stone-900 font-serif leading-tight">
                  {isAr ? 'حلويات شرقية، غربية وفطير بلدي لا يُقاوم' : 'Exquisite Pastries & Authentic Egyptian Feteer'}
                </h2>

                <p className="text-xs sm:text-sm md:text-base text-stone-600 leading-relaxed">
                  {isAr
                    ? 'استمتع بأشهى بسبوسة بالسمن البلدي، قشطوطة اللوتس والمانجو، تورت الفورسيزونز، والفطير المشلتت الساخن مع التوصيل السريع لجميع مناطق القاهرة والإسكندرية.'
                    : 'Indulge in artisanal Basbousa with pure ghee, viral Lotus & Mango Qashtoota, celebration cakes, and piping hot savory feteer.'}
                </p>

                {/* Quick Info Badges */}
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-2.5 sm:gap-3 pt-1 sm:pt-2">
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-xl text-xs font-semibold text-stone-700 border border-stone-200 shadow-xs">
                    <Flame className="w-4 h-4 text-[#B4963C]" />
                    <span>{isAr ? 'سمن بلدي طبيعي 100%' : '100% Pure Butter Ghee'}</span>
                  </div>
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-white rounded-xl text-xs font-semibold text-stone-700 border border-stone-200 shadow-xs">
                    <Award className="w-4 h-4 text-[#B4963C]" />
                    <span>{isAr ? 'خبرة أكثر من 25 عاماً' : '25+ Years of Excellence'}</span>
                  </div>
                </div>
              </div>

              {/* Visual Showcase Card */}
              <div className="relative w-full max-w-sm">
                <div className="relative rounded-2xl sm:rounded-3xl overflow-hidden border-2 border-[#B4963C]/30 shadow-xl shadow-[#B4963C]/10 group bg-white">
                  <img
                    src="https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80"
                    alt="Étoile Signature Torte"
                    className="w-full h-56 sm:h-72 object-cover transform group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-stone-950/80 via-stone-950/20 to-transparent"></div>
                  <div className="absolute bottom-4 inset-x-4">
                    <span className="text-[10px] font-bold bg-[#B4963C] text-white px-2.5 py-0.5 rounded-md uppercase tracking-wider">
                      {isAr ? 'الأكثر طلباً' : 'Bestseller'}
                    </span>
                    <h3 className="text-base sm:text-lg font-bold text-white mt-1">
                      {isAr ? 'تورتة فور سيزونز الفاخرة' : 'Four Seasons Luxury Torte'}
                    </h3>
                    <p className="text-xs text-[#FAF0CA] font-mono font-bold mt-0.5">
                      480 {isAr ? 'ج.م' : 'EGP'}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Dynamic Category Navigation Tabs */}
          <CategoryTabs
            categories={ETOILE_CATEGORIES}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
            language={language}
            items={menuItems}
            recentOrdersCount={recentOrders.length}
          />

          {/* View Toggle: Recent Orders View VS Menu Items View */}
          {selectedCategory === 'recent_orders' ? (
            <RecentOrdersView
              orders={mergedRecentOrders}
              language={language}
              onReorder={handleReorderPastOrder}
              onViewReceipt={(order) => setConfirmedOrder(order)}
              onExploreMenu={() => setSelectedCategory('all')}
              onClearHistory={handleClearCustomerOrders}
            />
          ) : (
            <>
              {/* Instant Search Bar & Filter Chips */}
              <SearchBar
                searchQuery={searchQuery}
                onSearchChange={setSearchQuery}
                language={language}
                activeFilter={activeFilter}
                onFilterChange={setActiveFilter}
              />

              {/* Menu Items Grid */}
              <main className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-4 sm:py-6 flex-1 w-full">
                <div className="flex items-center justify-between mb-4">
                  <h2 className="text-base sm:text-xl font-black text-stone-900 flex items-center gap-2">
                    <span>
                      {ETOILE_CATEGORIES.find((c) => c.id === selectedCategory)?.name[language]}
                    </span>
                    <span className="text-xs text-stone-500 font-normal">
                      ({filteredMenuItems.length} {isAr ? 'صنف متوفر' : 'items'})
                    </span>
                  </h2>
                </div>

                {filteredMenuItems.length === 0 ? (
                  <div className="bg-white rounded-2xl sm:rounded-3xl p-8 sm:p-12 text-center border border-stone-200 shadow-sm space-y-3">
                    <Utensils className="w-10 h-10 sm:w-12 sm:h-12 text-stone-400 mx-auto" />
                    <h3 className="text-base font-bold text-stone-800">
                      {isAr ? 'لا توجد أصناف تطابق بحثك' : 'No items match your search'}
                    </h3>
                    <p className="text-xs text-stone-500">
                      {isAr ? 'جرب البحث بكلمات أخرى أو تصفح باقي الأقسام' : 'Try searching for other keywords'}
                    </p>
                    <button
                      onClick={() => {
                        setSearchQuery('');
                        setActiveFilter(null);
                        setSelectedCategory('all');
                      }}
                      className="px-5 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl text-xs font-bold transition shadow-sm cursor-pointer"
                    >
                      {isAr ? 'عرض جميع الأصناف' : 'Show All Items'}
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-5 md:gap-6">
                    {filteredMenuItems.map((item) => {
                      const inCartCount = cartItems
                        .filter((ci) => ci.menuItem.id === item.id)
                        .reduce((acc, ci) => acc + ci.quantity, 0);

                      return (
                        <ProductCard
                          key={item.id}
                          item={item}
                          language={language}
                          quantityInCart={inCartCount}
                          onAddToCart={handleAddToCart}
                          onIncrement={handleIncrement}
                          onDecrement={handleDecrement}
                          onRateItem={handleRateItem}
                        />
                      );
                    })}
                  </div>
                )}
              </main>
            </>
          )}

          {/* Floating Cart Bar (Bottom) */}
          <FloatingCartBar
            totalItemsCount={totalCartCount}
            totalPrice={totalCartPrice}
            onOpenCart={() => setIsCartOpen(true)}
            language={language}
          />

          {/* Expandable Cart Modal (Without Payment Methods) */}
          {isCartOpen && (
            <CartModal
              isOpen={isCartOpen}
              onClose={() => setIsCartOpen(false)}
              cartItems={cartItems}
              onIncrement={(ci) => handleAddToCart(ci.menuItem, ci.selectedSize)}
              onDecrement={(ci) => handleDecrement(ci.menuItem, ci.selectedSize)}
              onRemoveItem={handleRemoveCartItem}
              onClearCart={handleClearCart}
              language={language}
              onOrderSuccess={(order) => {
                saveCustomerRecentOrder(order);
                setRecentOrders((prev) => [order, ...prev.filter((o) => o.id !== order.id)]);
                setOrders((prev) => [order, ...prev.filter((o) => o.id !== order.id)]);
                setMenuItems(getStoredMenu());
                setConfirmedOrder(order);
              }}
            />
          )}

          {/* Order Confirmation Modal with Confetti & Invoice # */}
          {confirmedOrder && (
            <OrderConfirmationModal
              order={confirmedOrder}
              onClose={() => setConfirmedOrder(null)}
              language={language}
            />
          )}

          {/* Branch Contact Drawer */}
          {isBranchesOpen && (
            <BranchContactDrawer
              isOpen={isBranchesOpen}
              onClose={() => setIsBranchesOpen(false)}
              language={language}
            />
          )}

          {/* Gemini AI Concierge Chat Drawer */}
          {isAIChatOpen && (
            <AIChatDrawer
              isOpen={isAIChatOpen}
              onClose={() => setIsAIChatOpen(false)}
              language={language}
            />
          )}

          {/* Luxury Light Theme Footer */}
          <footer className="bg-white border-t border-stone-200 text-stone-600 py-6 sm:py-8 px-3 sm:px-4 md:px-6 mt-8 sm:mt-12 pb-24 sm:pb-8 shadow-sm w-full">
            <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4 sm:gap-6">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 text-[#B4963C] border border-[#B4963C]/20 flex items-center justify-center font-serif font-black text-xl">
                  É
                </div>
                <div>
                  <h3 className="text-stone-900 font-bold text-sm">
                    {ETOILE_BRAND.name[language]}
                  </h3>
                  <p className="text-xs text-stone-500">
                    {ETOILE_BRAND.slogan[language]}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-6 text-xs">
                <a
                  href={`tel:${ETOILE_BRAND.hotline}`}
                  className="hover:text-[#B4963C] font-bold flex items-center gap-1.5 transition"
                >
                  <Phone className="w-3.5 h-3.5 text-[#B4963C]" />
                  <span>16312</span>
                </a>
                <button
                  onClick={() => setIsBranchesOpen(true)}
                  className="hover:text-[#B4963C] flex items-center gap-1.5 transition cursor-pointer"
                >
                  <MapPin className="w-3.5 h-3.5 text-[#B4963C]" />
                  <span>{isAr ? 'فروعنا' : 'Branches'}</span>
                </button>
                <a
                  href={ETOILE_BRAND.social.website}
                  target="_blank"
                  rel="noreferrer"
                  className="hover:text-[#B4963C] flex items-center gap-1.5 transition"
                >
                  <Globe className="w-3.5 h-3.5 text-[#B4963C]" />
                  <span>etoileeg.online</span>
                </a>
              </div>

              {/* Clean Customer Footer: No staff or POS buttons visible to customers */}
              <div className="text-xs text-stone-400 font-medium text-center md:text-end">
                <span>© {new Date().getFullYear()} {isAr ? 'حلواني إيتوال • جميع الحقوق محفوظة' : 'Étoile Patisserie • All rights reserved'}</span>
              </div>
            </div>
          </footer>
        </div>
      )}

      {/* Global Staff POS Login & User Switching Modal */}
      {isStaffLoginOpen && (
        <StaffLoginModal
          isOpen={isStaffLoginOpen}
          onClose={() => setIsStaffLoginOpen(false)}
          onSuccess={(user) => handleStaffLoginSuccess(user)}
          language={language}
        />
      )}
    </div>
  );
}
