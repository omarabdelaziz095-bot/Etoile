import React, { useState } from 'react';
import { X, Lock, ShieldCheck, AlertCircle, CheckCircle2 } from 'lucide-react';
import { Language, StaffUser } from '../../types';
import {
  authenticateStaffPIN,
  setCurrentStaffUser,
} from '../../services/staffUserService';

interface StaffLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (user: StaffUser) => void;
  language: Language;
}

export const StaffLoginModal: React.FC<StaffLoginModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  language,
}) => {
  const isAr = language === 'ar';
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [authenticatedUser, setAuthenticatedUser] = useState<StaffUser | null>(null);

  if (!isOpen) return null;

  const handleVerifyPin = (inputPin: string) => {
    // Authenticate PIN
    const user = authenticateStaffPIN(inputPin);
    if (user) {
      setError(null);
      setAuthenticatedUser(user);
      setCurrentStaffUser(user);
      setTimeout(() => {
        onSuccess(user);
        onClose();
        setPin('');
        setAuthenticatedUser(null);
      }, 500);
    } else {
      setError(
        isAr
          ? 'رمز PIN غير صالح، أو تم تعطيل هذا الحساب'
          : 'Invalid staff PIN or account is inactive'
      );
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleVerifyPin(pin);
  };

  const handleQuickKey = (num: string) => {
    if (pin.length < 4) {
      const nextPin = pin + num;
      setPin(nextPin);
      setError(null);
      if (nextPin.length === 4) {
        handleVerifyPin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-sm bg-white border border-stone-200 rounded-3xl shadow-2xl p-5 sm:p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 end-4 p-1.5 rounded-full text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center space-y-1.5 mb-5">
          <div className="w-12 h-12 rounded-2xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center mx-auto shadow-xs">
            <Lock className="w-6 h-6 stroke-[2.2]" />
          </div>
          <h3 className="text-lg font-black text-stone-900 font-serif">
            {isAr ? 'بوابة الكاشير والصلاحيات' : 'Cashier & Staff POS Portal'}
          </h3>
          <p className="text-xs text-stone-500 font-medium">
            {isAr ? 'أدخل رمز PIN السري المخصص لموظفي الكاشير' : 'Enter authorized staff 4-digit PIN code'}
          </p>
        </div>

        {error && (
          <div className="mb-4 flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-semibold animate-fadeIn">
            <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
            <span>{error}</span>
          </div>
        )}

        {authenticatedUser && (
          <div className="mb-4 flex items-center gap-2 p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold animate-fadeIn">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
            <span>
              {isAr
                ? `تم تسجيل الدخول: ${authenticatedUser.name.ar} (${authenticatedUser.roleTitle.ar})`
                : `Logged in: ${authenticatedUser.name.en} (${authenticatedUser.roleTitle.en})`}
            </span>
          </div>
        )}

        {/* Masked PIN Dots Display */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="flex justify-center gap-3 py-1">
            {[0, 1, 2, 3].map((i) => (
              <div
                key={i}
                className={`w-12 h-12 rounded-2xl border-2 flex items-center justify-center text-2xl font-bold font-mono transition-all duration-150 ${
                  pin.length > i
                    ? 'border-[#B4963C] bg-[#B4963C]/10 text-[#B4963C] shadow-xs'
                    : 'border-stone-200 bg-stone-50 text-stone-300'
                }`}
              >
                {pin.length > i ? '•' : ''}
              </div>
            ))}
          </div>

          {/* Numeric Keypad */}
          <div className="grid grid-cols-3 gap-2">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9', 'C', '0', '⌫'].map((k) => (
              <button
                key={k}
                type="button"
                onClick={() => {
                  if (k === 'C') setPin('');
                  else if (k === '⌫') handleBackspace();
                  else handleQuickKey(k);
                }}
                className="py-3 rounded-xl bg-stone-50 hover:bg-stone-100 text-stone-800 font-bold text-base border border-stone-200/80 transition active:scale-95 cursor-pointer shadow-2xs"
              >
                {k}
              </button>
            ))}
          </div>

          <button
            type="submit"
            disabled={pin.length < 4}
            className="w-full py-3.5 bg-[#B4963C] hover:bg-[#9E8232] disabled:opacity-40 text-white font-bold rounded-xl text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-[#B4963C]/20"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>{isAr ? 'تأكيد الدخول للكاشير' : 'Verify & Enter POS'}</span>
          </button>
        </form>
      </div>
    </div>
  );
};
