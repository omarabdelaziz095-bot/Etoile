import React from 'react';
import { Phone, Globe, MapPin, Sparkles, Clock } from 'lucide-react';
import { Language } from '../../types';
import { ETOILE_BRAND } from '../../data/etoileMenuData';

interface HeaderProps {
  language: Language;
  onToggleLanguage: () => void;
  onOpenBranches: () => void;
  onOpenAIChat: () => void;
  onOpenStaffModal?: () => void;
  onOpenRecentOrders?: () => void;
  recentOrdersCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  language,
  onToggleLanguage,
  onOpenBranches,
  onOpenAIChat,
  onOpenStaffModal,
  onOpenRecentOrders,
  recentOrdersCount = 0,
}) => {
  const isAr = language === 'ar';
  const logoClickRef = React.useRef<{ count: number; timer: any }>({ count: 0, timer: null });

  // Discreet secret 3-tap on the Étoile logo to open staff modal without exposing buttons to customers
  const handleLogoClick = () => {
    logoClickRef.current.count += 1;
    if (logoClickRef.current.timer) clearTimeout(logoClickRef.current.timer);
    if (logoClickRef.current.count >= 3) {
      logoClickRef.current.count = 0;
      if (onOpenStaffModal) onOpenStaffModal();
    } else {
      logoClickRef.current.timer = setTimeout(() => {
        logoClickRef.current.count = 0;
      }, 1000);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#B4963C]/20 shadow-sm w-full">
      {/* Top announcement bar - 100% customer facing */}
      <div className="bg-[#B4963C] text-white text-[11px] sm:text-xs py-1.5 px-3 sm:px-4 md:px-6 font-semibold flex items-center justify-between shadow-xs">
        <span className="hidden md:inline-block">
          ✨ {isAr ? 'صناع السعادة منذ 1999 • حلواني إيتوال' : 'Makers of Happiness Since 1999 • Étoile Egypt'}
        </span>
        <div className="flex items-center gap-3 mx-auto md:mx-0">
          <a
            href={`tel:${ETOILE_BRAND.hotline}`}
            className="flex items-center gap-1.5 hover:underline font-bold tracking-wider"
          >
            <Phone className="w-3.5 h-3.5 fill-current" />
            <span>{isAr ? 'الخط الساخن:' : 'Hotline:'} {ETOILE_BRAND.hotline}</span>
          </a>
          <span className="opacity-50">|</span>
          <button
            onClick={onOpenBranches}
            className="hover:underline flex items-center gap-1 font-medium cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5" />
            <span>{isAr ? 'فروعنا' : 'Branches'}</span>
          </button>
        </div>
      </div>

      {/* Main Luxury Header - White & Gold with fluid responsive margins */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-2.5 sm:py-3 flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand identity & Logo */}
        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
          <div
            className="relative group cursor-pointer shrink-0"
            onClick={handleLogoClick}
            title={ETOILE_BRAND.name[language]}
          >
            <div className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl sm:rounded-2xl bg-gradient-to-br from-[#B4963C] via-[#C9AB4F] to-[#9B7F2D] p-0.5 shadow-md shadow-[#B4963C]/20 flex items-center justify-center transform transition group-hover:scale-105">
              <div className="w-full h-full bg-white rounded-[10px] sm:rounded-[14px] flex flex-col items-center justify-center text-[#B4963C]">
                <span className="text-lg sm:text-xl font-bold font-serif leading-none">É</span>
                <span className="text-[6px] sm:text-[7px] tracking-widest text-[#B4963C] font-bold uppercase">Étoile</span>
              </div>
            </div>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <h1 className="text-base sm:text-xl md:text-2xl font-black tracking-tight text-stone-900 font-serif truncate">
                {ETOILE_BRAND.name[language]}
              </h1>
              <span className="text-[9px] sm:text-[10px] bg-[#B4963C]/10 text-[#B4963C] border border-[#B4963C]/30 px-1.5 sm:px-2 py-0.5 rounded-full font-mono font-bold shrink-0">
                QR MENU
              </span>
            </div>
            <p className="text-[10px] sm:text-xs text-[#B4963C] font-bold tracking-wide truncate">
              {ETOILE_BRAND.slogan[language]}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-1.5 sm:gap-2 md:gap-3 shrink-0">
          {/* Recent Orders Button */}
          {onOpenRecentOrders && (
            <button
              onClick={onOpenRecentOrders}
              className="relative flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-stone-50 hover:bg-stone-100 border border-stone-200 text-stone-700 hover:text-stone-950 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer shadow-2xs"
              title={isAr ? 'طلباتي السابقة' : 'My Recent Orders'}
            >
              <Clock className="w-3.5 h-3.5 text-[#B4963C]" />
              <span className="hidden sm:inline">{isAr ? 'طلباتي' : 'Orders'}</span>
              {recentOrdersCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-[#B4963C] text-white text-[9px] font-mono font-bold flex items-center justify-center">
                  {recentOrdersCount}
                </span>
              )}
            </button>
          )}

          {/* AI Concierge Trigger */}
          <button
            onClick={onOpenAIChat}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-[#B4963C]/10 hover:bg-[#B4963C]/20 border border-[#B4963C]/30 text-[#B4963C] rounded-xl text-xs sm:text-sm font-bold transition shadow-xs hover:scale-[1.02] active:scale-[0.98] cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#B4963C] animate-pulse" />
            <span className="hidden md:inline">{isAr ? 'الشيف إيتوال الذكي' : 'AI Concierge'}</span>
          </button>

          {/* Language Toggle (AR / EN) */}
          <button
            onClick={onToggleLanguage}
            className="flex items-center gap-1 px-2.5 sm:px-3 py-1.5 bg-stone-100 hover:bg-stone-200 border border-stone-200 text-stone-700 rounded-xl text-xs sm:text-sm font-bold transition hover:border-[#B4963C]/40 cursor-pointer"
            title={isAr ? 'Switch to English' : 'التحويل للغة العربية'}
          >
            <Globe className="w-3.5 h-3.5 text-[#B4963C]" />
            <span className="font-mono text-xs sm:text-sm">{isAr ? 'EN' : 'عربي'}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
