import React, { useState } from 'react';
import {
  Clock,
  RotateCcw,
  ReceiptText,
  ShoppingBag,
  CheckCircle2,
  Timer,
  UtensilsCrossed,
  Trash2,
  ArrowRight,
  ArrowLeft,
  ChevronDown,
  ChevronUp,
  AlertCircle,
  Sparkles,
} from 'lucide-react';
import { Order, OrderStatus, Language } from '../../types';

interface RecentOrdersViewProps {
  orders: Order[];
  language: Language;
  onReorder: (order: Order) => void;
  onViewReceipt: (order: Order) => void;
  onExploreMenu: () => void;
  onClearHistory: () => void;
}

export const RecentOrdersView: React.FC<RecentOrdersViewProps> = ({
  orders,
  language,
  onReorder,
  onViewReceipt,
  onExploreMenu,
  onClearHistory,
}) => {
  const isAr = language === 'ar';
  const ArrowBack = isAr ? ArrowLeft : ArrowRight;
  const [expandedOrders, setExpandedOrders] = useState<Record<string, boolean>>({});
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  const toggleExpand = (id: string) => {
    setExpandedOrders((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Status configuration
  const getStatusBadge = (status: OrderStatus) => {
    switch (status) {
      case 'new':
        return {
          label: isAr ? 'طلب جديد (تم الإرسال)' : 'New Order (Sent)',
          bg: 'bg-amber-50 text-amber-700 border-amber-200',
          dot: 'bg-amber-500 animate-pulse',
          icon: Clock,
        };
      case 'preparing':
        return {
          label: isAr ? 'قيد التجهيز بالمطبخ' : 'In Kitchen Prep',
          bg: 'bg-blue-50 text-blue-700 border-blue-200',
          dot: 'bg-blue-500 animate-spin',
          icon: Timer,
        };
      case 'completed':
        return {
          label: isAr ? 'تم التسليم بنجاح' : 'Completed',
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          dot: 'bg-emerald-500',
          icon: CheckCircle2,
        };
      case 'cancelled':
        return {
          label: isAr ? 'ملغي' : 'Cancelled',
          bg: 'bg-rose-50 text-rose-700 border-rose-200',
          dot: 'bg-rose-500',
          icon: AlertCircle,
        };
      default:
        return {
          label: isAr ? 'قيد المعالجة' : 'Processing',
          bg: 'bg-stone-50 text-stone-600 border-stone-200',
          dot: 'bg-[#B4963C]',
          icon: Clock,
        };
    }
  };

  // Format order date & time cleanly
  const formatOrderTime = (timestamp: number | string) => {
    try {
      const date = new Date(timestamp);
      const isToday = new Date().toDateString() === date.toDateString();
      const timeStr = date.toLocaleTimeString(isAr ? 'ar-EG' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
      });
      if (isToday) {
        return `${isAr ? 'اليوم' : 'Today'}, ${timeStr}`;
      }
      const dateStr = date.toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
        month: 'short',
        day: 'numeric',
      });
      return `${dateStr} • ${timeStr}`;
    } catch {
      return String(timestamp);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto px-3 sm:px-4 md:px-6 py-6 sm:py-8 space-y-6">
      {/* Top Banner / Breadcrumb */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white p-4 sm:p-6 rounded-2xl sm:rounded-3xl border border-stone-200 shadow-xs">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center shrink-0 border border-[#B4963C]/20">
            <Clock className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-stone-900 font-serif">
                {isAr ? 'طلباتي السابقة من هذا الجهاز' : 'My Recent Orders'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-[#B4963C]/10 text-[#B4963C] text-xs font-mono font-bold border border-[#B4963C]/20">
                {orders.length}
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              {isAr
                ? 'سجل الطلبات المحفوظ محلياً على جهازك مع إمكانية متابعة الحالة وإعادة الطلب فوراً'
                : 'Orders placed from this device with live status & instant reorder'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-center">
          <button
            onClick={onExploreMenu}
            className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-700 hover:text-stone-900 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
          >
            <ShoppingBag className="w-3.5 h-3.5 text-[#B4963C]" />
            <span>{isAr ? 'تصفح المنيو' : 'Browse Menu'}</span>
          </button>

          {orders.length > 0 && (
            <button
              onClick={() => setShowClearConfirm(true)}
              className="p-2 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition cursor-pointer"
              title={isAr ? 'مسح سجل الطلبات' : 'Clear order history'}
            >
              <Trash2 className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Confirmation to clear history */}
      {showClearConfirm && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 animate-fadeIn">
          <div className="flex items-center gap-2 text-xs font-semibold text-rose-800">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>
              {isAr
                ? 'هل أنت متأكد من رغبتك في مسح سجل طلباتك السابقة من هذا الجهاز؟'
                : 'Are you sure you want to clear your recent orders history on this device?'}
            </span>
          </div>
          <div className="flex items-center gap-2 self-end sm:self-auto">
            <button
              onClick={() => setShowClearConfirm(false)}
              className="px-3 py-1.5 bg-white border border-stone-200 text-stone-700 rounded-xl text-xs font-bold hover:bg-stone-50 cursor-pointer"
            >
              {isAr ? 'إلغاء' : 'Cancel'}
            </button>
            <button
              onClick={() => {
                onClearHistory();
                setShowClearConfirm(false);
              }}
              className="px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold cursor-pointer"
            >
              {isAr ? 'تأكيد المسح' : 'Yes, Clear'}
            </button>
          </div>
        </div>
      )}

      {/* Empty State */}
      {orders.length === 0 ? (
        <div className="bg-white rounded-3xl p-8 sm:p-12 text-center border border-stone-200 shadow-xs space-y-4">
          <div className="w-20 h-20 rounded-full bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center mx-auto shadow-inner">
            <ShoppingBag className="w-10 h-10 stroke-[1.8]" />
          </div>

          <div className="max-w-md mx-auto space-y-2">
            <h3 className="text-lg font-black text-stone-900 font-serif">
              {isAr ? 'لا توجد طلبات سابقة على هذا الجهاز' : 'No Recent Orders on this Device'}
            </h3>
            <p className="text-xs sm:text-sm text-stone-500 leading-relaxed">
              {isAr
                ? 'عند إرسال أي طلب جديد من هذا المتصفح، سيظهر هنا تلقائياً ليمكنك متابعة حالة التحضير أو إعادة طلبه بنقرة واحدة.'
                : 'Any order placed from this browser will appear here automatically so you can track kitchen progress or reorder in one click.'}
            </p>
          </div>

          <div className="pt-2">
            <button
              onClick={onExploreMenu}
              className="inline-flex items-center gap-2 px-6 py-3.5 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-2xl text-sm transition shadow-lg shadow-[#B4963C]/25 cursor-pointer transform hover:scale-[1.02] active:scale-[0.98]"
            >
              <Sparkles className="w-4 h-4 text-[#FAF0CA]" />
              <span>{isAr ? 'تصفح قائمة إيتوال واطلب الآن' : 'Browse Étoile Menu & Order'}</span>
              <ArrowBack className="w-4 h-4" />
            </button>
          </div>
        </div>
      ) : (
        /* Orders List */
        <div className="space-y-4">
          {orders.map((order) => {
            const statusConfig = getStatusBadge(order.status);
            const StatusIcon = statusConfig.icon;
            const isExpanded = expandedOrders[order.id] ?? true; // Default expanded for great UX

            return (
              <div
                key={order.id || order.invoiceNumber}
                className="bg-white rounded-2xl sm:rounded-3xl border border-stone-200 shadow-xs hover:shadow-md transition-all duration-200 overflow-hidden"
              >
                {/* Order Card Header */}
                <div className="p-4 sm:p-5 border-b border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-stone-50/50">
                  <div className="flex items-center gap-3">
                    {/* Invoice Badge */}
                    <div className="px-3 py-1.5 rounded-xl bg-white border border-[#B4963C]/40 shadow-2xs text-center">
                      <span className="text-[10px] uppercase font-bold text-stone-400 block leading-tight">
                        {isAr ? 'فاتورة' : 'Invoice'}
                      </span>
                      <span className="text-base font-black font-mono text-[#B4963C]">
                        {order.invoiceNumber}
                      </span>
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs sm:text-sm font-bold text-stone-900">
                          {order.diningMode === 'dine_in'
                            ? `${isAr ? 'صالة • طاولة' : 'Dine-In • Table'} #${order.tableNumber || '—'}`
                            : `${isAr ? 'تيك أواي •' : 'Takeaway •'} ${order.customerName || (isAr ? 'عميل' : 'Customer')}`}
                        </span>
                      </div>
                      <p className="text-[11px] text-stone-500 font-medium mt-0.5">
                        {formatOrderTime(order.createdAt)}
                      </p>
                    </div>
                  </div>

                  {/* Status Badge */}
                  <div className="flex items-center gap-2 self-start sm:self-center">
                    <span
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold border ${statusConfig.bg}`}
                    >
                      <span className={`w-2 h-2 rounded-full ${statusConfig.dot}`}></span>
                      <StatusIcon className="w-3.5 h-3.5" />
                      <span>{statusConfig.label}</span>
                    </span>

                    <button
                      onClick={() => toggleExpand(order.id)}
                      className="p-1.5 rounded-xl text-stone-400 hover:text-stone-700 hover:bg-stone-100 transition cursor-pointer"
                      title={isExpanded ? (isAr ? 'طي' : 'Collapse') : (isAr ? 'توسيع' : 'Expand')}
                    >
                      {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Items Breakdown (Collapsible) */}
                {isExpanded && (
                  <div className="p-4 sm:p-5 space-y-3">
                    {/* Takeaway Cashier Guidance Notice */}
                    {order.diningMode === 'takeaway' && (
                      <div className="p-3 bg-gradient-to-r from-amber-50 to-white border border-[#B4963C]/40 rounded-xl flex items-start gap-2.5 text-xs text-stone-800 shadow-2xs">
                        <div className="w-6 h-6 rounded-lg bg-[#B4963C] text-white flex items-center justify-center shrink-0 mt-0.5">
                          <ShoppingBag className="w-3.5 h-3.5" />
                        </div>
                        <div className="leading-relaxed">
                          <span className="font-bold text-stone-900 block mb-0.5">
                            {isAr ? 'تنبيه استلام التيك أواي:' : 'Takeaway Pickup Notice:'}
                          </span>
                          {isAr ? (
                            <>
                              يرجى إبراز رقم الفاتورة (<span className="font-mono font-black text-[#B4963C] px-1 py-0.2 bg-[#B4963C]/10 rounded">{order.invoiceNumber}</span>) للكاشير أو إبلاغه بالرقم لإنهاء وتأكيد طلبك.
                            </>
                          ) : (
                            <>
                              Please show your invoice number (<span className="font-mono font-black text-[#B4963C] px-1 py-0.2 bg-[#B4963C]/10 rounded">{order.invoiceNumber}</span>) to the cashier or inform the cashier to finalize your order.
                            </>
                          )}
                        </div>
                      </div>
                    )}

                    <div className="space-y-2">
                      {order.items.map((line, idx) => (
                        <div
                          key={idx}
                          className="flex items-center justify-between text-xs py-1.5 border-b border-stone-100 last:border-b-0"
                        >
                          <div className="flex items-center gap-2.5">
                            <span className="w-6 h-6 rounded-lg bg-stone-100 text-[#B4963C] font-mono font-bold flex items-center justify-center shrink-0 border border-stone-200">
                              {line.quantity}×
                            </span>
                            <div>
                              <span className="font-bold text-stone-800">
                                {line.title[language]}
                              </span>
                              {line.selectedSize && (
                                <span className="text-[11px] text-stone-500 font-medium ms-1.5">
                                  ({line.selectedSize})
                                </span>
                              )}
                              {line.notes && (
                                <p className="text-[10px] text-stone-400 italic">
                                  {line.notes}
                                </p>
                              )}
                            </div>
                          </div>
                          <span className="font-mono font-bold text-stone-900 shrink-0">
                            {line.totalPrice} {isAr ? 'ج.م' : 'EGP'}
                          </span>
                        </div>
                      ))}
                    </div>

                    {/* Special Notes if any */}
                    {order.specialNotes && (
                      <div className="p-2.5 bg-amber-50/70 rounded-xl border border-amber-200/80 text-[11px] text-amber-900">
                        <span className="font-bold">{isAr ? 'ملاحظات التحضير: ' : 'Cooking Notes: '}</span>
                        <span>{order.specialNotes}</span>
                      </div>
                    )}

                    {/* Financial Summary */}
                    <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                      <div className="text-stone-500 font-medium">
                        <span>{isAr ? 'شامل ضريبة القيمة المضافة 14% (' : 'Includes 14% VAT ('}</span>
                        <span className="font-mono">{order.tax} {isAr ? 'ج.م' : 'EGP'}</span>
                        <span>)</span>
                      </div>

                      <div className="flex items-center gap-1.5 text-sm sm:text-base font-black text-stone-900">
                        <span>{isAr ? 'الإجمالي:' : 'Total:'}</span>
                        <span className="font-mono text-[#B4963C] text-base sm:text-lg">
                          {order.total} {isAr ? 'ج.م' : 'EGP'}
                        </span>
                      </div>
                    </div>

                    {/* Order Action Buttons */}
                    <div className="pt-3 flex flex-wrap items-center justify-end gap-2.5 border-t border-stone-100">
                      <button
                        onClick={() => onViewReceipt(order)}
                        className="flex-1 sm:flex-initial px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                      >
                        <ReceiptText className="w-3.5 h-3.5 text-[#B4963C]" />
                        <span>{isAr ? 'عرض الإيصال' : 'View Receipt'}</span>
                      </button>

                      <button
                        onClick={() => onReorder(order)}
                        className="flex-1 sm:flex-initial px-4 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer shadow-md shadow-[#B4963C]/20 transform active:scale-95"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>{isAr ? 'إعادة طلب هذه الأصناف' : 'Reorder Items'}</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
