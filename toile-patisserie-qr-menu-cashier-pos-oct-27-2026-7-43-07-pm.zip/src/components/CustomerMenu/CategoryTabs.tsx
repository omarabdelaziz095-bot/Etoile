import React, { useRef } from 'react';
import {
  Sparkles,
  Percent,
  Sun,
  Cake,
  Heart,
  Wheat,
  Flame,
  Utensils,
  Sandwich,
  IceCream,
  Coffee,
  Clock,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { CategoryInfo, Language, MenuItem } from '../../types';

interface CategoryTabsProps {
  categories: CategoryInfo[];
  selectedCategory: string;
  onSelectCategory: (categoryId: string) => void;
  language: Language;
  items: MenuItem[];
  recentOrdersCount?: number;
}

const ICON_MAP: Record<string, React.ElementType> = {
  Sparkles,
  Percent,
  Sun,
  Cake,
  Heart,
  Wheat,
  Flame,
  Utensils,
  Sandwich,
  IceCream,
  Coffee,
};

export const CategoryTabs: React.FC<CategoryTabsProps> = ({
  categories,
  selectedCategory,
  onSelectCategory,
  language,
  items,
  recentOrdersCount = 0,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const isAr = language === 'ar';

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const offset = direction === 'left' ? -220 : 220;
      scrollRef.current.scrollBy({ left: offset, behavior: 'smooth' });
    }
  };

  // Helper to count items in each category
  const getItemCount = (categoryId: string) => {
    if (categoryId === 'all') return items.length;
    return items.filter(item => item.category === categoryId).length;
  };

  return (
    <div className="relative sticky top-[64px] sm:top-[73px] z-30 bg-white/95 backdrop-blur-md border-b border-stone-200 py-2 sm:py-2.5 px-2 sm:px-4 md:px-6 shadow-2xs">
      <div className="max-w-7xl mx-auto flex items-center relative">
        {/* Scroll Left Button */}
        <button
          onClick={() => scroll('left')}
          className="hidden md:flex items-center justify-center w-8 h-8 rounded-full bg-white hover:bg-stone-50 text-stone-700 hover:text-[#B4963C] border border-stone-200 absolute -left-2 z-10 transition shadow-md cursor-pointer"
          aria-label="Scroll left"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {/* Categories container */}
        <div
          ref={scrollRef}
          className="flex items-center gap-1.5 sm:gap-2 overflow-x-auto no-scrollbar scroll-smooth py-1 px-0.5 w-full"
          style={{ scrollbarWidth: 'none', msOverflowStyle: 'none' }}
        >
          {/* Recent Orders History Tab */}
          <button
            onClick={() => onSelectCategory('recent_orders')}
            className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-200 select-none cursor-pointer shrink-0 ${
              selectedCategory === 'recent_orders'
                ? 'bg-[#B4963C] text-white shadow-md shadow-[#B4963C]/30 scale-[1.02] font-bold'
                : 'bg-white hover:bg-stone-50 text-stone-700 hover:text-stone-950 border border-stone-200/90 shadow-2xs'
            }`}
          >
            <Clock
              className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${
                selectedCategory === 'recent_orders'
                  ? 'text-white'
                  : 'text-[#B4963C]'
              }`}
            />
            <span>{isAr ? 'طلباتي السابقة' : 'Recent Orders'}</span>
            {recentOrdersCount > 0 ? (
              <span
                className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono font-bold ${
                  selectedCategory === 'recent_orders'
                    ? 'bg-white/25 text-white'
                    : 'bg-[#B4963C] text-white'
                }`}
              >
                {recentOrdersCount}
              </span>
            ) : null}
          </button>

          {/* Separator */}
          <div className="h-5 w-px bg-stone-200 shrink-0 mx-0.5"></div>

          {/* Menu Categories */}
          {categories.map((cat) => {
            const isSelected = selectedCategory === cat.id;
            const IconComponent = ICON_MAP[cat.icon] || Sparkles;
            const count = getItemCount(cat.id);

            return (
              <button
                key={cat.id}
                onClick={() => onSelectCategory(cat.id)}
                className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-3.5 py-1.5 sm:py-2 rounded-xl text-xs sm:text-sm font-semibold whitespace-nowrap transition-all duration-200 select-none cursor-pointer shrink-0 ${
                  isSelected
                    ? 'bg-[#B4963C] text-white shadow-md shadow-[#B4963C]/30 scale-[1.02] font-bold'
                    : 'bg-white hover:bg-stone-50 text-stone-700 hover:text-stone-950 border border-stone-200/90 shadow-2xs'
                }`}
              >
                <IconComponent
                  className={`w-3.5 h-3.5 sm:w-4 sm:h-4 ${
                    isSelected
                      ? 'text-white fill-current'
                      : 'text-[#B4963C]'
                  }`}
                />
                <span>{cat.name[language]}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.5 rounded-full font-mono ${
                    isSelected
                      ? 'bg-white/25 text-white font-bold'
                      : 'bg-stone-100 text-stone-500'
                  }`}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>

        {/* Scroll Right Button */}
        <button
          onClick={() => scroll('right')}
          className="hidden md:flex items-center justify-center w-8 h-8 rounded-full bg-white hover:bg-stone-50 text-stone-700 hover:text-[#B4963C] border border-stone-200 absolute -right-2 z-10 transition shadow-md cursor-pointer"
          aria-label="Scroll right"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
