import React, { useState, useRef, useEffect } from 'react';
import { X, Sparkles, Send, Bot, User, Loader2, ArrowRight } from 'lucide-react';
import { Language } from '../../types';

interface Message {
  role: 'user' | 'model';
  content: string;
}

interface AIChatDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const AIChatDrawer: React.FC<AIChatDrawerProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  const isAr = language === 'ar';

  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      content: isAr
        ? 'أهلاً بك في حلواني إيتوال! 🎂 أنا "الشيف إيتوال الذكي" خبير الحلويات والمخبوزات. كيف يمكنني مساعدتك اليوم؟ يمكنك سؤالي عن ترشيحات لعيد ميلاد، أفضل بوكس شرقي للمناسبات، أو أصناف القشطوطة والتريند!'
        : 'Welcome to Étoile Patisserie! 🎂 I am "Chef Étoile", your dessert sommelier and concierge. How can I help you pick the sweetest treats today?',
    },
  ]);

  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    if (isOpen) {
      scrollToBottom();
    }
  }, [messages, isLoading, isOpen]);

  if (!isOpen) return null;

  const quickPrompts = isAr
    ? [
        'اقترح تورتة لعيد ميلاد 10 أفراد؟',
        'عايز أفضل بوكس حلويات شرقية للضيافة',
        'ما هي مكونات القشطوطة باللوتس والمانجو؟',
        'اقترح عشاء حادق لشخصين من الفطير والحواوشي',
      ]
    : [
        'Recommend a birthday cake for 10 people',
        'Best oriental dessert box for guests?',
        'What is in the Lotus & Mango Qashtoota?',
        'Suggest savory dinner for two with Feteer & Hawawshi',
      ];

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || isLoading) return;

    const newMessages: Message[] = [...messages, { role: 'user', content: text }];
    setMessages(newMessages);
    setInput('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages,
          language,
        }),
      });

      if (res.ok) {
        const data = await res.json();
        setMessages((prev) => [
          ...prev,
          { role: 'model', content: data.reply || (isAr ? 'عفواً، لم يصل رد.' : 'No response generated.') },
        ]);
      } else {
        throw new Error('Chat API returned an error');
      }
    } catch (err) {
      console.error('Chat error:', err);
      const fallbackReply = isAr
        ? 'اختيار ممتاز! نوصيك بتجربة تورتة فور سيزونز مقاس 24 لأنها ترضي جميع الأذواق (لوتس، نوتيلا، كيندر، وفواكه)، وبجانبها قشطوطة المانجو الطبيعية المنعشة وبسبوسة إيتوال بالسمن البلدي. هل تود تفاصيل عن الأسعار؟'
        : 'A wonderful choice! We warmly recommend our Four Seasons Torte (Size 24) satisfying every taste, paired with fresh Mango Qashtoota and classic Plain Basbousa.';
      setMessages((prev) => [...prev, { role: 'model', content: fallbackReply }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-md bg-white border-s border-stone-200 h-full flex flex-col shadow-2xl animate-slideLeft">
        {/* Chat Header */}
        <div className="p-4 border-b border-stone-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#B4963C] text-white flex items-center justify-center shadow-xs">
              <Bot className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h3 className="text-sm font-bold text-stone-900">
                  {isAr ? 'الشيف إيتوال الذكي' : 'Chef Étoile AI'}
                </h3>
                <span className="text-[10px] bg-[#B4963C]/10 text-[#B4963C] px-2 py-0.5 rounded-full font-mono font-bold">
                  Gemini 3.8 Flash
                </span>
              </div>
              <p className="text-xs text-[#B4963C] font-semibold">
                {isAr ? 'خبير الحلويات والمناسبات' : 'Pastry & Dessert Sommelier'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Conversation Thread */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-[#FAFAF8]">
          {messages.map((m, idx) => (
            <div
              key={idx}
              className={`flex items-start gap-2.5 ${
                m.role === 'user' ? 'justify-end' : 'justify-start'
              }`}
            >
              {m.role === 'model' && (
                <div className="w-7 h-7 rounded-lg bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center shrink-0 mt-0.5">
                  <Bot className="w-4 h-4" />
                </div>
              )}

              <div
                className={`max-w-[85%] rounded-2xl p-3 text-xs sm:text-sm leading-relaxed ${
                  m.role === 'user'
                    ? 'bg-[#B4963C] text-white font-medium rounded-te-none shadow-sm'
                    : 'bg-white text-stone-900 border border-stone-200/90 rounded-ts-none shadow-2xs'
                }`}
              >
                {m.content}
              </div>

              {m.role === 'user' && (
                <div className="w-7 h-7 rounded-lg bg-stone-200 text-stone-700 flex items-center justify-center shrink-0 mt-0.5">
                  <User className="w-4 h-4" />
                </div>
              )}
            </div>
          ))}

          {isLoading && (
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center shrink-0">
                <Bot className="w-4 h-4" />
              </div>
              <div className="bg-white text-stone-600 border border-stone-200 rounded-2xl p-3 text-xs flex items-center gap-2 shadow-2xs">
                <Loader2 className="w-4 h-4 animate-spin text-[#B4963C]" />
                <span>{isAr ? 'الشيف إيتوال يجهز النصيحة...' : 'Chef Étoile is thinking...'}</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Quick Suggestion Pills */}
        <div className="p-2.5 border-t border-stone-100 bg-white">
          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-1">
            {quickPrompts.map((prompt, i) => (
              <button
                key={i}
                onClick={() => handleSend(prompt)}
                disabled={isLoading}
                className="px-2.5 py-1.5 rounded-xl bg-stone-50 hover:bg-stone-100 text-stone-700 hover:text-[#B4963C] border border-stone-200 text-[11px] font-medium whitespace-nowrap transition cursor-pointer flex items-center gap-1 shrink-0"
              >
                <span>{prompt}</span>
                <ArrowRight className="w-3 h-3 text-[#B4963C]" />
              </button>
            ))}
          </div>
        </div>

        {/* Input Field */}
        <div className="p-3 border-t border-stone-100 bg-white">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={isAr ? 'اسأل الشيف إيتوال...' : 'Ask Chef Étoile...'}
              disabled={isLoading}
              className="flex-1 px-4 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 placeholder-stone-400 text-xs sm:text-sm focus:border-[#B4963C] outline-none shadow-2xs"
            />
            <button
              type="submit"
              disabled={isLoading || !input.trim()}
              className="p-2.5 bg-[#B4963C] hover:bg-[#9E8232] disabled:opacity-50 text-white rounded-xl transition cursor-pointer font-bold shadow-xs"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};
