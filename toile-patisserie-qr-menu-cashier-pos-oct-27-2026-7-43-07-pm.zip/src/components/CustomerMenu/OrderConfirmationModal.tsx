import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import {
  CheckCircle2,
  Clock,
  Printer,
  X,
  ShoppingBag,
  UtensilsCrossed,
  Receipt,
  Info,
} from 'lucide-react';
import { Order, Language } from '../../types';
import { ETOILE_BRAND } from '../../data/etoileMenuData';
import { printThermalReceipt } from '../../services/printService';

interface OrderConfirmationModalProps {
  order: Order | null;
  onClose: () => void;
  language: Language;
}

export const OrderConfirmationModal: React.FC<OrderConfirmationModalProps> = ({
  order,
  onClose,
  language,
}) => {
  const isAr = language === 'ar';

  // Trigger celebration confetti when an order is confirmed
  useEffect(() => {
    if (order) {
      try {
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#B4963C', '#C9AB4F', '#9B7F2D', '#ffffff'],
        });
      } catch (e) {}
    }
  }, [order]);

  if (!order) return null;

  const handlePrint = () => {
    printThermalReceipt(order, language);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-lg bg-white border border-stone-200 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* Header Ribbon - Gold & White */}
        <div className="bg-[#B4963C] p-5 text-center text-white relative shadow-sm">
          <button
            onClick={onClose}
            className="absolute top-4 end-4 p-1 rounded-full bg-white/20 hover:bg-white/30 text-white transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
          <div className="w-14 h-14 bg-white text-[#B4963C] rounded-2xl flex items-center justify-center mx-auto mb-2 shadow-md">
            <CheckCircle2 className="w-8 h-8 stroke-[2.5]" />
          </div>
          <h2 className="text-xl sm:text-2xl font-black font-serif">
            {isAr ? 'تم استلام طلبك بنجاح!' : 'Order Placed Successfully!'}
          </h2>
          <p className="text-xs font-medium text-white/90 mt-0.5">
            {isAr ? 'شكراً لاختيارك حلواني إيتوال - صناع السعادة' : 'Thank you for choosing Étoile Patisserie'}
          </p>
        </div>

        {/* Invoice & Status Tracker */}
        <div className="p-5 space-y-4 overflow-y-auto max-h-[75vh] bg-white">
          {/* Invoice Number Badge */}
          <div className="text-center p-4 bg-stone-50 border border-[#B4963C]/30 rounded-2xl shadow-2xs">
            <span className="text-xs text-stone-500 block mb-0.5 uppercase tracking-wider font-semibold">
              {isAr ? 'رقم الفاتورة المرجعي' : 'Sequential Invoice Number'}
            </span>
            <span className="text-3xl font-black font-mono text-[#B4963C] tracking-wider">
              {order.invoiceNumber}
            </span>
            <div className="mt-1 text-xs text-stone-600 flex items-center justify-center gap-2 font-medium">
              <span>
                {order.diningMode === 'dine_in'
                  ? `${isAr ? 'طاولة صالة:' : 'Dine-In Table:'} ${order.tableNumber || '-'}`
                  : `${isAr ? 'تيك أواي للعميل:' : 'Takeaway:'} ${order.customerName || (isAr ? 'عميل' : 'Guest')}`}
              </span>
              <span>•</span>
              <span>
                {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>

          {/* ========================================================
              TAKEAWAY SPECIFIC INSTRUCTION FOR CASHIER FINALIZATION
          ======================================================== */}
          {order.diningMode === 'takeaway' && (
            <div className="p-4 bg-gradient-to-br from-amber-50 via-white to-amber-50/80 border-2 border-[#B4963C] rounded-2xl shadow-sm space-y-2.5">
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#B4963C] text-white flex items-center justify-center shrink-0 shadow-2xs">
                  <ShoppingBag className="w-4 h-4 stroke-[2.5]" />
                </div>
                <div>
                  <h4 className="text-xs sm:text-sm font-black text-stone-900">
                    {isAr ? 'تنبيه استلام طلب التيك أواي' : 'Takeaway Order Instructions'}
                  </h4>
                  <span className="text-[10px] text-[#B4963C] font-bold">
                    {isAr ? 'إجراء مطلوب لإنهاء الطلب' : 'Action Required to Finalize'}
                  </span>
                </div>
              </div>

              <div className="p-3 bg-white rounded-xl border border-[#B4963C]/30 space-y-1.5 shadow-2xs">
                <p className="text-xs text-stone-800 leading-relaxed font-semibold">
                  {isAr ? (
                    <>
                      يرجى التوجه إلى الكاشير وإبراز رقم الفاتورة (
                      <span className="font-mono text-[#B4963C] font-black text-sm px-1.5 py-0.5 bg-[#B4963C]/10 rounded-md">
                        {order.invoiceNumber}
                      </span>
                      ) أو إبلاغ موظف الكاشير بالرقم لإنهاء وتأكيد طلبك واستلامه فور جاهزيته.
                    </>
                  ) : (
                    <>
                      Please show your invoice number (
                      <span className="font-mono text-[#B4963C] font-black text-sm px-1.5 py-0.5 bg-[#B4963C]/10 rounded-md">
                        {order.invoiceNumber}
                      </span>
                      ) to the cashier or inform the cashier of your number to finalize and collect your order.
                    </>
                  )}
                </p>
                <div className="flex items-center justify-between text-[11px] pt-1 border-t border-stone-100 text-stone-500">
                  <span>{isAr ? 'الاسم المدون:' : 'Customer Name:'} <strong>{order.customerName || '-'}</strong></span>
                  {order.customerPhone && (
                    <span>{isAr ? 'الهاتف:' : 'Phone:'} <strong className="font-mono">{order.customerPhone}</strong></span>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* DINE-IN TABLE NOTICE */}
          {order.diningMode === 'dine_in' && (
            <div className="p-3.5 bg-stone-50 border border-stone-200 rounded-2xl flex items-center gap-3 text-xs text-stone-700 font-medium">
              <div className="w-8 h-8 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center shrink-0">
                <UtensilsCrossed className="w-4 h-4" />
              </div>
              <p className="leading-relaxed">
                {isAr
                  ? `طلب صالة على طاولة رقم (${order.tableNumber || '-'}). سيقوم فريق الخدمة بتقديم الطلب لطاولتكم فور الانتهاء من التحضير.`
                  : `Dine-in at Table #${order.tableNumber || '-'}. Staff will deliver your order directly to your table once prepared.`}
              </p>
            </div>
          )}

          {/* Live Kitchen Status */}
          <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center shrink-0">
              <Clock className="w-5 h-5 animate-spin" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-stone-900">
                {isAr ? 'جاري التحضير والتجهيز بالفرع' : 'Sent to Étoile Kitchen'}
              </h4>
              <p className="text-xs text-stone-500">
                {isAr ? 'الوقت المتوقع للتجهيز: 10 - 15 دقيقة' : 'Estimated preparation time: 10 - 15 mins'}
              </p>
            </div>
          </div>

          {/* Items Summary */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              {isAr ? 'تفاصيل الأصناف' : 'Order Items Summary'}
            </h4>
            <div className="bg-stone-50 rounded-2xl p-3.5 border border-stone-200 space-y-2 text-xs">
              {order.items.map((line, idx) => (
                <div key={idx} className="flex justify-between items-center text-stone-800">
                  <div className="flex items-center gap-2">
                    <span className="w-5 h-5 rounded-md bg-white border border-stone-200 text-[#B4963C] font-mono font-bold flex items-center justify-center text-[11px]">
                      {line.quantity}×
                    </span>
                    <span className="font-semibold">{line.title[language] || line.title.ar}</span>
                    {line.selectedSize && (
                      <span className="text-[10px] text-stone-500">({line.selectedSize})</span>
                    )}
                  </div>
                  <span className="font-mono font-bold text-[#B4963C]">
                    {line.totalPrice} {isAr ? 'ج.م' : 'EGP'}
                  </span>
                </div>
              ))}

              <div className="pt-2 border-t border-stone-200 flex justify-between font-bold text-stone-600">
                <span>{isAr ? 'ضريبة القيمة المضافة (14%):' : 'VAT (14%):'}</span>
                <span>{order.tax} {isAr ? 'ج.م' : 'EGP'}</span>
              </div>

              <div className="pt-1 flex justify-between font-black text-sm text-stone-900">
                <span>{isAr ? 'الإجمالي المطلوب:' : 'Total Amount:'}</span>
                <span className="text-[#B4963C] font-mono">{order.total} {isAr ? 'ج.م' : 'EGP'}</span>
              </div>
            </div>
          </div>

          {/* Hotline reminder */}
          <div className="text-center text-xs text-stone-500 pt-1">
            <span>
              {isAr
                ? 'لأي استفسار يرجى التواصل مع الفرع أو الخط الساخن:'
                : 'For inquiries, call hotline:'}
            </span>{' '}
            <a href={`tel:${ETOILE_BRAND.hotline}`} className="text-[#B4963C] font-bold hover:underline">
              {ETOILE_BRAND.hotline}
            </a>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-white border-t border-stone-100 flex items-center gap-3">
          <button
            onClick={handlePrint}
            className="flex-1 py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition cursor-pointer"
          >
            <Printer className="w-4 h-4 text-[#B4963C]" />
            <span>{isAr ? 'طباعة الإيصال 80mm' : 'Print Receipt'}</span>
          </button>

          <button
            onClick={onClose}
            className="flex-1 py-3 px-4 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-1.5 transition cursor-pointer shadow-md shadow-[#B4963C]/20"
          >
            <span>{isAr ? 'العودة للقائمة' : 'Back to Menu'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
