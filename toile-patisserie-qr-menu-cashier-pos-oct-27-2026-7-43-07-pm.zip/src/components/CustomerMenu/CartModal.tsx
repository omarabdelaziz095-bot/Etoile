import React, { useState } from 'react';
import {
  X,
  Plus,
  Minus,
  Trash2,
  UtensilsCrossed,
  ShoppingBag,
  Phone,
  User,
  FileText,
  Send,
  Loader2,
  AlertCircle,
} from 'lucide-react';
import { CartItem, DiningMode, Language, Order } from '../../types';
import { ETOILE_BRAND } from '../../data/etoileMenuData';
import { submitOrder, deductStockForOrder } from '../../services/firebaseService';
import { audioService } from '../../services/audioService';
import { saveCustomerRecentOrder } from '../../services/customerOrdersService';

interface CartModalProps {
  isOpen: boolean;
  onClose: () => void;
  cartItems: CartItem[];
  onIncrement: (cartItem: CartItem) => void;
  onDecrement: (cartItem: CartItem) => void;
  onRemoveItem: (cartItemId: string) => void;
  onClearCart: () => void;
  language: Language;
  onOrderSuccess: (order: Order) => void;
}

export const CartModal: React.FC<CartModalProps> = ({
  isOpen,
  onClose,
  cartItems,
  onIncrement,
  onDecrement,
  onRemoveItem,
  onClearCart,
  language,
  onOrderSuccess,
}) => {
  const isAr = language === 'ar';

  const [diningMode, setDiningMode] = useState<DiningMode>('dine_in');
  const [tableNumber, setTableNumber] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [specialNotes, setSpecialNotes] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  if (!isOpen) return null;

  // Calculations
  const subtotal = cartItems.reduce((acc, item) => acc + item.unitPrice * item.quantity, 0);
  const tax = Math.round(subtotal * ETOILE_BRAND.vatRate);
  const total = subtotal + tax;

  const handleSubmitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);

    if (cartItems.length === 0) {
      setFormError(isAr ? 'السلة فارغة!' : 'Your cart is empty!');
      return;
    }

    if (diningMode === 'dine_in') {
      if (!tableNumber.trim()) {
        setFormError(isAr ? 'برجاء إدخال رقم الطاولة' : 'Please enter your table number');
        return;
      }
    } else {
      if (!customerName.trim()) {
        setFormError(isAr ? 'برجاء إدخال اسم العميل' : 'Please enter customer name');
        return;
      }
      if (!customerPhone.trim() || customerPhone.trim().length < 8) {
        setFormError(
          isAr
            ? 'برجاء إدخال رقم هاتف صحيح للتواصل'
            : 'Please enter a valid contact phone number'
        );
        return;
      }
    }

    setIsSubmitting(true);

    try {
      // Map cart items to order line items
      const orderLineItems = cartItems.map((ci) => ({
        itemId: ci.menuItem.id,
        title: ci.menuItem.title,
        quantity: ci.quantity,
        unitPrice: ci.unitPrice,
        totalPrice: ci.unitPrice * ci.quantity,
        selectedSize: ci.selectedSize ? ci.selectedSize.name[language] : undefined,
        notes: ci.specialInstructions,
      }));

      const newOrder = await submitOrder({
        diningMode,
        tableNumber: diningMode === 'dine_in' ? tableNumber.trim() : undefined,
        customerName: diningMode === 'takeaway' ? customerName.trim() : undefined,
        customerPhone: diningMode === 'takeaway' ? customerPhone.trim() : undefined,
        specialNotes: specialNotes.trim() || undefined,
        items: orderLineItems,
        subtotal,
        tax,
        total,
      });

      // Sound chime
      audioService.playSuccessChime();

      // Clear cart
      onClearCart();
      setIsSubmitting(false);

      // Deduct inventory stock for ordered items
      try {
        await deductStockForOrder(newOrder);
      } catch (e) {
        console.error('Failed to deduct stock for order:', e);
      }

      // Save to device localStorage recent orders
      try {
        saveCustomerRecentOrder(newOrder);
      } catch (e) {
        console.error('Failed to save recent order to device storage:', e);
      }

      onClose();
      onOrderSuccess(newOrder);
    } catch (err: any) {
      console.error('Failed to submit order:', err);
      setIsSubmitting(false);
      setFormError(
        isAr
          ? 'حدث خطأ أثناء إرسال الطلب، تم الحفظ محلياً'
          : 'Error sending order to Firebase, saved locally'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="w-full sm:max-w-xl max-h-[92vh] sm:max-h-[85vh] bg-white border border-stone-200 rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center">
              <ShoppingBag className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h2 className="text-lg font-black text-stone-900">
                {isAr ? 'سلة الطلبات' : 'Your Order Bag'}
              </h2>
              <p className="text-xs text-stone-500 font-medium">
                {cartItems.length} {isAr ? 'أصناف مختارة' : 'items selected'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body (Scrollable) */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-5 bg-white">
          {formError && (
            <div className="flex items-center gap-2 p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-700 text-xs font-semibold">
              <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
              <span>{formError}</span>
            </div>
          )}

          {/* Cart Items List */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              {isAr ? 'الأصناف المختارة' : 'Selected Items'}
            </h3>

            {cartItems.length === 0 ? (
              <div className="text-center py-8 text-stone-400">
                <p className="text-sm font-medium">{isAr ? 'السلة فارغة' : 'Your cart is empty'}</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                {cartItems.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between gap-3 p-3 bg-stone-50 rounded-2xl border border-stone-200/80"
                  >
                    <img
                      src={item.menuItem.image}
                      alt={item.menuItem.title[language]}
                      className="w-14 h-14 rounded-xl object-cover shrink-0 bg-stone-100"
                    />

                    <div className="flex-1 min-w-0">
                      <h4 className="text-sm font-bold text-stone-900 truncate">
                        {item.menuItem.title[language]}
                      </h4>
                      {item.selectedSize && (
                        <span className="text-[11px] text-[#B4963C] font-semibold">
                          {item.selectedSize.name[language]}
                        </span>
                      )}
                      <div className="text-xs font-bold text-[#B4963C] mt-0.5 font-mono">
                        {item.unitPrice} {isAr ? 'ج.م' : 'EGP'}
                      </div>
                    </div>

                    {/* Quantity controls */}
                    <div className="flex items-center gap-1.5 bg-white px-2 py-1 rounded-xl border border-stone-200 shadow-2xs">
                      <button
                        onClick={() => onDecrement(item)}
                        className="w-6 h-6 rounded-lg bg-stone-100 hover:bg-stone-200 text-stone-700 flex items-center justify-center transition cursor-pointer"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="text-xs font-bold text-[#B4963C] min-w-[1.2rem] text-center font-mono">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => onIncrement(item)}
                        className="w-6 h-6 rounded-lg bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold flex items-center justify-center transition cursor-pointer"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Delete item */}
                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="p-1.5 text-stone-400 hover:text-rose-600 transition cursor-pointer"
                      title={isAr ? 'حذف' : 'Remove'}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Dining Mode Selector (Dine-In vs Takeaway) */}
          <div className="space-y-3 pt-2 border-t border-stone-100">
            <h3 className="text-xs font-bold text-stone-500 uppercase tracking-wider">
              {isAr ? 'طريقة الاستلام' : 'Dining Option'}
            </h3>

            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setDiningMode('dine_in')}
                className={`flex items-center justify-center gap-2 p-3.5 rounded-2xl border text-xs sm:text-sm font-bold transition cursor-pointer ${
                  diningMode === 'dine_in'
                    ? 'bg-[#B4963C]/10 border-[#B4963C] text-[#B4963C] shadow-sm shadow-[#B4963C]/10'
                    : 'bg-white border-stone-200 text-stone-600 hover:border-stone-300'
                }`}
              >
                <UtensilsCrossed className="w-4 h-4" />
                <span>{isAr ? 'تناول بالصالة (Dine-In)' : 'Dine-In'}</span>
              </button>

              <button
                type="button"
                onClick={() => setDiningMode('takeaway')}
                className={`flex items-center justify-center gap-2 p-3.5 rounded-2xl border text-xs sm:text-sm font-bold transition cursor-pointer ${
                  diningMode === 'takeaway'
                    ? 'bg-[#B4963C]/10 border-[#B4963C] text-[#B4963C] shadow-sm shadow-[#B4963C]/10'
                    : 'bg-white border-stone-200 text-stone-600 hover:border-stone-300'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>{isAr ? 'تيك أواي / استلام (Takeaway)' : 'Takeaway'}</span>
              </button>
            </div>

            {/* Dining details input */}
            {diningMode === 'dine_in' ? (
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-2">
                <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
                  <span>{isAr ? 'رقم الطاولة *' : 'Table Number *'}</span>
                  <span className="text-[10px] text-[#B4963C] font-semibold">
                    ({isAr ? 'مكتوب على ستيكر الـ QR' : 'Found on table QR sticker'})
                  </span>
                </label>
                <input
                  type="text"
                  required
                  value={tableNumber}
                  onChange={(e) => setTableNumber(e.target.value)}
                  placeholder={isAr ? 'مثال: طاولة 12 أو T-04' : 'e.g. Table 12 or T-04'}
                  className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-stone-900 placeholder-stone-400 text-sm focus:border-[#B4963C] outline-none shadow-2xs"
                />
              </div>
            ) : (
              <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200/80 space-y-3">
                <div>
                  <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5 mb-1">
                    <User className="w-3.5 h-3.5 text-[#B4963C]" />
                    <span>{isAr ? 'اسم العميل *' : 'Customer Name *'}</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder={isAr ? 'الاسم بالكامل' : 'Your full name'}
                    className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-stone-900 placeholder-stone-400 text-sm focus:border-[#B4963C] outline-none shadow-2xs"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5 mb-1">
                    <Phone className="w-3.5 h-3.5 text-[#B4963C]" />
                    <span>{isAr ? 'رقم الموبايل *' : 'Phone Number *'}</span>
                  </label>
                  <input
                    type="tel"
                    required
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="010XXXXXXXX"
                    className="w-full px-3.5 py-2.5 bg-white border border-stone-200 rounded-xl text-stone-900 placeholder-stone-400 text-sm focus:border-[#B4963C] outline-none font-mono shadow-2xs"
                  />
                </div>

                {/* Takeaway Cashier Guidance Notice */}
                <div className="p-3 bg-amber-50/80 border border-[#B4963C]/30 rounded-xl flex items-start gap-2.5 text-xs text-stone-800">
                  <div className="w-5 h-5 rounded-full bg-[#B4963C] text-white flex items-center justify-center shrink-0 mt-0.5">
                    <ShoppingBag className="w-3 h-3" />
                  </div>
                  <p className="leading-relaxed">
                    {isAr
                      ? 'تنبيه: بعد إرسال الطلب، سيظهر لك رقم الفاتورة المرجعي. يرجى إبرازه للكاشير أو إبلاغ موظف الكاشير به لإنهاء طلبك وتأكيده.'
                      : 'Notice: Upon submitting, your invoice number will appear. Please show or inform the cashier to finalize and pick up your order.'}
                  </p>
                </div>
              </div>
            )}

            {/* Special Instructions */}
            <div>
              <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5 mb-1">
                <FileText className="w-3.5 h-3.5 text-[#B4963C]" />
                <span>{isAr ? 'ملاحظات وتجهيزات خاصة (اختياري)' : 'Special Cooking Notes'}</span>
              </label>
              <textarea
                value={specialNotes}
                onChange={(e) => setSpecialNotes(e.target.value)}
                rows={2}
                placeholder={
                  isAr
                    ? 'مثال: السكر خفيف، تقطيع التورتة، زيادة شيدر، تسخين الفطير جيداً...'
                    : 'e.g. Light syrup, slice cake into 12, extra warm feteer...'
                }
                className="w-full px-3.5 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 placeholder-stone-400 text-xs focus:border-[#B4963C] outline-none resize-none shadow-2xs"
              />
            </div>
          </div>

          {/* Pricing & VAT Breakdown */}
          <div className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200 space-y-2 text-xs">
            <div className="flex justify-between text-stone-600 font-medium">
              <span>{isAr ? 'المجموع الفرعي:' : 'Subtotal:'}</span>
              <span className="font-mono font-bold text-stone-800">
                {subtotal} {isAr ? 'ج.م' : 'EGP'}
              </span>
            </div>
            <div className="flex justify-between text-stone-600 font-medium">
              <span>{isAr ? 'ضريبة القيمة المضافة (14% VAT):' : 'VAT (14%):'}</span>
              <span className="font-mono font-bold text-stone-800">
                {tax} {isAr ? 'ج.م' : 'EGP'}
              </span>
            </div>
            <div className="pt-2 border-t border-stone-200 flex justify-between text-sm sm:text-base font-black text-stone-900">
              <span>{isAr ? 'الإجمالي النهائي المطلوب:' : 'Grand Total:'}</span>
              <span className="text-[#B4963C] font-mono">
                {total} {isAr ? 'ج.م' : 'EGP'}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-stone-100 bg-white flex items-center gap-3">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs sm:text-sm font-bold transition cursor-pointer"
          >
            {isAr ? 'متابعة التسوق' : 'Keep Shopping'}
          </button>

          <button
            type="button"
            disabled={isSubmitting || cartItems.length === 0}
            onClick={handleSubmitOrder}
            className="flex-1 py-3.5 px-4 bg-[#B4963C] hover:bg-[#9E8232] disabled:opacity-50 text-white rounded-xl text-sm sm:text-base font-black shadow-lg shadow-[#B4963C]/25 flex items-center justify-center gap-2 transition cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{isAr ? 'جاري إرسال الطلب للفرع...' : 'Sending to Étoile...'}</span>
              </>
            ) : (
              <>
                <Send className="w-5 h-5" />
                <span>{isAr ? 'تأكيد وإرسال الطلب للكاشير' : 'Confirm & Place Order'}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
