import React from 'react';
import { Search, X, Flame, Star, Tag, Award } from 'lucide-react';
import { Language } from '../../types';

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  language: Language;
  activeFilter: string | null;
  onFilterChange: (filter: string | null) => void;
}

export const SearchBar: React.FC<SearchBarProps> = ({
  searchQuery,
  onSearchChange,
  language,
  activeFilter,
  onFilterChange,
}) => {
  const isAr = language === 'ar';

  const filterChips = [
    {
      id: 'discount',
      label: isAr ? 'عروض وخصومات' : 'Discounts & Offers',
      icon: Tag,
      color: 'text-rose-500',
    },
    {
      id: 'top_rated',
      label: isAr ? 'الأعلى تقييماً (4.9+)' : 'Top Rated (4.9+)',
      icon: Star,
      color: 'text-[#B4963C]',
    },
    {
      id: 'bestseller',
      label: isAr ? 'الأكثر مبيعاً' : 'Best Sellers',
      icon: Award,
      color: 'text-[#B4963C]',
    },
    {
      id: 'under_100',
      label: isAr ? 'أقل من 100 ج.م' : 'Under 100 EGP',
      icon: Flame,
      color: 'text-emerald-600',
    },
  ];

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-3 sm:py-4 space-y-2.5 sm:space-y-3 w-full">
      {/* Search Bar Input */}
      <div className="relative">
        <div className="absolute inset-y-0 start-0 flex items-center ps-4 pointer-events-none text-stone-400">
          <Search className="w-5 h-5 text-[#B4963C]" />
        </div>
        <input
          type="text"
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          placeholder={
            isAr
              ? 'ابحث عن صنفك المفضل... بسبوسة، قشطوطة، تورتة، فطير، حواوشي'
              : 'Search for Basbousa, Qashtoota, Torte, Feteer, Hawawshi...'
          }
          className="w-full ps-11 pe-10 py-3.5 bg-white hover:bg-stone-50/50 focus:bg-white text-stone-900 placeholder-stone-400 rounded-2xl border border-stone-200 focus:border-[#B4963C] focus:ring-2 focus:ring-[#B4963C]/20 outline-none text-sm transition shadow-xs"
        />
        {searchQuery && (
          <button
            onClick={() => onSearchChange('')}
            className="absolute inset-y-0 end-0 flex items-center pe-3 text-stone-400 hover:text-stone-700 cursor-pointer"
          >
            <div className="w-6 h-6 rounded-full bg-stone-100 flex items-center justify-center">
              <X className="w-3.5 h-3.5" />
            </div>
          </button>
        )}
      </div>

      {/* Quick Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-0.5">
        <span className="text-xs text-stone-500 font-medium whitespace-nowrap">
          {isAr ? 'تصفية سريعة:' : 'Quick Filter:'}
        </span>
        {filterChips.map((chip) => {
          const isActive = activeFilter === chip.id;
          const Icon = chip.icon;

          return (
            <button
              key={chip.id}
              onClick={() => onFilterChange(isActive ? null : chip.id)}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition cursor-pointer ${
                isActive
                  ? 'bg-[#B4963C] text-white shadow-md shadow-[#B4963C]/25'
                  : 'bg-white hover:bg-stone-50 text-stone-700 border border-stone-200/90 shadow-2xs'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-white' : chip.color}`} />
              <span>{chip.label}</span>
              {isActive && <X className="w-3 h-3 ms-0.5" />}
            </button>
          );
        })}
      </div>
    </div>
  );
};
