import React from 'react';
import { X, Phone, MessageCircle, Globe, MapPin, Clock, ExternalLink } from 'lucide-react';
import { Language } from '../../types';
import { ETOILE_BRANCHES, ETOILE_BRAND } from '../../data/etoileMenuData';

interface BranchContactDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  language: Language;
}

export const BranchContactDrawer: React.FC<BranchContactDrawerProps> = ({
  isOpen,
  onClose,
  language,
}) => {
  if (!isOpen) return null;

  const isAr = language === 'ar';

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-md bg-white border-s border-stone-200 h-full flex flex-col shadow-2xl animate-slideLeft">
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-stone-100 flex items-center justify-between bg-white">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center">
              <Phone className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h3 className="text-base font-bold text-stone-900">
                {isAr ? 'فروع وخدمة عملاء إيتوال' : 'Étoile Branches & Contact'}
              </h3>
              <p className="text-xs text-[#B4963C] font-bold">
                {isAr ? 'الخط الساخن الموحد 16312' : 'Unified Hotline 16312'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Contact Action Buttons */}
        <div className="p-4 border-b border-stone-100 bg-stone-50 grid grid-cols-2 gap-2.5">
          <a
            href={`tel:${ETOILE_BRAND.hotline}`}
            className="flex items-center justify-center gap-2 p-3 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-xl text-xs transition shadow-xs"
          >
            <Phone className="w-4 h-4 fill-current" />
            <span>{isAr ? 'اتصل بـ 16312' : 'Call 16312'}</span>
          </a>

          <a
            href={`https://wa.me/${ETOILE_BRAND.whatsapp}`}
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 p-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-xl text-xs transition shadow-xs"
          >
            <MessageCircle className="w-4 h-4 fill-current" />
            <span>WhatsApp</span>
          </a>
        </div>

        {/* Branches List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-white">
          <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider mb-2">
            {isAr ? 'فروع القاهرة والإسكندرية' : 'Cairo & Alexandria Branches'}
          </h4>

          {ETOILE_BRANCHES.map((branch) => (
            <div
              key={branch.id}
              className="p-3.5 bg-stone-50 rounded-2xl border border-stone-200/80 hover:border-[#B4963C]/40 transition space-y-1.5 shadow-2xs"
            >
              <div className="flex items-start justify-between gap-2">
                <h5 className="text-sm font-bold text-stone-900 flex items-center gap-1.5">
                  <MapPin className="w-4 h-4 text-[#B4963C] shrink-0" />
                  <span>{branch.name[language]}</span>
                </h5>
              </div>

              <p className="text-xs text-stone-600 ps-5 leading-relaxed font-medium">
                {branch.address[language]}
              </p>

              <div className="flex items-center gap-2 text-[11px] text-stone-500 ps-5 pt-1">
                <Clock className="w-3.5 h-3.5 text-[#B4963C]" />
                <span>{branch.hours[language]}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Social Media & Website Footer */}
        <div className="p-4 border-t border-stone-100 bg-stone-50 space-y-2 text-center">
          <div className="flex items-center justify-center gap-4 text-stone-600 font-medium">
            <a
              href={ETOILE_BRAND.social.facebook}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#B4963C] text-xs transition"
            >
              Facebook
            </a>
            <span>•</span>
            <a
              href={ETOILE_BRAND.social.instagram}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#B4963C] text-xs transition"
            >
              Instagram
            </a>
            <span>•</span>
            <a
              href={ETOILE_BRAND.social.tiktok}
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-[#B4963C] text-xs transition"
            >
              TikTok
            </a>
          </div>

          <a
            href={ETOILE_BRAND.social.website}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs text-[#B4963C] hover:underline font-bold"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>etoileeg.online</span>
            <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
};
