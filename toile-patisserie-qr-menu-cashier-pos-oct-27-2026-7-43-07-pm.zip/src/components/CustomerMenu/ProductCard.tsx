import React, { useState } from 'react';
import { Star, Plus, Minus, Clock, Check } from 'lucide-react';
import { MenuItem, Language, ItemSizeVariation } from '../../types';

interface ProductCardProps {
  item: MenuItem;
  language: Language;
  quantityInCart: number;
  onAddToCart: (item: MenuItem, selectedSize?: ItemSizeVariation) => void;
  onIncrement: (item: MenuItem, selectedSize?: ItemSizeVariation) => void;
  onDecrement: (item: MenuItem, selectedSize?: ItemSizeVariation) => void;
  onRateItem: (itemId: string, rating: number) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  item,
  language,
  quantityInCart,
  onAddToCart,
  onIncrement,
  onDecrement,
  onRateItem,
}) => {
  const isAr = language === 'ar';
  const [selectedSize, setSelectedSize] = useState<ItemSizeVariation | undefined>(
    item.sizes && item.sizes.length > 0 ? item.sizes[0] : undefined
  );
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [userRating, setUserRating] = useState<number | null>(null);
  const [hasRated, setHasRated] = useState(false);

  // Dynamic price depending on selected size
  const activePrice = selectedSize ? selectedSize.price : item.price;

  // Stock calculations
  const isTracked = item.trackStock ?? true;
  const currentStock = item.stockQuantity ?? 0;
  const isOutOfStock = !item.available || (isTracked && currentStock <= 0);
  const isLowStock = isTracked && !isOutOfStock && currentStock <= (item.lowStockThreshold ?? 5);

  const handleRate = (stars: number) => {
    setUserRating(stars);
    setHasRated(true);
    onRateItem(item.id, stars);
    setTimeout(() => {
      setShowRatingModal(false);
    }, 1200);
  };

  return (
    <div
      className={`group relative bg-white rounded-2xl border transition-all duration-300 overflow-hidden flex flex-col justify-between ${
        !isOutOfStock
          ? 'border-stone-200/80 hover:border-[#B4963C]/50 shadow-xs hover:shadow-xl hover:shadow-[#B4963C]/10 hover:-translate-y-1'
          : 'border-stone-200 opacity-60 grayscale-[40%]'
      }`}
    >
      {/* Top Image Section */}
      <div className="relative aspect-[4/3] w-full overflow-hidden bg-stone-100 flex items-center justify-center">
        {item.image ? (
          <img
            src={item.image}
            alt={item.title[language]}
            loading="lazy"
            className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
            onError={(e) => {
              (e.target as HTMLImageElement).src =
                'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80';
            }}
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-stone-50 to-stone-100 text-stone-300 select-none">
            <div className="w-14 h-14 rounded-2xl bg-[#B4963C]/10 border border-[#B4963C]/20 flex items-center justify-center">
              <span className="text-2xl font-serif text-[#B4963C] font-black">É</span>
            </div>
            <span className="text-[11px] text-stone-500 font-semibold mt-2">
              {isAr ? 'حلواني إيتوال' : 'Étoile Patisserie'}
            </span>
          </div>
        )}

        {/* Gradient Overlay for badges */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-black/20"></div>

        {/* Badge (Discount / Best Seller / New) */}
        {item.badge && !isOutOfStock && (
          <div className="absolute top-3 start-3">
            <span
              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold tracking-wide shadow-md ${
                item.badge.type === 'discount'
                  ? 'bg-rose-600 text-white animate-pulse'
                  : item.badge.type === 'new'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-[#B4963C] text-white'
              }`}
            >
              {item.badge[language]}
            </span>
          </div>
        )}

        {/* Low Stock Pill Badge */}
        {isLowStock && (
          <div className="absolute top-3 start-3">
            <span className="px-2.5 py-1 rounded-lg text-[11px] font-bold tracking-wide shadow-md bg-amber-500 text-white flex items-center gap-1 animate-pulse">
              <span>{isAr ? `متبقي ${currentStock} فقط!` : `Only ${currentStock} left!`}</span>
            </span>
          </div>
        )}

        {/* Out of Stock Overlay */}
        {isOutOfStock && (
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-[2px] flex items-center justify-center p-3 text-center">
            <span className="px-3 py-1.5 bg-rose-600 text-white rounded-lg text-xs font-bold shadow-lg">
              {isAr ? 'نفذت الكمية' : 'Sold Out'}
            </span>
          </div>
        )}

        {/* Interactive Star Rating Badge */}
        <button
          onClick={() => setShowRatingModal(true)}
          className="absolute top-3 end-3 flex items-center gap-1 bg-white/95 backdrop-blur-md px-2 py-1 rounded-lg text-xs text-[#B4963C] font-bold border border-[#B4963C]/30 hover:border-[#B4963C] transition cursor-pointer shadow-xs"
          title={isAr ? 'اضغط لتقييم الصنف' : 'Click to rate item'}
        >
          <Star className="w-3.5 h-3.5 fill-[#B4963C] text-[#B4963C]" />
          <span>{item.rating.toFixed(1)}</span>
          <span className="text-[10px] text-stone-500 font-normal">
            ({item.ratingCount})
          </span>
        </button>

        {/* Prep Time indicator */}
        {item.prepTimeMinutes && (
          <div className="absolute bottom-2 start-3 flex items-center gap-1 text-[11px] text-white bg-black/60 px-2 py-0.5 rounded-md backdrop-blur-xs font-medium">
            <Clock className="w-3 h-3 text-[#B4963C]" />
            <span>
              {item.prepTimeMinutes} {isAr ? 'دقيقة' : 'min'}
            </span>
          </div>
        )}
      </div>

      {/* Content Section */}
      <div className="p-4 flex-1 flex flex-col justify-between gap-3">
        <div>
          {/* Subcategory */}
          {item.subCategory && (
            <span className="text-[11px] text-[#B4963C] font-bold tracking-wide uppercase">
              {item.subCategory}
            </span>
          )}

          {/* Title */}
          <h3 className="text-base sm:text-lg font-bold text-stone-900 group-hover:text-[#B4963C] transition-colors line-clamp-1 mt-0.5">
            {item.title[language]}
          </h3>

          {/* Description */}
          <p className="text-xs text-stone-600 line-clamp-2 mt-1 leading-relaxed">
            {item.description[language]}
          </p>
        </div>

        {/* Sizes Selector (if available) */}
        {item.sizes && item.sizes.length > 0 && (
          <div className="space-y-1">
            <label className="text-[11px] text-stone-500 font-semibold">
              {isAr ? 'اختر الحجم:' : 'Select Size:'}
            </label>
            <div className="grid grid-cols-2 gap-1.5">
              {item.sizes.map((sz) => (
                <button
                  key={sz.id}
                  type="button"
                  onClick={() => setSelectedSize(sz)}
                  className={`px-2 py-1.5 rounded-lg text-[11px] font-bold border transition text-center truncate cursor-pointer ${
                    selectedSize?.id === sz.id
                      ? 'bg-[#B4963C]/10 text-[#B4963C] border-[#B4963C]'
                      : 'bg-stone-50 text-stone-700 border-stone-200 hover:border-stone-300'
                  }`}
                >
                  {sz.name[language]}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Price & Add to Cart Controls */}
        <div className="pt-2.5 border-t border-stone-100 flex items-center justify-between gap-2 mt-auto">
          {/* Price */}
          <div>
            <div className="flex items-baseline gap-1">
              <span className="text-lg sm:text-xl font-black text-[#B4963C]">
                {activePrice}
              </span>
              <span className="text-xs text-[#B4963C] font-bold">
                {isAr ? 'ج.م' : 'EGP'}
              </span>
            </div>
            {item.originalPrice && (
              <span className="text-xs text-stone-400 line-through">
                {item.originalPrice} {isAr ? 'ج.م' : 'EGP'}
              </span>
            )}
          </div>

          {/* Action: Add to Cart or Inline Counter */}
          {isOutOfStock ? (
            <span className="px-3 py-1.5 bg-stone-100 text-stone-400 rounded-xl text-xs font-bold border border-stone-200 cursor-not-allowed">
              {isAr ? 'نفذت الكمية' : 'Sold Out'}
            </span>
          ) : (
            <div>
              {quantityInCart > 0 ? (
                <div className="flex items-center gap-1.5 bg-stone-50 border border-[#B4963C]/40 rounded-xl p-1 shadow-xs">
                  <button
                    onClick={() => onDecrement(item, selectedSize)}
                    className="w-7 h-7 rounded-lg bg-white hover:bg-stone-100 text-stone-800 border border-stone-200 flex items-center justify-center transition active:scale-95 cursor-pointer"
                    aria-label="Decrease"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-sm font-bold text-[#B4963C] min-w-[1.2rem] text-center font-mono">
                    {quantityInCart}
                  </span>
                  <button
                    onClick={() => onIncrement(item, selectedSize)}
                    disabled={isTracked && quantityInCart >= currentStock}
                    className="w-7 h-7 rounded-lg bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold flex items-center justify-center transition active:scale-95 cursor-pointer shadow-xs disabled:opacity-40 disabled:cursor-not-allowed"
                    aria-label="Increase"
                    title={isTracked && quantityInCart >= currentStock ? (isAr ? 'أقصى كمية متوفرة بالمخزون' : 'Max stock reached') : undefined}
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => onAddToCart(item, selectedSize)}
                  className="flex items-center gap-1.5 px-3.5 py-2 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl text-xs sm:text-sm font-bold shadow-md shadow-[#B4963C]/25 transition-all hover:scale-[1.02] active:scale-95 cursor-pointer"
                >
                  <Plus className="w-4 h-4 stroke-[3]" />
                  <span>{isAr ? 'أضف' : 'Add'}</span>
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Interactive Rating Modal */}
      {showRatingModal && (
        <div className="absolute inset-0 bg-white/95 backdrop-blur-xs z-20 flex flex-col items-center justify-center p-4 text-center animate-fadeIn border border-[#B4963C]/30 rounded-2xl">
          {hasRated ? (
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto">
                <Check className="w-6 h-6 stroke-[3]" />
              </div>
              <h4 className="text-sm font-bold text-stone-900">
                {isAr ? 'شكراً لتقييمك!' : 'Thank you for your rating!'}
              </h4>
              <p className="text-xs text-[#B4963C] font-bold">
                ⭐ {userRating} / 5
              </p>
            </div>
          ) : (
            <div className="space-y-3 w-full">
              <h4 className="text-xs font-bold text-[#B4963C] uppercase tracking-wider">
                {isAr ? 'تقييم تجربة الصنف' : 'Rate this Item'}
              </h4>
              <p className="text-sm font-bold text-stone-900 line-clamp-1">
                {item.title[language]}
              </p>
              <div className="flex items-center justify-center gap-1.5 py-1">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button
                    key={star}
                    onClick={() => handleRate(star)}
                    className="p-1 hover:scale-125 transition-transform text-stone-300 hover:text-[#B4963C] focus:text-[#B4963C] cursor-pointer"
                  >
                    <Star className="w-6 h-6 fill-current" />
                  </button>
                ))}
              </div>
              <button
                onClick={() => setShowRatingModal(false)}
                className="text-xs text-stone-500 hover:text-stone-900 underline cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
