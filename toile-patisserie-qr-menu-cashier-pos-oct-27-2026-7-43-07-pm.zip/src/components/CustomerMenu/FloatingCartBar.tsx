import React from 'react';
import { ShoppingBag, ChevronRight, ChevronLeft } from 'lucide-react';
import { Language } from '../../types';

interface FloatingCartBarProps {
  totalItemsCount: number;
  totalPrice: number;
  onOpenCart: () => void;
  language: Language;
}

export const FloatingCartBar: React.FC<FloatingCartBarProps> = ({
  totalItemsCount,
  totalPrice,
  onOpenCart,
  language,
}) => {
  if (totalItemsCount <= 0) return null;

  const isAr = language === 'ar';
  const ArrowIcon = isAr ? ChevronLeft : ChevronRight;

  return (
    <div className="fixed bottom-5 inset-x-4 max-w-md mx-auto z-40 animate-bounce-subtle">
      <button
        onClick={onOpenCart}
        className="w-full bg-gradient-to-r from-[#B4963C] via-[#C9AB4F] to-[#B4963C] hover:from-[#9E8232] hover:to-[#9E8232] text-white p-3.5 sm:p-4 rounded-2xl shadow-2xl shadow-[#B4963C]/35 flex items-center justify-between transition-all duration-300 transform active:scale-[0.98] cursor-pointer border border-[#B4963C]/50"
      >
        {/* Left: Cart Bag and Count Badge */}
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-xl bg-white/20 flex items-center justify-center">
            <ShoppingBag className="w-5 h-5 text-white stroke-[2.2]" />
            <span className="absolute -top-1.5 -end-1.5 w-5 h-5 bg-white text-[#B4963C] font-black text-xs rounded-full flex items-center justify-center shadow-md font-mono">
              {totalItemsCount}
            </span>
          </div>

          <div className="text-start">
            <div className="text-xs font-semibold text-white/90 uppercase tracking-wide">
              {isAr ? 'طلبك الحالي' : 'Current Order'}
            </div>
            <div className="text-sm sm:text-base font-black text-white">
              {isAr ? 'استعراض السلة وإتمام الطلب' : 'View Cart & Checkout'}
            </div>
          </div>
        </div>

        {/* Right: Total Price & Arrow */}
        <div className="flex items-center gap-2">
          <div className="text-end">
            <span className="text-base sm:text-lg font-black font-mono">
              {totalPrice.toFixed(0)}
            </span>
            <span className="text-xs font-bold ms-1">
              {isAr ? 'ج.م' : 'EGP'}
            </span>
          </div>

          <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center">
            <ArrowIcon className="w-5 h-5 stroke-[2.5]" />
          </div>
        </div>
      </button>
    </div>
  );
};
