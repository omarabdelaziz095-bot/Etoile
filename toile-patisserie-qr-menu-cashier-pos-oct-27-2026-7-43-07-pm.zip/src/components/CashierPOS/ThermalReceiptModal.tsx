import { X, Printer, ExternalLink } from 'lucide-react';
import { Order, Language } from '../../types';
import { printThermalReceipt, openPrintableReceiptWindow } from '../../services/printService';

interface ThermalReceiptModalProps {
  order: Order | null;
  onClose: () => void;
  language: Language;
}

export const ThermalReceiptModal: React.FC<ThermalReceiptModalProps> = ({
  order,
  onClose,
  language,
}) => {
  if (!order) return null;

  const isAr = language === 'ar';

  const handlePrint = () => {
    printThermalReceipt(order, language);
  };

  const handleOpenWindow = () => {
    openPrintableReceiptWindow(order, language);
  };

  const formattedDate = new Date(order.createdAt).toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
  const formattedTime = new Date(order.createdAt).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-sm bg-white border border-stone-200 rounded-3xl shadow-2xl flex flex-col max-h-[90vh] overflow-hidden">
        {/* Top Control Bar */}
        <div className="p-3.5 bg-white border-b border-stone-100 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Printer className="w-4 h-4 text-[#B4963C]" />
            <h3 className="text-xs font-bold text-stone-900">
              {isAr ? 'معاينة إيصال الطابعة الحرارية (80mm)' : 'Thermal Receipt Preview (80mm)'}
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* The 80mm POS Thermal Receipt Display (Pure Black on Paper White) */}
        <div className="flex-1 overflow-y-auto p-4 bg-stone-50 flex justify-center">
          <div
            id="thermal-receipt-print-area"
            className="w-full max-w-[320px] bg-white text-black p-5 rounded-md shadow-md font-mono text-xs space-y-3 leading-tight select-all border border-stone-300"
            dir="rtl"
          >
            {/* Header */}
            <div className="text-center space-y-1 border-b border-dashed border-stone-400 pb-3">
              <div className="text-lg font-black tracking-wider uppercase font-serif text-[#B4963C]">
                حلواني إيتوال
              </div>
              <div className="text-[11px] font-bold">
                Étoile Patisserie & Bakery
              </div>
              <div className="text-[10px] text-stone-600">
                صناع السعادة منذ 1999 • فرع القاهرة الرئيسي
              </div>
              <div className="text-[10px] font-bold">
                الخط الساخن: 16312 • س.ت: 48920
              </div>
              <div className="text-[9px] text-stone-500">
                رقم التسجيل الضريبي: 512-884-301
              </div>
            </div>

            {/* Invoice Info */}
            <div className="space-y-1 border-b border-dashed border-stone-400 pb-2 text-[11px]">
              <div className="flex justify-between font-bold">
                <span>رقم الفاتورة:</span>
                <span className="text-sm font-black">{order.invoiceNumber}</span>
              </div>
              <div className="flex justify-between">
                <span>التاريخ:</span>
                <span>{formattedDate} {formattedTime}</span>
              </div>
              <div className="flex justify-between font-bold">
                <span>طريقة الطلب:</span>
                <span>
                  {order.diningMode === 'dine_in'
                    ? `صالة (طاولة: ${order.tableNumber})`
                    : `تيك أواي (${order.customerName || 'عميل'})`}
                </span>
              </div>
              {order.customerPhone && (
                <div className="flex justify-between">
                  <span>الهاتف:</span>
                  <span className="font-sans">{order.customerPhone}</span>
                </div>
              )}
              {order.specialNotes && (
                <div className="pt-1 text-[10px] text-stone-700">
                  <span>ملاحظات: {order.specialNotes}</span>
                </div>
              )}
            </div>

            {/* Line Items Table */}
            <div className="space-y-1.5 border-b border-dashed border-stone-400 pb-2 text-[11px]">
              <div className="flex justify-between font-bold border-b border-stone-200 pb-1">
                <span className="w-8">الكمية</span>
                <span className="flex-1 text-start ps-1">الصنف</span>
                <span className="w-14 text-end">الإجمالي</span>
              </div>

              {order.items.map((item, idx) => (
                <div key={idx} className="flex justify-between items-start text-[11px]">
                  <span className="w-8 font-bold">{item.quantity}×</span>
                  <div className="flex-1 text-start ps-1">
                    <div className="font-semibold">{item.title.ar}</div>
                    {item.selectedSize && (
                      <div className="text-[9px] text-stone-600">({item.selectedSize})</div>
                    )}
                  </div>
                  <span className="w-14 text-end font-bold font-mono">
                    {item.totalPrice} ج.م
                  </span>
                </div>
              ))}
            </div>

            {/* Financial Summary */}
            <div className="space-y-1 border-b border-dashed border-stone-400 pb-2 text-[11px]">
              <div className="flex justify-between">
                <span>المجموع الفرعي:</span>
                <span className="font-mono">{order.subtotal} ج.م</span>
              </div>
              <div className="flex justify-between">
                <span>ضريبة القيمة المضافة (14%):</span>
                <span className="font-mono">{order.tax} ج.م</span>
              </div>
              <div className="flex justify-between text-sm font-black pt-1 border-t border-stone-300">
                <span>الإجمالي المطلوب:</span>
                <span className="font-mono">{order.total} ج.م</span>
              </div>
            </div>

            {/* Footer Barcode & Thanks */}
            <div className="text-center pt-2 space-y-1.5">
              <div className="font-mono tracking-widest text-xs border border-stone-400 py-1 bg-stone-50">
                * {order.invoiceNumber.replace('#', '')} *
              </div>
              <p className="text-[10px] font-bold">
                نتمنى لكم تجربة سعيدة ولذيذة دائماً!
              </p>
              <p className="text-[9px] text-stone-500">
                الموقع الإلكتروني: etoileeg.online
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-3.5 bg-white border-t border-stone-100 flex flex-wrap items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex-1 py-3 px-4 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-xl text-xs sm:text-sm flex items-center justify-center gap-2 transition cursor-pointer shadow-md shadow-[#B4963C]/20"
          >
            <Printer className="w-4 h-4" />
            <span>{isAr ? 'طباعة الإيصال فوراً' : 'Print Receipt'}</span>
          </button>

          <button
            onClick={handleOpenWindow}
            className="py-3 px-3.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            title={isAr ? 'فتح في نافذة مستقلة / حفظ PDF' : 'Open in new window / Save PDF'}
          >
            <ExternalLink className="w-4 h-4 text-[#B4963C]" />
            <span className="hidden sm:inline">{isAr ? 'نافذة مستقلة' : 'New Window'}</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition cursor-pointer"
          >
            {isAr ? 'إغلاق' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
