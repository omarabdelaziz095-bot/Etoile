import React, { useState } from 'react';
import { X, CookingPot, Check, Clock, Printer, AlertTriangle } from 'lucide-react';
import { Order, Language } from '../../types';
import { printKitchenSlip } from '../../services/printService';

interface KitchenDisplayModalProps {
  order: Order | null;
  onClose: () => void;
  onMarkReady: (order: Order) => void;
  language: Language;
}

export const KitchenDisplayModal: React.FC<KitchenDisplayModalProps> = ({
  order,
  onClose,
  onMarkReady,
  language,
}) => {
  const isAr = language === 'ar';
  const [checkedItems, setCheckedItems] = useState<Record<number, boolean>>({});

  if (!order) return null;

  const toggleCheck = (idx: number) => {
    setCheckedItems((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  const allItemsChecked = order.items.length > 0 && order.items.every((_, idx) => checkedItems[idx]);

  const handlePrintSlip = () => {
    printKitchenSlip(order, language);
  };

  const minutesElapsed = Math.floor((Date.now() - order.createdAt) / 60000);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
      <div className="w-full max-w-lg bg-white border-2 border-emerald-500 rounded-3xl shadow-2xl overflow-hidden flex flex-col">
        {/* KDS Header */}
        <div className="bg-emerald-600 p-4 border-b border-emerald-700 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white text-emerald-600 flex items-center justify-center font-bold shadow-md">
              <CookingPot className="w-7 h-7" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-2xl font-black font-mono tracking-wider text-white">
                  {order.invoiceNumber}
                </span>
                <span className="text-xs bg-emerald-800 text-white px-2 py-0.5 rounded-md font-bold">
                  {isAr ? 'بون المطبخ' : 'Kitchen Slip'}
                </span>
              </div>
              <p className="text-xs text-emerald-100">
                {order.diningMode === 'dine_in'
                  ? `${isAr ? 'صالة - طاولة' : 'Dine-In Table'}: ${order.tableNumber}`
                  : `${isAr ? 'تيك أواي' : 'Takeaway'}: ${order.customerName || 'عميل'}`}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintSlip}
              className="p-2 rounded-xl bg-white/20 hover:bg-white/30 text-white transition cursor-pointer"
              title={isAr ? 'طباعة بون المطبخ' : 'Print Slip'}
            >
              <Printer className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl text-white/80 hover:text-white hover:bg-white/20 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Elapsed Timer Banner */}
        <div className="bg-stone-50 px-5 py-2.5 border-b border-stone-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-2 text-stone-700 font-mono font-medium">
            <Clock className={`w-4 h-4 ${minutesElapsed > 15 ? 'text-rose-600 animate-spin' : 'text-[#B4963C]'}`} />
            <span>
              {isAr ? 'وقت الطلب:' : 'Order Time:'} {new Date(order.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
            <span>({minutesElapsed} {isAr ? 'دقيقة مضت' : 'min ago'})</span>
          </div>

          {minutesElapsed > 15 && (
            <span className="text-rose-600 font-bold flex items-center gap-1 animate-pulse">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{isAr ? 'تأخير بالتحضير!' : 'Preparation delayed!'}</span>
            </span>
          )}
        </div>

        {/* Cooking notes alert (if present) */}
        {order.specialNotes && (
          <div className="p-3 bg-amber-50 border-b border-amber-200 text-[#B4963C] text-xs font-bold flex items-start gap-2">
            <span className="px-1.5 py-0.5 rounded bg-[#B4963C] text-white font-bold text-[10px]">
              {isAr ? 'ملاحظة خاصة' : 'NOTE'}
            </span>
            <span>{order.specialNotes}</span>
          </div>
        )}

        {/* Checkable Kitchen Items List */}
        <div className="p-5 flex-1 overflow-y-auto space-y-3 bg-white">
          <h4 className="text-xs font-bold text-stone-500 uppercase tracking-wider">
            {isAr ? 'أصناف التحضير (اضغط للتعليم عند الانتهاء)' : 'Preparation Items (Tap to check when ready)'}
          </h4>

          <div className="space-y-2">
            {order.items.map((line, idx) => {
              const isChecked = !!checkedItems[idx];

              return (
                <div
                  key={idx}
                  onClick={() => toggleCheck(idx)}
                  className={`p-4 rounded-2xl border transition-all cursor-pointer flex items-center justify-between gap-3 ${
                    isChecked
                      ? 'bg-stone-100/60 border-stone-200 opacity-50 line-through'
                      : 'bg-stone-50 border-stone-200/90 hover:border-emerald-500'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-7 h-7 rounded-xl flex items-center justify-center font-bold transition ${
                        isChecked
                          ? 'bg-emerald-600 text-white'
                          : 'bg-white text-stone-400 border border-stone-300'
                      }`}
                    >
                      {isChecked && <Check className="w-4 h-4 stroke-[3]" />}
                    </div>

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-lg font-black font-mono text-[#B4963C]">
                          {line.quantity}×
                        </span>
                        <span className="text-base font-bold text-stone-900">
                          {line.title.ar}
                        </span>
                      </div>
                      {line.selectedSize && (
                        <span className="text-xs text-[#B4963C] font-semibold">
                          [{line.selectedSize}]
                        </span>
                      )}
                    </div>
                  </div>

                  <span className="text-xs font-mono font-bold text-stone-400">
                    #{idx + 1}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-white border-t border-stone-100 flex items-center gap-3">
          <button
            onClick={() => onMarkReady(order)}
            className="flex-1 py-3.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-sm transition flex items-center justify-center gap-2 cursor-pointer shadow-md shadow-emerald-600/25 active:scale-95"
          >
            <Check className="w-5 h-5 stroke-[3]" />
            <span>{isAr ? 'جاهز للتسليم (انتهى التحضير)' : 'Mark All Prepared & Ready'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
