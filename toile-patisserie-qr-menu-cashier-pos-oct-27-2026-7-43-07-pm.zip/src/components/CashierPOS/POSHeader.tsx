import React, { useState, useEffect } from 'react';
import {
  Bell,
  Volume2,
  VolumeX,
  Clock,
  Wifi,
  WifiOff,
  LogOut,
  LayoutList,
  CookingPot,
  BarChart3,
  Package,
  Boxes,
  Wand2,
  Globe,
  Share2,
  Check,
  Users,
  Shield,
  UserCheck,
} from 'lucide-react';
import { Language, StaffUser, StaffPermission } from '../../types';
import { audioService } from '../../services/audioService';
import { hasPermission } from '../../services/staffUserService';

export type POSViewTab =
  | 'orders'
  | 'kitchen'
  | 'analytics'
  | 'inventory'
  | 'stock'
  | 'ai_studio'
  | 'users';

interface POSHeaderProps {
  currentTab: POSViewTab;
  onChangeTab: (tab: POSViewTab) => void;
  newOrdersCount: number;
  isFirebaseConnected: boolean;
  onExitPOS: () => void;
  language: Language;
  onToggleLanguage: () => void;
  currentStaffUser: StaffUser | null;
  onSwitchUser: () => void;
}

export const POSHeader: React.FC<POSHeaderProps> = ({
  currentTab,
  onChangeTab,
  newOrdersCount,
  isFirebaseConnected,
  onExitPOS,
  language,
  onToggleLanguage,
  currentStaffUser,
  onSwitchUser,
}) => {
  const isAr = language === 'ar';
  const [timeStr, setTimeStr] = useState('');
  const [isMuted, setIsMuted] = useState(audioService.isMuted);
  const [copiedLink, setCopiedLink] = useState(false);

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeStr(
        now.toLocaleTimeString(isAr ? 'ar-EG' : 'en-US', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      );
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [isAr]);

  const handleToggleMute = () => {
    const muted = audioService.toggleMute();
    setIsMuted(muted);
  };

  const handleCopyPOSUrl = () => {
    const posUrl = `${window.location.origin}/pos.html`;
    navigator.clipboard.writeText(posUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  const allNavTabs: {
    id: POSViewTab;
    permission: StaffPermission;
    label: { ar: string; en: string };
    icon: React.ElementType;
  }[] = [
    { id: 'orders', permission: 'orders', label: { ar: 'موجز الطلبات', en: 'Orders Stream' }, icon: LayoutList },
    { id: 'kitchen', permission: 'kitchen', label: { ar: 'شاشة المطبخ KDS', en: 'Kitchen Display' }, icon: CookingPot },
    { id: 'analytics', permission: 'analytics', label: { ar: 'المبيعات والتقارير', en: 'POS Analytics' }, icon: BarChart3 },
    { id: 'inventory', permission: 'inventory', label: { ar: 'إدارة المنيو', en: 'Menu Inventory' }, icon: Package },
    { id: 'stock', permission: 'stock', label: { ar: 'إدارة المخزون', en: 'Stock Manager' }, icon: Boxes },
    { id: 'ai_studio', permission: 'ai_studio', label: { ar: 'استوديو الحلو الذكي', en: 'AI Pastry Studio' }, icon: Wand2 },
    { id: 'users', permission: 'users', label: { ar: 'المستخدمين والصلاحيات', en: 'Staff & Roles' }, icon: Users },
  ];

  // Filter tabs based on current staff user's assigned permissions
  const authorizedTabs = allNavTabs.filter((tab) => hasPermission(currentStaffUser, tab.permission));

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-stone-200 shadow-xs">
      {/* Top status bar - Light theme */}
      <div className="bg-[#FAFAF8] border-b border-stone-200/90 px-3 sm:px-4 py-1.5 flex flex-wrap items-center justify-between gap-2 text-xs">
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Connection status */}
          <div className="flex items-center gap-1.5">
            {isFirebaseConnected ? (
              <span className="flex items-center gap-1 text-emerald-600 font-semibold">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <Wifi className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Firebase RTDB</span>
                <span>{isAr ? 'متصل' : 'Live'}</span>
              </span>
            ) : (
              <span className="flex items-center gap-1 text-[#B4963C] font-semibold">
                <WifiOff className="w-3.5 h-3.5" />
                <span>{isAr ? 'مزامنة محلية' : 'Local Sync'}</span>
              </span>
            )}
          </div>
          <span className="text-stone-300">|</span>
          <span className="text-stone-600 font-mono font-bold flex items-center gap-1">
            <Clock className="w-3.5 h-3.5 text-[#B4963C]" />
            <span>{timeStr}</span>
          </span>
        </div>

        {/* Staff User & Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Current Staff User Badge & Switcher */}
          {currentStaffUser && (
            <div className="flex items-center gap-2 bg-white border border-stone-200 px-2 py-0.5 rounded-xl shadow-2xs">
              <div
                className="w-5 h-5 rounded-md text-white font-bold text-[10px] flex items-center justify-center shrink-0"
                style={{ backgroundColor: currentStaffUser.avatarColor || '#B4963C' }}
              >
                {currentStaffUser.name.ar.charAt(0)}
              </div>
              <div className="flex items-center gap-1.5">
                <span className="font-bold text-stone-800 text-[11px] max-w-[120px] truncate">
                  {currentStaffUser.name[language] || currentStaffUser.name.ar}
                </span>
                <span
                  className="px-1.5 py-0.2 rounded text-[9px] font-bold uppercase tracking-wider text-white"
                  style={{ backgroundColor: currentStaffUser.avatarColor || '#B4963C' }}
                >
                  {currentStaffUser.roleTitle[language] || currentStaffUser.roleTitle.ar}
                </span>
              </div>
              <button
                onClick={onSwitchUser}
                className="text-[11px] text-[#B4963C] hover:text-[#9E8232] font-bold hover:underline ps-1 cursor-pointer"
                title={isAr ? 'تبديل المستخدم النشط' : 'Switch Active Staff'}
              >
                {isAr ? 'تبديل' : 'Switch'}
              </button>
            </div>
          )}

          <span className="text-stone-300 hidden sm:inline">|</span>

          {/* Direct link copy */}
          <button
            onClick={handleCopyPOSUrl}
            className="hidden md:flex items-center gap-1 text-xs text-[#B4963C] hover:text-[#9E8232] font-semibold bg-white border border-[#B4963C]/30 px-2 py-0.5 rounded-lg shadow-2xs transition cursor-pointer"
            title={isAr ? 'نسخ رابط الكاشير المباشر' : 'Copy Direct POS Link'}
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>{copiedLink ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'رابط /pos' : 'POS Link')}</span>
          </button>

          <span className="text-stone-300 hidden md:inline">|</span>

          {/* Audio toggle */}
          <button
            onClick={handleToggleMute}
            className={`flex items-center gap-1 px-2 py-0.5 rounded transition cursor-pointer ${
              isMuted
                ? 'text-stone-500 bg-stone-100'
                : 'text-[#B4963C] bg-[#B4963C]/10 font-bold'
            }`}
            title={isMuted ? 'Unmute alerts' : 'Mute alerts'}
          >
            {isMuted ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
            <span className="text-[11px] font-semibold hidden sm:inline">{isMuted ? (isAr ? 'صامت' : 'Muted') : (isAr ? 'صوت' : 'Audio')}</span>
          </button>

          {/* Lang toggle */}
          <button
            onClick={onToggleLanguage}
            className="flex items-center gap-1 text-stone-600 hover:text-stone-900 font-semibold cursor-pointer"
          >
            <Globe className="w-3.5 h-3.5 text-[#B4963C]" />
            <span>{isAr ? 'English' : 'عربي'}</span>
          </button>

          <span className="text-stone-300">|</span>

          {/* Exit POS */}
          <button
            onClick={onExitPOS}
            className="flex items-center gap-1 text-rose-600 hover:text-rose-700 font-bold transition cursor-pointer"
            title={isAr ? 'الخروج للمنيو' : 'Exit POS to QR Menu'}
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>{isAr ? 'خروج' : 'Exit'}</span>
          </button>
        </div>
      </div>

      {/* Main POS Navbar */}
      <div className="max-w-7xl mx-auto px-3 sm:px-4 py-2.5 flex flex-col md:flex-row md:items-center justify-between gap-3 overflow-x-auto">
        <div className="flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#B4963C] to-[#9E8232] text-white flex items-center justify-center font-serif font-black text-lg shadow-md">
            É
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-base sm:text-lg font-black text-stone-900">
                {isAr ? 'كاشير إيتوال - لوحة الإدارة والطلبات' : 'Étoile Cashier POS & Orders'}
              </h1>
              <span className="text-[10px] bg-[#B4963C]/10 text-[#B4963C] border border-[#B4963C]/30 px-2 py-0.5 rounded-full font-mono font-bold">
                CASHIER POS
              </span>
            </div>
            <p className="text-xs text-stone-500 font-medium">
              {isAr ? 'نظام استلام ومتابعة فواتير وإدارة منيو حلواني إيتوال' : 'Live Real-time Order Stream & Receipt POS'}
            </p>
          </div>
        </div>

        {/* View mode tabs (Filtered by active permissions) */}
        <div className="flex items-center gap-1 bg-stone-100 p-1 rounded-2xl border border-stone-200 shrink-0 overflow-x-auto max-w-full">
          {authorizedTabs.map((tab) => {
            const isActive = currentTab === tab.id;
            const Icon = tab.icon;

            return (
              <button
                key={tab.id}
                onClick={() => onChangeTab(tab.id)}
                className={`relative flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs sm:text-sm font-bold transition whitespace-nowrap cursor-pointer ${
                  isActive
                    ? 'bg-[#B4963C] text-white shadow-sm shadow-[#B4963C]/25'
                    : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
                }`}
              >
                <Icon className="w-4 h-4 shrink-0" />
                <span>{tab.label[language]}</span>

                {/* Show new order alert badge on Orders tab */}
                {tab.id === 'orders' && newOrdersCount > 0 && (
                  <span className="w-5 h-5 rounded-full bg-rose-600 text-white font-mono text-xs flex items-center justify-center font-black animate-pulse">
                    {newOrdersCount}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>
    </header>
  );
};
