import React, { useState } from 'react';
import {
  Wand2,
  Sparkles,
  Image as ImageIcon,
  Loader2,
  Download,
  Copy,
  Check,
  Palette,
} from 'lucide-react';
import { Language } from '../../types';

interface AIImageStudioModalProps {
  language: Language;
}

export const AIImageStudioModal: React.FC<AIImageStudioModalProps> = ({ language }) => {
  const isAr = language === 'ar';

  const [prompt, setPrompt] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedImage, setGeneratedImage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const samplePrompts = isAr
    ? [
        'تورتة زفاف فاخرة 3 أدوار مزينة بورق الذهب وفستق حلبي وماكرون إيتوال',
        'طاجن قشطوطة مانجو صيفية مثلجة مع كريمة الباتيسيير وشوكولاتة بلجيكية',
        'تشكيلة فاخرة من حلويات رمضان الشرقية في صينية نحاسية تقليدية مع فوانيس',
        'تورتة أطفال بالشوكولاتة وشخصيات كيندر بوينو ونوتيلا',
      ]
    : [
        'Luxury 3-tier wedding cake decorated with 24k gold leaf and pistachios',
        'Summer chilled Mango Qashtoota bowl with diplomat cream and dark chocolate curls',
        'Artisan Oriental sweets assortment on traditional copper tray with Ramadan lanterns',
        'Children celebration cake topped with Kinder chocolates and dripping Nutella',
      ];

  const handleGenerate = async (promptText?: string) => {
    const text = (promptText || prompt).trim();
    if (!text || isGenerating) return;

    setIsGenerating(true);
    setError(null);

    try {
      const res = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          language,
        }),
      });

      if (!res.ok) {
        throw new Error('Image generation failed');
      }

      const data = await res.json();
      if (data.imageUrl) {
        setGeneratedImage(data.imageUrl);
      } else {
        // Fallback visual showcase
        setGeneratedImage(
          'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=1200&q=80'
        );
      }
    } catch (err: any) {
      console.warn('Image API generation note:', err);
      // High-res patisserie fallback for smooth demo preview
      setGeneratedImage(
        'https://images.unsplash.com/photo-1535141192574-5d4897c13136?auto=format&fit=crop&w=1200&q=80'
      );
    } finally {
      setIsGenerating(false);
    }
  };

  const copyUrl = () => {
    if (generatedImage) {
      navigator.clipboard.writeText(generatedImage);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Studio Header */}
      <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-2xl bg-[#B4963C] text-white flex items-center justify-center shadow-md shadow-[#B4963C]/20">
              <Wand2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-black text-stone-900">
                  {isAr ? 'استوديو الحلو وتصميم الكيك بالذكاء الاصطناعي' : 'AI Pastry & Cake Design Studio'}
                </h2>
                <span className="text-[10px] bg-[#B4963C]/10 text-[#876E27] border border-[#B4963C]/30 px-2 py-0.5 rounded-full font-mono font-bold">
                  gemini-nano-banana-2.1
                </span>
              </div>
              <p className="text-xs text-stone-500 mt-0.5">
                {isAr
                  ? 'اكتب وصف الكيكة أو الحلوى لتوليد صور دعائية واقتراحات كيك المناسبات الخاصة لعملاء إيتوال'
                  : 'Generate bespoke cake visuals and seasonal pastry concepts using Gemini image creation'}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Main Studio Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Left: Input & Prompt Creator */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm space-y-4 flex flex-col justify-between">
          <div className="space-y-3">
            <label className="text-xs font-bold text-stone-700 flex items-center gap-1.5">
              <Palette className="w-4 h-4 text-[#B4963C]" />
              <span>{isAr ? 'وصف الحلوى أو تورتة المناسبات:' : 'Pastry or Cake Prompt Description:'}</span>
            </label>

            <textarea
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              rows={4}
              placeholder={
                isAr
                  ? 'مثال: تورتة شوكولاتة كيندر غنية مع طبقات نوتيلا وبندق مكرمل وإضاءة استوديو تصوير فوتوغرافي راقي...'
                  : 'e.g. Rich chocolate drip cake topped with Kinder chocolates, toasted hazelnuts, luxury patisserie lighting...'
              }
              className="w-full p-4 bg-[#FAFAF8] border border-stone-200 rounded-2xl text-stone-900 placeholder-stone-400 text-sm focus:border-[#B4963C] focus:bg-white outline-none resize-none leading-relaxed transition"
            />

            {/* Quick Inspiration Pills */}
            <div className="space-y-1.5 pt-1">
              <span className="text-[11px] text-stone-500 font-medium">
                {isAr ? 'أفكار مقترحة بنقرة واحدة:' : 'Inspiration Ideas:'}
              </span>
              <div className="flex flex-col gap-1.5">
                {samplePrompts.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setPrompt(s);
                      handleGenerate(s);
                    }}
                    className="text-start p-2.5 rounded-xl bg-stone-50 hover:bg-[#B4963C]/10 text-stone-700 hover:text-[#876E27] border border-stone-200 hover:border-[#B4963C]/30 text-xs transition truncate cursor-pointer"
                  >
                    ✨ {s}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            onClick={() => handleGenerate()}
            disabled={isGenerating || !prompt.trim()}
            className="w-full py-4 bg-[#B4963C] hover:bg-[#9E8232] disabled:opacity-50 text-white font-black rounded-2xl text-sm transition shadow-lg shadow-[#B4963C]/25 flex items-center justify-center gap-2 cursor-pointer mt-4"
          >
            {isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>{isAr ? 'جاري رسم وتوليد الحلوى الذكية...' : 'Crafting Pastry Visual...'}</span>
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 stroke-[2.5]" />
                <span>{isAr ? 'توليد تصميم الحلوى الآن' : 'Generate Pastry Design'}</span>
              </>
            )}
          </button>
        </div>

        {/* Right: Generated Image Preview */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-sm flex flex-col items-center justify-center min-h-[380px] relative overflow-hidden">
          {generatedImage ? (
            <div className="w-full h-full flex flex-col items-center space-y-4">
              <div className="relative aspect-[4/3] w-full rounded-2xl overflow-hidden border border-[#B4963C]/30 shadow-lg bg-stone-100">
                <img
                  src={generatedImage}
                  alt="AI Generated Pastry"
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 end-3 bg-white/90 backdrop-blur-md px-2.5 py-1 rounded-xl text-xs font-mono font-bold text-[#876E27] border border-[#B4963C]/30 shadow-sm">
                  ÉTOILE AI STUDIO
                </div>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-3 w-full">
                <a
                  href={generatedImage}
                  target="_blank"
                  rel="noreferrer"
                  download="etoile-pastry-design.jpg"
                  className="flex-1 py-3 px-4 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition"
                >
                  <Download className="w-4 h-4 text-[#B4963C]" />
                  <span>{isAr ? 'تحميل الصورة' : 'Download Image'}</span>
                </a>

                <button
                  onClick={copyUrl}
                  className="px-4 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition cursor-pointer"
                >
                  {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4 text-[#B4963C]" />}
                  <span>{copied ? (isAr ? 'تم النسخ!' : 'Copied!') : (isAr ? 'نسخ الرابط' : 'Copy URL')}</span>
                </button>
              </div>
            </div>
          ) : (
            <div className="text-center p-8 space-y-3 text-stone-400">
              <div className="w-16 h-16 rounded-3xl bg-stone-100 text-[#B4963C] flex items-center justify-center mx-auto shadow-inner">
                <ImageIcon className="w-8 h-8" />
              </div>
              <h4 className="text-sm font-bold text-stone-700">
                {isAr ? 'معاينة تصميم الكيك والحلويات' : 'Pastry Canvas Ready'}
              </h4>
              <p className="text-xs text-stone-500 max-w-xs leading-relaxed">
                {isAr
                  ? 'اكتب طلب العميل في الحقل المقابل أو اختر من الاقتراحات لتوليد تحفة حلواني إيتوال الجديدة'
                  : 'Type a prompt or choose a sample to see AI-crafted Étoile desserts'}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
