import React, { useState, useRef } from 'react';
import {
  Package,
  Plus,
  Search,
  Check,
  X,
  Edit2,
  Eye,
  EyeOff,
  Upload,
  Trash2,
  Image as ImageIcon,
  RotateCcw,
  Sparkles,
  ShieldCheck,
  Camera,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';
import { MenuItem, Language } from '../../types';
import { ETOILE_CATEGORIES } from '../../data/etoileMenuData';
import {
  toggleMenuItemAvailability,
  updateMenuItemDetails,
  addCustomMenuItem,
} from '../../services/firebaseService';

interface MenuInventoryManagerProps {
  menuItems: MenuItem[];
  onUpdateMenu: (items: MenuItem[]) => void;
  language: Language;
  isPOSButtonHiddenOnCustomerMenu?: boolean;
  onToggleHidePOSButton?: (hidden: boolean) => void;
}

export const MenuInventoryManager: React.FC<MenuInventoryManagerProps> = ({
  menuItems,
  onUpdateMenu,
  language,
  isPOSButtonHiddenOnCustomerMenu = false,
  onToggleHidePOSButton,
}) => {
  const isAr = language === 'ar';

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Edit Item Modal State
  const [editingItem, setEditingItem] = useState<MenuItem | null>(null);
  const [editTitleAr, setEditTitleAr] = useState('');
  const [editTitleEn, setEditTitleEn] = useState('');
  const [editDescAr, setEditDescAr] = useState('');
  const [editDescEn, setEditDescEn] = useState('');
  const [editCategory, setEditCategory] = useState('');
  const [editPrice, setEditPrice] = useState<number>(0);
  const [editImage, setEditImage] = useState<string>('');
  const [editPrepTime, setEditPrepTime] = useState<number | undefined>(undefined);
  const [isSaving, setIsSaving] = useState(false);

  // Add Item Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newTitleAr, setNewTitleAr] = useState('');
  const [newTitleEn, setNewTitleEn] = useState('');
  const [newDescAr, setNewDescAr] = useState('');
  const [newDescEn, setNewDescEn] = useState('');
  const [newCategory, setNewCategory] = useState('oriental');
  const [newPrice, setNewPrice] = useState(100);
  const [newImageUrl, setNewImageUrl] = useState('');

  // Hidden file input refs for image upload
  const fileInputRef = useRef<HTMLInputElement>(null);
  const addFileInputRef = useRef<HTMLInputElement>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3000);
  };

  // Toggle availability (Freeze / Enable)
  const handleToggle = async (itemId: string, currentStatus: boolean) => {
    const updated = await toggleMenuItemAvailability(itemId, !currentStatus);
    onUpdateMenu(updated);
    showToast(
      !currentStatus
        ? (isAr ? 'تم تفعيل الصنف وإتاحته للزبائن' : 'Item is now available')
        : (isAr ? 'تم تجميد الصنف وإخفاؤه مؤقتاً' : 'Item frozen from menu')
    );
  };

  // Open Edit Modal for a specific item
  const handleOpenEditModal = (item: MenuItem) => {
    setEditingItem(item);
    setEditTitleAr(item.title.ar);
    setEditTitleEn(item.title.en);
    setEditDescAr(item.description.ar);
    setEditDescEn(item.description.en);
    setEditCategory(item.category);
    setEditPrice(item.price);
    setEditImage(item.image || '');
    setEditPrepTime(item.prepTimeMinutes);
  };

  // Close Edit Modal
  const handleCloseEditModal = () => {
    setEditingItem(null);
    setIsSaving(false);
  };

  // Handle image upload and optimize/compress before saving
  const handleImageFileUpload = (e: React.ChangeEvent<HTMLInputElement>, isForNewItem = false) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      alert(isAr ? 'يرجى اختيار ملف صورة صالح (JPG, PNG, WebP)' : 'Please select a valid image file');
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const rawDataUrl = event.target?.result as string;
      if (!rawDataUrl) return;

      const img = new Image();
      img.onload = () => {
        const MAX_WIDTH = 800;
        const MAX_HEIGHT = 800;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height = Math.round((height * MAX_WIDTH) / width);
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width = Math.round((width * MAX_HEIGHT) / height);
            height = MAX_HEIGHT;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, width, height);
          const compressedDataUrl = canvas.toDataURL('image/jpeg', 0.85);

          if (isForNewItem) {
            setNewImageUrl(compressedDataUrl);
          } else {
            setEditImage(compressedDataUrl);
          }
          showToast(isAr ? 'تم استيراد الصورة وضغطها بنجاح' : 'Photo imported and optimized successfully');
        } else {
          if (isForNewItem) setNewImageUrl(rawDataUrl);
          else setEditImage(rawDataUrl);
        }
      };
      img.onerror = () => {
        alert(isAr ? 'تعذر قراءة ملف الصورة، يرجى اختيار ملف آخر' : 'Could not decode image file');
      };
      img.src = rawDataUrl;
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Remove photo (clear image)
  const handleRemovePhoto = () => {
    setEditImage('');
    showToast(isAr ? 'تم حذف الصورة - سيظهر شعار إيتوال الفاخر' : 'Photo removed - default emblem will show');
  };

  // Save full edits to Firebase & local storage
  const handleSaveItemEdits = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingItem) return;

    if (!editTitleAr.trim()) {
      alert(isAr ? 'يرجى إدخال اسم الصنف بالعربية' : 'Arabic title is required');
      return;
    }

    setIsSaving(true);
    try {
      const updates: Partial<MenuItem> = {
        title: {
          ar: editTitleAr.trim(),
          en: editTitleEn.trim() || editTitleAr.trim(),
        },
        description: {
          ar: editDescAr.trim(),
          en: editDescEn.trim() || editDescAr.trim(),
        },
        category: editCategory,
        price: Number(editPrice),
        image: editImage.trim(),
        prepTimeMinutes: editPrepTime ? Number(editPrepTime) : undefined,
      };

      const updatedMenu = await updateMenuItemDetails(editingItem.id, updates);
      onUpdateMenu(updatedMenu);
      showToast(isAr ? `تم تحديث بيانات "${editTitleAr}" بنجاح!` : `Updated "${editTitleEn || editTitleAr}" successfully!`);
      handleCloseEditModal();
    } catch (err) {
      console.error('Save error:', err);
      alert(isAr ? 'حدث خطأ أثناء الحفظ، يرجى المحاولة مرة أخرى' : 'Failed to save changes');
    } finally {
      setIsSaving(false);
    }
  };

  // Add custom item
  const handleAddNewItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitleAr || !newPrice) return;

    const newItem: MenuItem = {
      id: `custom_${Date.now()}`,
      title: { ar: newTitleAr.trim(), en: newTitleEn.trim() || newTitleAr.trim() },
      description: { ar: newDescAr.trim(), en: newDescEn.trim() || newDescAr.trim() },
      category: newCategory,
      price: Number(newPrice),
      image: newImageUrl.trim() || '',
      rating: 5.0,
      ratingCount: 1,
      available: true,
      badge: { ar: 'صنف جديد', en: 'New Item', type: 'new' },
    };

    const updated = await addCustomMenuItem(newItem);
    onUpdateMenu(updated);
    setShowAddModal(false);
    showToast(isAr ? `تمت إضافة "${newTitleAr}" للمنيو!` : `Added "${newTitleEn || newTitleAr}" to menu!`);
    // Reset form
    setNewTitleAr('');
    setNewTitleEn('');
    setNewDescAr('');
    setNewDescEn('');
    setNewPrice(100);
    setNewImageUrl('');
  };

  // Filter items
  const filteredItems = menuItems.filter((item) => {
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch =
      searchQuery === '' ||
      item.title.ar.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.title.en.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.id.toLowerCase().includes(searchQuery.toLowerCase());

    return matchesCat && matchesSearch;
  });

  return (
    <div className="space-y-5">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 start-1/2 -translate-x-1/2 z-50 bg-stone-900 text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-bold border border-[#B4963C]/40 animate-bounce">
          <Check className="w-4 h-4 text-[#B4963C]" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top action & info bar */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-stone-200 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-stone-900 flex items-center gap-2">
            <Package className="w-5 h-5 text-[#B4963C]" />
            <span>{isAr ? 'إدارة المنيو، تعديل الأسماء والصور والمخزون' : 'Menu Inventory & Item Management'}</span>
          </h2>
          <p className="text-xs text-stone-500 mt-1 font-medium">
            {isAr
              ? 'تعديل أسماء الأصناف (عربي/إنجليزي)، رفع أو حذف الصور، تحديث الأسعار، وتجميد الأصناف غير المتوفرة فورياً'
              : 'Edit item titles, upload/remove photos, update prices, and toggle live availability'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 w-full md:w-auto">
          {/* Production Mode Toggle: Hide POS button from published customer menu */}
          {onToggleHidePOSButton && (
            <button
              onClick={() => onToggleHidePOSButton(!isPOSButtonHiddenOnCustomerMenu)}
              className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl text-xs font-bold transition border cursor-pointer ${
                isPOSButtonHiddenOnCustomerMenu
                  ? 'bg-amber-50 text-[#876E27] border-[#B4963C]/40 hover:bg-amber-100'
                  : 'bg-stone-50 text-stone-600 border-stone-200 hover:bg-stone-100'
              }`}
              title={
                isAr
                  ? 'التحكم في إظهار أو إخفاء زر الكاشير من منيو الزبائن على الطاولات'
                  : 'Toggle Cashier button visibility on customer tables menu'
              }
            >
              <ShieldCheck className="w-4 h-4 text-[#B4963C]" />
              <span>
                {isPOSButtonHiddenOnCustomerMenu
                  ? (isAr ? 'وضع النشر: زر الكاشير مخفي عن الزبائن' : 'Published: POS Hidden from Diners')
                  : (isAr ? 'وضع المعاينة: زر الكاشير ظاهر' : 'Preview: POS Button Visible')}
              </span>
            </button>
          )}

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-xl text-xs sm:text-sm transition cursor-pointer shadow-md shadow-[#B4963C]/20 active:scale-95"
            aria-label={isAr ? 'إضافة صنف جديد للمنيو' : 'Add New Menu Item'}
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>{isAr ? 'إضافة صنف جديد' : 'Add New Item'}</span>
          </button>
        </div>
      </div>

      {/* Publishing Explanation Notice Card */}
      <div className="bg-gradient-to-r from-amber-50/60 via-stone-50 to-white p-4 rounded-2xl border border-[#B4963C]/20 flex items-start gap-3 text-xs text-stone-700">
        <HelpCircle className="w-5 h-5 text-[#B4963C] shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-bold text-stone-900">
            {isAr ? 'معلومة هامة حول وضع النشر وطباعة QR الطاولات:' : 'About Publishing & Table QR Code Menus:'}
          </p>
          <p className="text-stone-600 leading-relaxed">
            {isAr
              ? 'عند نشر المنيو للزبائن عبر رمز الـ QR، يتم إخفاء زر الكاشير تلقائياً من أعلى الصفحة لمنع الزبائن من الدخول إليه. يستطيع طاقم الكاشير الوصول الدائم للوحة عبر الرابط المباشر (/pos) أو (/pos.html) أو من خلال رابط "دخول الكاشير والتحكم" أسفل الفوتر المحمي برمز PIN.'
              : 'When printing QR codes for table diners, the public Cashier button can be hidden from the customer header. Staff can always access the POS dashboard via direct URL (/pos), (/pos.html), or via the PIN-protected Staff Portal link in the footer.'}
          </p>
        </div>
      </div>

      {/* Filter and Category selectors */}
      <div className="flex flex-col sm:flex-row items-center gap-3 bg-white p-3 rounded-2xl border border-stone-200 shadow-xs">
        <div className="relative flex-1 w-full">
          <label htmlFor="inventory-search" className="sr-only">
            {isAr ? 'بحث في أصناف المنيو' : 'Search items'}
          </label>
          <Search className="w-4 h-4 text-stone-400 absolute inset-y-0 start-3 my-auto pointer-events-none" />
          <input
            id="inventory-search"
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={isAr ? 'ابحث باسم الصنف (عربي أو إنجليزي)...' : 'Search by item title or code...'}
            className="w-full ps-9 pe-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder-stone-400 focus:border-[#B4963C] focus:bg-white outline-none transition"
          />
        </div>

        {/* Category select dropdown */}
        <div className="w-full sm:w-auto">
          <label htmlFor="inventory-category-select" className="sr-only">
            {isAr ? 'تصفية حسب القسم' : 'Filter by category'}
          </label>
          <select
            id="inventory-category-select"
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="w-full sm:w-56 px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-800 outline-none focus:border-[#B4963C] font-semibold"
          >
            {ETOILE_CATEGORIES.map((cat) => (
              <option key={cat.id} value={cat.id}>
                {cat.name[language]}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Inventory Items Table with Accessibility */}
      <div className="bg-white rounded-3xl border border-stone-200 overflow-hidden shadow-xs">
        <div className="overflow-x-auto">
          <table className="w-full text-start text-xs sm:text-sm" aria-label={isAr ? 'جدول إدارة أصناف المنيو' : 'Menu Inventory Table'}>
            <thead className="bg-stone-50 text-stone-500 text-[11px] uppercase tracking-wider border-b border-stone-200 font-bold">
              <tr>
                <th scope="col" className="py-3.5 px-4 text-start">{isAr ? 'الصورة والصنف' : 'Item & Photo'}</th>
                <th scope="col" className="py-3.5 px-4 text-start">{isAr ? 'القسم' : 'Category'}</th>
                <th scope="col" className="py-3.5 px-4 text-start">{isAr ? 'السعر (ج.م)' : 'Price (EGP)'}</th>
                <th scope="col" className="py-3.5 px-4 text-center">{isAr ? 'حالة التوافر' : 'Availability'}</th>
                <th scope="col" className="py-3.5 px-4 text-end">{isAr ? 'تعديل وإجراءات' : 'Edit & Actions'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {filteredItems.map((item) => {
                return (
                  <tr
                    key={item.id}
                    className={`hover:bg-stone-50/70 transition ${
                      !item.available ? 'opacity-60 bg-stone-50/40' : ''
                    }`}
                  >
                    {/* Item & Image */}
                    <td className="py-3.5 px-4">
                      <div className="flex items-center gap-3">
                        <div className="relative w-12 h-12 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shrink-0 flex items-center justify-center">
                          {item.image ? (
                            <img
                              src={item.image}
                              alt={item.title[language]}
                              className="w-full h-full object-cover"
                              onError={(e) => {
                                (e.target as HTMLImageElement).src =
                                  'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80';
                              }}
                            />
                          ) : (
                            <div className="w-full h-full flex flex-col items-center justify-center bg-stone-50 text-[#B4963C]">
                              <span className="font-serif font-black text-sm">É</span>
                            </div>
                          )}
                        </div>

                        <div>
                          <div className="font-bold text-stone-900 text-sm flex items-center gap-2">
                            <span>{item.title[language]}</span>
                            {/* Dual language label if available */}
                            {language === 'ar' && item.title.en && item.title.en !== item.title.ar && (
                              <span className="text-[11px] text-stone-400 font-normal">
                                ({item.title.en})
                              </span>
                            )}
                          </div>
                          <div className="text-xs text-stone-500 line-clamp-1 max-w-xs font-medium">
                            {item.description[language] || (isAr ? 'لا يوجد وصف' : 'No description')}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Category */}
                    <td className="py-3 px-4">
                      <span className="px-2.5 py-1 bg-stone-100 text-stone-700 rounded-lg text-xs font-semibold">
                        {ETOILE_CATEGORIES.find((c) => c.id === item.category)?.name[language] || item.category}
                      </span>
                    </td>

                    {/* Price */}
                    <td className="py-3 px-4 font-mono font-black text-[#B4963C] text-sm">
                      {item.price} {isAr ? 'ج.م' : 'EGP'}
                    </td>

                    {/* Live Availability Toggle Switch */}
                    <td className="py-3 px-4 text-center">
                      <button
                        onClick={() => handleToggle(item.id, item.available)}
                        className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                          item.available
                            ? 'bg-emerald-50 text-emerald-700 border border-emerald-200 hover:bg-emerald-100'
                            : 'bg-rose-50 text-rose-700 border border-rose-200 hover:bg-rose-100'
                        }`}
                        aria-label={
                          item.available
                            ? (isAr ? `تجميد صنف ${item.title[language]}` : `Freeze ${item.title[language]}`)
                            : (isAr ? `تفعيل صنف ${item.title[language]}` : `Enable ${item.title[language]}`)
                        }
                      >
                        {item.available ? (
                          <>
                            <Eye className="w-3.5 h-3.5 text-emerald-600" />
                            <span>{isAr ? 'متاح للطلب' : 'Available'}</span>
                          </>
                        ) : (
                          <>
                            <EyeOff className="w-3.5 h-3.5 text-rose-600" />
                            <span>{isAr ? 'مجمد (غير متوفر)' : 'Frozen'}</span>
                          </>
                        )}
                      </button>
                    </td>

                    {/* Actions: Open Full Edit Modal */}
                    <td className="py-3 px-4 text-end">
                      <button
                        onClick={() => handleOpenEditModal(item)}
                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#B4963C]/10 hover:bg-[#B4963C] text-[#876E27] hover:text-white font-bold rounded-xl text-xs transition border border-[#B4963C]/30 shadow-2xs cursor-pointer"
                        aria-label={isAr ? `تعديل صنف ${item.title[language]}` : `Edit ${item.title[language]}`}
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                        <span>{isAr ? 'تعديل الصنف والصورة' : 'Edit Item & Photo'}</span>
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* ========================================================
          COMPREHENSIVE EDIT MENU ITEM MODAL
          Allows editing Item Name (AR & EN), Price, Description,
          and Uploading or Removing Photo.
      ======================================================== */}
      {editingItem && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="edit-dialog-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn overflow-y-auto"
        >
          <div className="w-full max-w-xl bg-white border border-stone-200 rounded-3xl p-6 shadow-2xl relative space-y-5 my-8">
            {/* Close Button */}
            <button
              onClick={handleCloseEditModal}
              className="absolute top-5 end-5 p-2 rounded-full text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
              aria-label={isAr ? 'إغلاق نافذة التعديل' : 'Close edit modal'}
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-[#B4963C]/10 text-[#B4963C] border border-[#B4963C]/20 flex items-center justify-center shadow-xs">
                <Edit2 className="w-5 h-5" />
              </div>
              <div>
                <h3 id="edit-dialog-title" className="text-lg font-black text-stone-900">
                  {isAr ? 'تعديل بيانات الصنف والصورة' : 'Edit Menu Item Details & Photo'}
                </h3>
                <p className="text-xs text-stone-500 font-medium">
                  {isAr
                    ? `تعديل الاسم بالعربي والإنجليزي، الأسعار، ورفع أو حذف الصورة لـ: ${editingItem.title[language]}`
                    : `Update names, pricing, and photo for: ${editingItem.title[language]}`}
                </p>
              </div>
            </div>

            {/* Edit Form */}
            <form onSubmit={handleSaveItemEdits} className="space-y-4 text-xs">
              {/* Photo Management Section */}
              <div className="p-4 bg-stone-50 rounded-2xl border border-stone-200 space-y-3">
                <label className="text-stone-800 font-bold block text-xs">
                  {isAr ? 'إدارة صورة الصنف (رفع صورة من جهازك أو حذفها):' : 'Item Photo Management (Upload or Remove):'}
                </label>

                <div className="flex flex-col sm:flex-row items-center gap-4">
                  {/* Image Preview Box */}
                  <div className="relative w-28 h-28 rounded-2xl overflow-hidden bg-white border-2 border-dashed border-[#B4963C]/40 shadow-xs flex items-center justify-center shrink-0">
                    {editImage ? (
                      <img
                        src={editImage}
                        alt="Preview"
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          (e.target as HTMLImageElement).src =
                            'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80';
                        }}
                      />
                    ) : (
                      <div className="text-center p-2 text-stone-400 space-y-1">
                        <ImageIcon className="w-6 h-6 mx-auto text-[#B4963C]/60" />
                        <span className="text-[10px] block font-semibold text-stone-500">
                          {isAr ? 'بدون صورة' : 'No Photo'}
                        </span>
                        <span className="text-[9px] text-[#B4963C] block font-bold">
                          {isAr ? 'سيظهر شعار إيتوال' : 'Étoile emblem'}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Photo Action Buttons */}
                  <div className="space-y-2 flex-1 w-full">
                    {/* Hidden Native File Input */}
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageFileUpload(e, false)}
                      className="hidden"
                      id="edit-file-upload"
                      aria-label={isAr ? 'اختر صورة من جهازك' : 'Choose photo from device'}
                    />

                    <div className="flex flex-wrap items-center gap-2">
                      {/* Upload Photo Button */}
                      <button
                        type="button"
                        onClick={() => fileInputRef.current?.click()}
                        className="flex-1 min-w-[140px] py-2.5 px-3 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-xl transition flex items-center justify-center gap-1.5 shadow-xs cursor-pointer"
                        aria-label={isAr ? 'رفع صورة جديدة من الجهاز' : 'Upload photo from device'}
                      >
                        <Upload className="w-4 h-4" />
                        <span>{isAr ? 'رفع صورة من جهازك' : 'Upload Photo'}</span>
                      </button>

                      {/* Remove Photo Button */}
                      {editImage && (
                        <button
                          type="button"
                          onClick={handleRemovePhoto}
                          className="py-2.5 px-3 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold rounded-xl transition border border-rose-200 flex items-center gap-1.5 cursor-pointer"
                          aria-label={isAr ? 'حذف صورة الصنف' : 'Remove photo'}
                        >
                          <Trash2 className="w-4 h-4 text-rose-600" />
                          <span>{isAr ? 'حذف الصورة' : 'Remove'}</span>
                        </button>
                      )}
                    </div>

                    {/* Direct Image URL input */}
                    <div className="pt-1">
                      <label htmlFor="edit-image-url" className="text-[11px] text-stone-500 font-semibold block mb-1">
                        {isAr ? 'أو ضع رابط صورة مباشر (URL):' : 'Or paste direct Image URL:'}
                      </label>
                      <input
                        id="edit-image-url"
                        type="url"
                        value={editImage}
                        onChange={(e) => setEditImage(e.target.value)}
                        placeholder="https://images.unsplash.com/..."
                        className="w-full px-3 py-1.5 bg-white border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-mono text-xs"
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Title Inputs (Arabic & English) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="edit-title-ar" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'اسم الصنف بالعربية *' : 'Item Title (Arabic) *'}
                  </label>
                  <input
                    id="edit-title-ar"
                    type="text"
                    required
                    value={editTitleAr}
                    onChange={(e) => setEditTitleAr(e.target.value)}
                    placeholder="مثال: تورتة لوتس فاخرة"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] focus:bg-white font-medium text-xs sm:text-sm transition"
                  />
                </div>

                <div>
                  <label htmlFor="edit-title-en" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'اسم الصنف بالإنجليزية *' : 'Item Title (English) *'}
                  </label>
                  <input
                    id="edit-title-en"
                    type="text"
                    value={editTitleEn}
                    onChange={(e) => setEditTitleEn(e.target.value)}
                    placeholder="e.g. Lotus Deluxe Torte"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] focus:bg-white font-medium text-xs sm:text-sm transition"
                  />
                </div>
              </div>

              {/* Description Inputs (Arabic & English) */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="edit-desc-ar" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'الوصف بالعربية' : 'Description (Arabic)'}
                  </label>
                  <textarea
                    id="edit-desc-ar"
                    value={editDescAr}
                    onChange={(e) => setEditDescAr(e.target.value)}
                    rows={2}
                    placeholder="مكونات وطعم الصنف..."
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] focus:bg-white resize-none transition"
                  />
                </div>

                <div>
                  <label htmlFor="edit-desc-en" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'الوصف بالإنجليزية' : 'Description (English)'}
                  </label>
                  <textarea
                    id="edit-desc-en"
                    value={editDescEn}
                    onChange={(e) => setEditDescEn(e.target.value)}
                    rows={2}
                    placeholder="Ingredients and flavour details..."
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] focus:bg-white resize-none transition"
                  />
                </div>
              </div>

              {/* Category, Price & Prep Time */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label htmlFor="edit-category" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'القسم *' : 'Category *'}
                  </label>
                  <select
                    id="edit-category"
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-semibold"
                  >
                    {ETOILE_CATEGORIES.filter((c) => c.id !== 'all').map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name[language]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="edit-price" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'السعر (ج.م) *' : 'Price (EGP) *'}
                  </label>
                  <input
                    id="edit-price"
                    type="number"
                    required
                    min={1}
                    value={editPrice}
                    onChange={(e) => setEditPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-mono font-bold"
                  />
                </div>

                <div>
                  <label htmlFor="edit-prep-time" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'وقت التجهيز (دقائق)' : 'Prep Time (min)'}
                  </label>
                  <input
                    id="edit-prep-time"
                    type="number"
                    min={0}
                    value={editPrepTime || ''}
                    onChange={(e) => setEditPrepTime(e.target.value ? Number(e.target.value) : undefined)}
                    placeholder="15"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-mono"
                  />
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 border-t border-stone-100 flex items-center gap-3">
                <button
                  type="submit"
                  disabled={isSaving}
                  className="flex-1 py-3 bg-[#B4963C] hover:bg-[#9E8232] disabled:opacity-50 text-white font-black rounded-xl transition cursor-pointer shadow-md shadow-[#B4963C]/20 flex items-center justify-center gap-2"
                >
                  <Check className="w-4 h-4 stroke-[3]" />
                  <span>{isSaving ? (isAr ? 'جاري الحفظ...' : 'Saving...') : (isAr ? 'حفظ التعديلات في المنيو' : 'Save Changes')}</span>
                </button>

                <button
                  type="button"
                  onClick={handleCloseEditModal}
                  className="px-5 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl transition cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          ADD NEW ITEM MODAL
      ======================================================== */}
      {showAddModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="add-dialog-title"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn overflow-y-auto"
        >
          <div className="w-full max-w-lg bg-white border border-stone-200 rounded-3xl p-6 shadow-2xl relative space-y-4 my-8">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 end-4 p-1.5 rounded-full text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
              aria-label={isAr ? 'إغلاق نافذة الإضافة' : 'Close add modal'}
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-[#B4963C]/10 text-[#B4963C] border border-[#B4963C]/20 flex items-center justify-center">
                <Plus className="w-5 h-5 stroke-[3]" />
              </div>
              <div>
                <h3 id="add-dialog-title" className="text-lg font-black text-stone-900">
                  {isAr ? 'إضافة صنف جديد لقائمة إيتوال' : 'Add New Product to Menu'}
                </h3>
                <p className="text-xs text-stone-500">
                  {isAr ? 'أدخل تفاصيل الصنف الجديد وارفعه مباشرة إلى Firebase RTDB' : 'Add item details and publish live'}
                </p>
              </div>
            </div>

            <form onSubmit={handleAddNewItem} className="space-y-3.5 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="new-title-ar" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'اسم الصنف بالعربي *' : 'Item Title (Arabic) *'}
                  </label>
                  <input
                    id="new-title-ar"
                    type="text"
                    required
                    value={newTitleAr}
                    onChange={(e) => setNewTitleAr(e.target.value)}
                    placeholder="مثال: تورتة لوتس كرسبي"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-medium"
                  />
                </div>
                <div>
                  <label htmlFor="new-title-en" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'الاسم بالإنجليزي' : 'Title (English)'}
                  </label>
                  <input
                    id="new-title-en"
                    type="text"
                    value={newTitleEn}
                    onChange={(e) => setNewTitleEn(e.target.value)}
                    placeholder="e.g. Lotus Crispy Torte"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-medium"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="new-desc-ar" className="text-stone-700 font-bold block mb-1">
                  {isAr ? 'الوصف بالعربي' : 'Description (Arabic)'}
                </label>
                <textarea
                  id="new-desc-ar"
                  value={newDescAr}
                  onChange={(e) => setNewDescAr(e.target.value)}
                  placeholder="وصف مكونات الصنف..."
                  rows={2}
                  className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] resize-none"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label htmlFor="new-category" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'القسم *' : 'Category *'}
                  </label>
                  <select
                    id="new-category"
                    value={newCategory}
                    onChange={(e) => setNewCategory(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-semibold"
                  >
                    {ETOILE_CATEGORIES.filter((c) => c.id !== 'all').map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name[language]}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="new-price" className="text-stone-700 font-bold block mb-1">
                    {isAr ? 'السعر (ج.م) *' : 'Price (EGP) *'}
                  </label>
                  <input
                    id="new-price"
                    type="number"
                    required
                    min={1}
                    value={newPrice}
                    onChange={(e) => setNewPrice(Number(e.target.value))}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-mono font-bold"
                  />
                </div>
              </div>

              {/* Upload or paste Image for New Item */}
              <div className="p-3 bg-stone-50 rounded-2xl border border-stone-200 space-y-2">
                <label className="text-stone-700 font-bold block">
                  {isAr ? 'صورة الصنف (رفع أو رابط مباشر):' : 'Item Photo (Upload or URL):'}
                </label>

                <div className="flex items-center gap-3">
                  <input
                    ref={addFileInputRef}
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleImageFileUpload(e, true)}
                    className="hidden"
                    id="add-file-upload"
                  />
                  <button
                    type="button"
                    onClick={() => addFileInputRef.current?.click()}
                    className="py-2 px-3 bg-white hover:bg-stone-100 text-stone-700 font-bold rounded-xl border border-stone-300 transition flex items-center gap-1.5 cursor-pointer shrink-0"
                  >
                    <Upload className="w-3.5 h-3.5 text-[#B4963C]" />
                    <span>{isAr ? 'رفع من الجهاز' : 'Upload File'}</span>
                  </button>

                  <input
                    type="url"
                    value={newImageUrl}
                    onChange={(e) => setNewImageUrl(e.target.value)}
                    placeholder={isAr ? 'أو ضع رابط URL مباشر...' : 'Or paste URL...'}
                    className="flex-1 px-3 py-2 bg-white border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C] font-mono text-xs"
                  />
                </div>
              </div>

              <div className="pt-3 border-t border-stone-100 flex gap-2">
                <button
                  type="submit"
                  className="flex-1 py-3 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-xl transition cursor-pointer shadow-md shadow-[#B4963C]/20"
                >
                  {isAr ? 'حفظ وإضافة للمنيو الآن' : 'Save & Publish Item'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 font-bold rounded-xl transition cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
