import React, { useState, useMemo, useRef } from 'react';
import {
  Boxes,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Plus,
  Minus,
  Search,
  Filter,
  Download,
  Printer,
  History,
  TrendingDown,
  RotateCcw,
  Sparkles,
  Layers,
  ChevronDown,
  ArrowUpDown,
  Check,
  PackageCheck,
  Building2,
  FileSpreadsheet,
  FileUp,
  X,
  Clock,
  SlidersHorizontal,
} from 'lucide-react';
import { MenuItem, Language, StockAdjustmentLog, StockAdjustmentReason } from '../../types';
import { ETOILE_CATEGORIES } from '../../data/etoileMenuData';
import {
  updateItemStock,
  updateItemStockSettings,
  batchRestockItems,
  getStockAdjustmentLogs,
  saveStockAdjustmentLogs,
} from '../../services/firebaseService';
import { printStockInventorySheet } from '../../services/printService';

interface StockManagerProps {
  menuItems: MenuItem[];
  onUpdateMenu: (items: MenuItem[]) => void;
  language: Language;
}

type StockStatusFilter = 'all' | 'low' | 'out' | 'in_stock' | 'untracked';

export const StockManager: React.FC<StockManagerProps> = ({
  menuItems,
  onUpdateMenu,
  language,
}) => {
  const isAr = language === 'ar';

  // Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<StockStatusFilter>('all');
  const [sortBy, setSortBy] = useState<'name' | 'stock_asc' | 'stock_desc' | 'price'>('stock_asc');

  // Modals state
  const [restockModalItem, setRestockModalItem] = useState<MenuItem | null>(null);
  const [restockAmount, setRestockAmount] = useState<number>(20);
  const [restockNote, setRestockNote] = useState('');
  const [showLogsModal, setShowLogsModal] = useState(false);
  const [showBatchRestockModal, setShowBatchRestockModal] = useState(false);
  const [batchRestockCategory, setBatchRestockCategory] = useState<string>('all');
  const [batchRestockAmount, setBatchRestockAmount] = useState<number>(15);

  // Quick edit threshold / unit modal
  const [settingsItem, setSettingsItem] = useState<MenuItem | null>(null);
  const [settingsThreshold, setSettingsThreshold] = useState<number>(5);
  const [settingsUnit, setSettingsUnit] = useState<string>('قطعة');
  const [settingsTrackStock, setSettingsTrackStock] = useState<boolean>(true);

  // Direct editing input state
  const [editingStockId, setEditingStockId] = useState<string | null>(null);
  const [tempStockValue, setTempStockValue] = useState<string>('');

  // Toast feedback
  const [toastMsg, setToastMsg] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Stock calculations
  const stats = useMemo(() => {
    let totalTracked = 0;
    let lowStockCount = 0;
    let outOfStockCount = 0;
    let inStockCount = 0;
    let untrackedCount = 0;
    let totalInventoryValue = 0;

    menuItems.forEach((item) => {
      if (item.trackStock) {
        totalTracked++;
        const stock = item.stockQuantity ?? 0;
        const threshold = item.lowStockThreshold ?? 5;

        if (stock <= 0 || !item.available) {
          outOfStockCount++;
        } else if (stock <= threshold) {
          lowStockCount++;
        } else {
          inStockCount++;
        }

        totalInventoryValue += stock * item.price;
      } else {
        untrackedCount++;
      }
    });

    return {
      totalItems: menuItems.length,
      totalTracked,
      lowStockCount,
      outOfStockCount,
      inStockCount,
      untrackedCount,
      totalInventoryValue,
    };
  }, [menuItems]);

  // Filtered & Sorted items
  const filteredItems = useMemo(() => {
    return menuItems
      .filter((item) => {
        // Category filter
        if (selectedCategory !== 'all' && item.category !== selectedCategory) {
          return false;
        }

        // Status filter
        const stock = item.stockQuantity ?? 0;
        const threshold = item.lowStockThreshold ?? 5;
        const isTracked = item.trackStock ?? true;

        if (statusFilter === 'low') {
          if (!isTracked || stock <= 0 || stock > threshold) return false;
        } else if (statusFilter === 'out') {
          if (!isTracked || (stock > 0 && item.available)) return false;
        } else if (statusFilter === 'in_stock') {
          if (!isTracked || stock <= threshold) return false;
        } else if (statusFilter === 'untracked') {
          if (isTracked) return false;
        }

        // Search query
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase().trim();
          const matchAr = item.title.ar.toLowerCase().includes(q);
          const matchEn = item.title.en.toLowerCase().includes(q);
          const matchSub = item.subCategory?.toLowerCase().includes(q);
          if (!matchAr && !matchEn && !matchSub) return false;
        }

        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'stock_asc') {
          return (a.stockQuantity ?? 0) - (b.stockQuantity ?? 0);
        }
        if (sortBy === 'stock_desc') {
          return (b.stockQuantity ?? 0) - (a.stockQuantity ?? 0);
        }
        if (sortBy === 'price') {
          return b.price - a.price;
        }
        return a.title[language].localeCompare(b.title[language]);
      });
  }, [menuItems, selectedCategory, statusFilter, searchQuery, sortBy, language]);

  // Quick Stock Adjustments (+1, -1, +5, -5, +10)
  const handleQuickAdjust = async (item: MenuItem, delta: number) => {
    const current = item.stockQuantity ?? 0;
    const newStock = Math.max(0, current + delta);
    const reason: StockAdjustmentReason = delta > 0 ? 'restock' : 'manual_adjustment';
    const note = delta > 0 ? (isAr ? `إضافة سريعة (+${delta})` : `Quick add (+${delta})`) : (isAr ? `خصم سريع (${delta})` : `Quick deduction (${delta})`);

    const updated = await updateItemStock(item.id, newStock, reason, note);
    onUpdateMenu(updated);
    showToast(
      isAr
        ? `تم تحديث مخزون "${item.title.ar}" إلى ${newStock} ${item.stockUnit || 'قطعة'}`
        : `Updated "${item.title.en}" stock to ${newStock} units`
    );
  };

  // Direct numeric input submit
  const handleSaveDirectStock = async (item: MenuItem) => {
    const parsed = parseInt(tempStockValue, 10);
    if (!isNaN(parsed) && parsed >= 0) {
      const updated = await updateItemStock(
        item.id,
        parsed,
        'manual_adjustment',
        isAr ? 'تعديل جرد يدوي مباشر' : 'Manual stocktake adjustment'
      );
      onUpdateMenu(updated);
      showToast(isAr ? `تم تعديل المخزون إلى ${parsed}` : `Stock updated to ${parsed}`);
    }
    setEditingStockId(null);
  };

  // Open single item restock modal
  const handleOpenRestockModal = (item: MenuItem) => {
    setRestockModalItem(item);
    setRestockAmount(20);
    setRestockNote(isAr ? 'توريد من الفرع الرئيسي' : 'Restock from central commissary');
  };

  // Submit single restock
  const handleSubmitRestock = async () => {
    if (!restockModalItem || restockAmount <= 0) return;
    const current = restockModalItem.stockQuantity ?? 0;
    const newStock = current + restockAmount;
    const updated = await updateItemStock(
      restockModalItem.id,
      newStock,
      'restock',
      restockNote || (isAr ? 'توريد دفعة مخزون' : 'Batch restock')
    );
    onUpdateMenu(updated);
    showToast(
      isAr
        ? `تم توريد +${restockAmount} إلى "${restockModalItem.title.ar}" بنجاح!`
        : `Added +${restockAmount} to "${restockModalItem.title.en}" successfully!`
    );
    setRestockModalItem(null);
  };

  // Submit Batch Restock (for whole category or all low items)
  const handleBatchRestock = async () => {
    const targetItems = menuItems.filter((i) => {
      if (batchRestockCategory !== 'all' && i.category !== batchRestockCategory) return false;
      return (i.stockQuantity ?? 0) <= (i.lowStockThreshold ?? 5);
    });

    if (targetItems.length === 0) {
      showToast(isAr ? 'لا توجد أصناف منخفضة المخزون في هذه الفئة' : 'No low stock items found in this category');
      setShowBatchRestockModal(false);
      return;
    }

    const restockList = targetItems.map((item) => ({
      itemId: item.id,
      addUnits: batchRestockAmount,
    }));

    const updated = await batchRestockItems(
      restockList,
      isAr ? `توريد مجمع (+${batchRestockAmount} لكل صنف)` : `Bulk restock (+${batchRestockAmount} per item)`
    );
    onUpdateMenu(updated);
    showToast(
      isAr
        ? `تم توريد ${batchRestockAmount} وحدة لـ ${targetItems.length} صنف بنجاح!`
        : `Successfully restocked ${targetItems.length} items with +${batchRestockAmount} units each!`
    );
    setShowBatchRestockModal(false);
  };

  // Toggle item availability (freeze/enable)
  const handleToggleSoldOut = async (item: MenuItem) => {
    const currentStock = item.stockQuantity ?? 0;
    if (item.available && currentStock > 0) {
      // Mark as Out of stock (zero stock)
      const updated = await updateItemStock(
        item.id,
        0,
        'manual_adjustment',
        isAr ? 'تصفير المخزون وإعلان نفاذ الكمية' : 'Zeroed stock & marked sold out'
      );
      onUpdateMenu(updated);
      showToast(isAr ? `تم تعليم الصنف "نفذت الكمية"` : `Item marked as Sold Out`);
    } else {
      // Restore stock with 15 units
      const updated = await updateItemStock(
        item.id,
        15,
        'restock',
        isAr ? 'إعادة الإتاحة وتعيين مخزون مبدئي' : 'Re-enabled with initial stock'
      );
      onUpdateMenu(updated);
      showToast(isAr ? `تمت إعادة إتاحة الصنف بمخزون 15` : `Item re-enabled with 15 units`);
    }
  };

  // Open settings modal (Threshold & Unit)
  const handleOpenSettingsModal = (item: MenuItem) => {
    setSettingsItem(item);
    setSettingsThreshold(item.lowStockThreshold ?? 5);
    setSettingsUnit(item.stockUnit || 'قطعة');
    setSettingsTrackStock(item.trackStock ?? true);
  };

  // Save settings
  const handleSaveSettings = async () => {
    if (!settingsItem) return;
    const updated = await updateItemStockSettings(settingsItem.id, {
      lowStockThreshold: settingsThreshold,
      stockUnit: settingsUnit,
      trackStock: settingsTrackStock,
    });
    onUpdateMenu(updated);
    showToast(isAr ? 'تم حفظ إعدادات المخزون بنجاح' : 'Stock settings saved successfully');
    setSettingsItem(null);
  };

  // Export Inventory as CSV (with UTF-8 BOM for Arabic support)
  const handleExportCSV = () => {
    const headers = [
      isAr ? 'معرف الصنف' : 'Item ID',
      isAr ? 'اسم الصنف (عربي)' : 'Title AR',
      isAr ? 'اسم الصنف (إنجليزي)' : 'Title EN',
      isAr ? 'الفئة' : 'Category',
      isAr ? 'المخزون الحالي' : 'Current Stock',
      isAr ? 'الوحدة' : 'Unit',
      isAr ? 'حد التنبيه' : 'Low Stock Threshold',
      isAr ? 'سعر الوحدة (ج.م)' : 'Unit Price (EGP)',
      isAr ? 'إجمالي قيمة المخزون (ج.م)' : 'Total Stock Value (EGP)',
      isAr ? 'حالة التتبع' : 'Track Stock',
      isAr ? 'حالة الإتاحة' : 'Availability',
    ];

    const rows = menuItems.map((item) => {
      const stock = item.stockQuantity ?? 0;
      const totalVal = stock * item.price;
      return [
        `"${item.id}"`,
        `"${item.title.ar.replace(/"/g, '""')}"`,
        `"${item.title.en.replace(/"/g, '""')}"`,
        `"${item.category}"`,
        stock,
        `"${item.stockUnit || 'قطعة'}"`,
        item.lowStockThreshold ?? 5,
        item.price,
        totalVal,
        item.trackStock ? (isAr ? 'مفعل' : 'Enabled') : (isAr ? 'معطل' : 'Disabled'),
        item.available ? (isAr ? 'متاح للطلب' : 'Available') : (isAr ? 'غير متاح' : 'Unavailable'),
      ];
    });

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `etoile_inventory_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    showToast(isAr ? 'تم تصدير كشف المخزون Excel بنجاح' : 'Inventory exported as CSV');
  };

  // Hidden file input for CSV Import
  const csvFileInputRef = useRef<HTMLInputElement>(null);

  const handleImportCSV = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const text = evt.target?.result as string;
        if (!text) return;
        const lines = text.split(/\r?\n/).filter((l) => l.trim().length > 0);
        if (lines.length < 2) {
          alert(isAr ? 'الملف فارغ أو لا يحتوي على بيانات صالحة' : 'File is empty or contains no data');
          return;
        }

        let updatedCount = 0;
        const restockEntries: Array<{ itemId: string; addUnits: number }> = [];

        for (let i = 1; i < lines.length; i++) {
          const cols = lines[i].split(',').map((c) => c.trim().replace(/^"|"$/g, ''));
          if (cols.length >= 5) {
            const id = cols[0];
            const stockQty = parseInt(cols[4], 10);
            if (id && !isNaN(stockQty)) {
              const item = menuItems.find((m) => m.id === id);
              if (item) {
                const diff = stockQty - (item.stockQuantity ?? 0);
                if (diff > 0) {
                  restockEntries.push({ itemId: id, addUnits: diff });
                } else if (diff < 0) {
                  await updateItemStock(id, stockQty, 'manual_adjustment', isAr ? 'استيراد كشف جرد' : 'CSV import');
                }
                updatedCount++;
              }
            }
          }
        }

        if (restockEntries.length > 0) {
          const updated = await batchRestockItems(restockEntries, isAr ? 'استيراد كشف جرد CSV' : 'CSV batch restock');
          onUpdateMenu(updated);
        }

        showToast(
          isAr
            ? `تم استيراد الملف بنجاح وتحديث ${updatedCount} صنف`
            : `File imported successfully, updated ${updatedCount} items`
        );
      } catch (err) {
        console.error('Error importing CSV:', err);
        alert(isAr ? 'حدث خطأ أثناء قراءة ملف CSV' : 'Error parsing CSV file');
      }
    };
    reader.readAsText(file);
    e.target.value = '';
  };

  // Print Inventory Sheet (Dedicated clean printing, zero blank pages)
  const handlePrintSheet = () => {
    printStockInventorySheet(menuItems, language);
  };

  const stockLogs = useMemo(() => getStockAdjustmentLogs(), [showLogsModal]);

  return (
    <div className="space-y-6">
      {/* Hidden Native File Input for CSV */}
      <input
        type="file"
        ref={csvFileInputRef}
        onChange={handleImportCSV}
        accept=".csv,text/csv"
        className="hidden"
      />

      {/* Toast Notification */}
      {toastMsg && (
        <div className="fixed bottom-6 start-1/2 -translate-x-1/2 z-50 bg-stone-900 text-white px-5 py-2.5 rounded-xl shadow-xl flex items-center gap-2 text-xs sm:text-sm font-bold border border-[#B4963C] animate-bounce">
          <CheckCircle2 className="w-4 h-4 text-[#B4963C]" />
          <span>{toastMsg}</span>
        </div>
      )}

      {/* Header & Quick Action Buttons */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-5 rounded-2xl border border-stone-200 shadow-xs">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 border border-[#B4963C]/20 flex items-center justify-center text-[#B4963C]">
              <Boxes className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg sm:text-xl font-black text-stone-900 flex items-center gap-2">
                <span>{isAr ? 'إدارة المخزون والتوريد (Stock Manager)' : 'Stock & Inventory Manager'}</span>
                <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-700">
                  {isAr ? 'مباشر مع الكاشير' : 'POS Synchronized'}
                </span>
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                {isAr
                  ? 'متابعة كميات الأصناف الحالية، تنبيهات النواقص، التوريد الفوري وتحديث قائمة الطلبات'
                  : 'Track live stock quantities, low-stock alerts, fast batch restocking and auto-deductions'}
              </p>
            </div>
          </div>
        </div>

        {/* Global Stock Actions */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setShowBatchRestockModal(true)}
            className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#B4963C] hover:bg-[#9E8232] text-white text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>{isAr ? 'توريد مجمع للنواقص' : 'Bulk Restock Low Items'}</span>
          </button>

          <button
            onClick={() => setShowLogsModal(true)}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold transition cursor-pointer"
          >
            <History className="w-4 h-4 text-stone-500" />
            <span>{isAr ? 'سجل حركات المخزون' : 'Stock Audit Logs'}</span>
          </button>

          <button
            onClick={() => csvFileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold transition cursor-pointer"
            title={isAr ? 'استيراد كشف جرد من ملف CSV' : 'Import Stock from CSV'}
          >
            <FileUp className="w-4 h-4 text-[#B4963C]" />
            <span>{isAr ? 'استيراد CSV' : 'Import CSV'}</span>
          </button>

          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold transition cursor-pointer"
            title={isAr ? 'تصدير كشف إكسيل' : 'Export Excel CSV'}
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-600" />
            <span>{isAr ? 'تصدير كشف جرد' : 'Export CSV'}</span>
          </button>

          <button
            onClick={handlePrintSheet}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold transition cursor-pointer"
            title={isAr ? 'طباعة كشف الجرد' : 'Print Stock Sheet'}
          >
            <Printer className="w-4 h-4 text-stone-600" />
            <span>{isAr ? 'طباعة كشف الجرد' : 'Print Sheet'}</span>
          </button>
        </div>
      </div>

      {/* KPI Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-5 gap-3 sm:gap-4">
        {/* Total Tracked Items */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-stone-500 uppercase tracking-wider">
              {isAr ? 'أصناف قيد التتبع' : 'Tracked Items'}
            </span>
            <div className="text-2xl font-black text-stone-900 mt-1">
              {stats.totalTracked}
              <span className="text-xs text-stone-400 font-normal ms-1">/ {stats.totalItems}</span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-stone-100 flex items-center justify-center text-stone-600">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        {/* In Stock (Healthy) */}
        <div
          onClick={() => setStatusFilter('in_stock')}
          className={`bg-white p-4 rounded-2xl border cursor-pointer transition shadow-xs flex items-center justify-between ${
            statusFilter === 'in_stock' ? 'border-emerald-500 ring-2 ring-emerald-500/20' : 'border-stone-200 hover:border-emerald-300'
          }`}
        >
          <div>
            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider">
              {isAr ? 'متوفر بكثرة' : 'Well Stocked'}
            </span>
            <div className="text-2xl font-black text-emerald-600 mt-1">
              {stats.inStockCount}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-emerald-50 flex items-center justify-center text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
          </div>
        </div>

        {/* Low Stock Alerts */}
        <div
          onClick={() => setStatusFilter('low')}
          className={`bg-white p-4 rounded-2xl border cursor-pointer transition shadow-xs flex items-center justify-between ${
            statusFilter === 'low' ? 'border-amber-500 ring-2 ring-amber-500/20' : 'border-stone-200 hover:border-amber-300'
          }`}
        >
          <div>
            <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider">
              {isAr ? 'تنبيه انخفاض' : 'Low Stock Warning'}
            </span>
            <div className="text-2xl font-black text-amber-600 mt-1 flex items-center gap-1.5">
              <span>{stats.lowStockCount}</span>
              {stats.lowStockCount > 0 && (
                <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-amber-100 text-amber-800 animate-pulse font-bold">
                  {isAr ? 'يحتاج توريد' : 'Needs Restock'}
                </span>
              )}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        {/* Out of Stock */}
        <div
          onClick={() => setStatusFilter('out')}
          className={`bg-white p-4 rounded-2xl border cursor-pointer transition shadow-xs flex items-center justify-between ${
            statusFilter === 'out' ? 'border-rose-500 ring-2 ring-rose-500/20' : 'border-stone-200 hover:border-rose-300'
          }`}
        >
          <div>
            <span className="text-[11px] font-bold text-rose-700 uppercase tracking-wider">
              {isAr ? 'نفذ من المخزون' : 'Out of Stock'}
            </span>
            <div className="text-2xl font-black text-rose-600 mt-1">
              {stats.outOfStockCount}
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-rose-50 flex items-center justify-center text-rose-600">
            <XCircle className="w-5 h-5" />
          </div>
        </div>

        {/* Total Inventory Valuation */}
        <div className="col-span-2 lg:col-span-1 bg-gradient-to-br from-white to-[#B4963C]/5 p-4 rounded-2xl border border-[#B4963C]/30 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-[#B4963C] uppercase tracking-wider">
              {isAr ? 'إجمالي قيمة البضاعة' : 'Inventory Valuation'}
            </span>
            <div className="text-xl sm:text-2xl font-black text-stone-900 mt-1">
              {stats.totalInventoryValue.toLocaleString()}
              <span className="text-xs text-[#B4963C] font-bold ms-1">{isAr ? 'ج.م' : 'EGP'}</span>
            </div>
          </div>
          <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 flex items-center justify-center text-[#B4963C]">
            <Building2 className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row items-center gap-3 justify-between">
          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto w-full md:w-auto pb-1 md:pb-0 scrollbar-none">
            {[
              { id: 'all', label: isAr ? 'جميع الأصناف' : 'All Items', count: menuItems.length },
              { id: 'low', label: isAr ? 'نواقص التنبيه' : 'Low Stock', count: stats.lowStockCount, alert: stats.lowStockCount > 0 },
              { id: 'out', label: isAr ? 'نفذت الكمية' : 'Out of Stock', count: stats.outOfStockCount, danger: stats.outOfStockCount > 0 },
              { id: 'in_stock', label: isAr ? 'متوفر' : 'In Stock', count: stats.inStockCount },
              { id: 'untracked', label: isAr ? 'غير مقيد' : 'Untracked', count: stats.untrackedCount },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setStatusFilter(tab.id as StockStatusFilter)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap cursor-pointer ${
                  statusFilter === tab.id
                    ? 'bg-stone-900 text-white'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                <span>{tab.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${
                    statusFilter === tab.id
                      ? 'bg-white/20 text-white'
                      : tab.danger
                      ? 'bg-rose-100 text-rose-700'
                      : tab.alert
                      ? 'bg-amber-100 text-amber-800'
                      : 'bg-stone-200 text-stone-600'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-2 w-full md:w-auto justify-end">
            <span className="text-xs text-stone-500 font-medium whitespace-nowrap flex items-center gap-1">
              <ArrowUpDown className="w-3.5 h-3.5" />
              <span>{isAr ? 'ترتيب حسب:' : 'Sort:'}</span>
            </span>
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-stone-50 border border-stone-200 text-xs font-bold rounded-xl px-2.5 py-1.5 text-stone-800 focus:outline-hidden focus:border-[#B4963C]"
            >
              <option value="stock_asc">{isAr ? 'المخزون: من الأقل للأعلى (نواقص أولاً)' : 'Stock: Lowest First (Low items)'}</option>
              <option value="stock_desc">{isAr ? 'المخزون: من الأعلى للأقل' : 'Stock: Highest First'}</option>
              <option value="name">{isAr ? 'الاسم الأبجدي' : 'Alphabetical Name'}</option>
              <option value="price">{isAr ? 'السعر' : 'Unit Price'}</option>
            </select>
          </div>
        </div>

        {/* Search & Category Filter Row */}
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 pt-2 border-t border-stone-100">
          {/* Instant Search Bar */}
          <div className="sm:col-span-8 relative">
            <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 start-3 text-stone-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={isAr ? 'ابحث باسم الصنف (بسبوسة، تورتة، كعك...) أو التصنيف...' : 'Search item name (Basbousa, Cake, Cookies...)...'}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl ps-9 pe-9 py-2 text-xs sm:text-sm text-stone-900 placeholder:text-stone-400 focus:outline-hidden focus:border-[#B4963C] focus:bg-white transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute top-1/2 -translate-y-1/2 end-3 text-stone-400 hover:text-stone-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          {/* Category Dropdown */}
          <div className="sm:col-span-4">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs sm:text-sm font-bold text-stone-800 focus:outline-hidden focus:border-[#B4963C] focus:bg-white"
            >
              {ETOILE_CATEGORIES.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.name[language]}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Main Stock Table & Cards */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-xs overflow-hidden">
        {/* Results info header */}
        <div className="px-5 py-3 border-b border-stone-100 flex items-center justify-between text-xs text-stone-500 bg-stone-50/50">
          <span>
            {isAr
              ? `عرض ${filteredItems.length} من أصل ${menuItems.length} صنف`
              : `Showing ${filteredItems.length} of ${menuItems.length} items`}
          </span>
          {statusFilter !== 'all' && (
            <button
              onClick={() => {
                setStatusFilter('all');
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="text-[#B4963C] font-bold hover:underline"
            >
              {isAr ? 'إعادة ضبط الفلاتر' : 'Reset filters'}
            </button>
          )}
        </div>

        {filteredItems.length === 0 ? (
          <div className="p-12 text-center text-stone-500">
            <Boxes className="w-12 h-12 text-stone-300 mx-auto mb-3" />
            <h3 className="text-base font-bold text-stone-800">
              {isAr ? 'لم يتم العثور على أصناف مطابقة للبحث' : 'No matching items found'}
            </h3>
            <p className="text-xs text-stone-400 mt-1">
              {isAr ? 'جرب البحث باسم آخر أو تغيير فلتر الفئة والمخزون' : 'Try adjusting your search query or filters'}
            </p>
          </div>
        ) : (
          <div className="divide-y divide-stone-100">
            {filteredItems.map((item) => {
              const stock = item.stockQuantity ?? 0;
              const threshold = item.lowStockThreshold ?? 5;
              const isTracked = item.trackStock ?? true;
              const isLow = isTracked && stock > 0 && stock <= threshold;
              const isOut = isTracked && (stock <= 0 || !item.available);
              const maxGauge = Math.max(stock, threshold * 3, 20);
              const stockPercent = Math.min(100, Math.round((stock / maxGauge) * 100));

              return (
                <div
                  key={item.id}
                  className={`p-4 sm:px-6 hover:bg-stone-50/80 transition-colors flex flex-col lg:flex-row lg:items-center justify-between gap-4 ${
                    isOut ? 'bg-rose-50/30' : isLow ? 'bg-amber-50/30' : ''
                  }`}
                >
                  {/* Left: Product Thumbnail & Details */}
                  <div className="flex items-center gap-3.5 min-w-[280px] max-w-md">
                    <div className="relative w-14 h-14 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shrink-0">
                      {item.image ? (
                        <img
                          src={item.image}
                          alt={item.title[language]}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src =
                              'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=400&q=80';
                          }}
                        />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center font-serif text-lg font-bold text-[#B4963C] bg-[#B4963C]/10">
                          É
                        </div>
                      )}
                      {isOut && (
                        <div className="absolute inset-0 bg-rose-900/60 flex items-center justify-center">
                          <span className="text-[9px] font-black text-white px-1 py-0.5 rounded-sm">0</span>
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="text-[10px] font-bold text-[#B4963C] bg-[#B4963C]/10 px-1.5 py-0.5 rounded-md uppercase tracking-wider">
                          {item.subCategory || item.category}
                        </span>
                        {/* Status badge */}
                        {isOut ? (
                          <span className="text-[10px] font-black text-rose-700 bg-rose-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                            <XCircle className="w-3 h-3" />
                            <span>{isAr ? 'نفذت الكمية' : 'Out of Stock'}</span>
                          </span>
                        ) : isLow ? (
                          <span className="text-[10px] font-black text-amber-800 bg-amber-100 px-2 py-0.5 rounded-md flex items-center gap-1 animate-pulse">
                            <AlertTriangle className="w-3 h-3" />
                            <span>{isAr ? `نواقص (${stock} فقط)` : `Low (${stock} left)`}</span>
                          </span>
                        ) : isTracked ? (
                          <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-md flex items-center gap-1">
                            <Check className="w-3 h-3" />
                            <span>{isAr ? 'متوفر' : 'In Stock'}</span>
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold text-stone-500 bg-stone-100 px-2 py-0.5 rounded-md">
                            {isAr ? 'مخزون مفتوح' : 'Untracked'}
                          </span>
                        )}
                      </div>

                      <h4 className="text-sm font-bold text-stone-900 truncate mt-1">
                        {item.title[language]}
                      </h4>

                      <div className="flex items-center gap-3 text-xs text-stone-500 mt-0.5">
                        <span className="font-bold text-[#B4963C]">
                          {item.price} {isAr ? 'ج.م' : 'EGP'}
                        </span>
                        <span>•</span>
                        <span className="text-stone-400">
                          {isAr ? `قيمة المخزون: ${(stock * item.price).toLocaleString()} ج.م` : `Val: ${(stock * item.price).toLocaleString()} EGP`}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Middle: Live Stock Level Gauge & Direct Input */}
                  <div className="flex-1 max-w-sm px-2">
                    <div className="flex items-center justify-between text-xs mb-1.5">
                      <span className="text-stone-500 font-medium">
                        {isAr ? 'الكمية المتوفرة حالياً:' : 'Current Stock:'}
                      </span>
                      <div className="flex items-center gap-1.5">
                        {editingStockId === item.id ? (
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0"
                              value={tempStockValue}
                              onChange={(e) => setTempStockValue(e.target.value)}
                              onKeyDown={(e) => {
                                if (e.key === 'Enter') handleSaveDirectStock(item);
                                if (e.key === 'Escape') setEditingStockId(null);
                              }}
                              className="w-16 px-1.5 py-0.5 text-xs font-bold border border-[#B4963C] rounded-md text-center bg-white"
                              autoFocus
                            />
                            <button
                              onClick={() => handleSaveDirectStock(item)}
                              className="p-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700"
                            >
                              <Check className="w-3 h-3" />
                            </button>
                            <button
                              onClick={() => setEditingStockId(null)}
                              className="p-1 rounded-md bg-stone-200 text-stone-700 hover:bg-stone-300"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setEditingStockId(item.id);
                              setTempStockValue(stock.toString());
                            }}
                            className="text-stone-900 font-mono font-black text-base hover:text-[#B4963C] flex items-center gap-1 group cursor-pointer"
                            title={isAr ? 'اضغط لتعديل الرقم مباشرة' : 'Click to edit number directly'}
                          >
                            <span>{stock}</span>
                            <span className="text-xs font-sans text-stone-500 font-medium">
                              {item.stockUnit || (isAr ? 'قطعة' : 'pcs')}
                            </span>
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Progress Bar Gauge */}
                    <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden">
                      <div
                        className={`h-full transition-all duration-300 rounded-full ${
                          isOut
                            ? 'bg-rose-500 w-full'
                            : isLow
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                        style={{ width: isOut ? '100%' : `${stockPercent}%` }}
                      ></div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-stone-400 mt-1">
                      <span>{isAr ? `حد التنبيه: ${threshold}` : `Alert Threshold: ${threshold}`}</span>
                      {item.lastRestockedAt && (
                        <span>
                          {isAr ? 'آخر توريد: ' : 'Restocked: '}
                          {new Date(item.lastRestockedAt).toLocaleDateString(isAr ? 'ar-EG' : 'en-US', {
                            month: 'numeric',
                            day: 'numeric',
                          })}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Right: Quick Adjust buttons & Tools */}
                  <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap justify-end">
                    {/* Quick Stepper: -5, -1, +1, +5, +10 */}
                    <div className="flex items-center bg-stone-100 p-1 rounded-xl border border-stone-200">
                      <button
                        onClick={() => handleQuickAdjust(item, -5)}
                        disabled={stock < 5}
                        className="px-1.5 py-1 text-[11px] font-bold text-stone-600 hover:text-stone-900 hover:bg-white rounded-lg disabled:opacity-30 disabled:pointer-events-none transition cursor-pointer"
                        title={isAr ? 'خصم 5' : '-5 units'}
                      >
                        -5
                      </button>
                      <button
                        onClick={() => handleQuickAdjust(item, -1)}
                        disabled={stock <= 0}
                        className="w-7 h-7 flex items-center justify-center text-stone-600 hover:text-stone-900 hover:bg-white rounded-lg disabled:opacity-30 disabled:pointer-events-none transition cursor-pointer"
                        title={isAr ? 'خصم 1' : '-1 unit'}
                      >
                        <Minus className="w-3.5 h-3.5" />
                      </button>
                      <span className="px-2 text-xs font-mono font-bold text-stone-800">
                        {stock}
                      </span>
                      <button
                        onClick={() => handleQuickAdjust(item, 1)}
                        className="w-7 h-7 flex items-center justify-center text-stone-600 hover:text-stone-900 hover:bg-white rounded-lg transition cursor-pointer"
                        title={isAr ? 'إضافة 1' : '+1 unit'}
                      >
                        <Plus className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => handleQuickAdjust(item, 5)}
                        className="px-1.5 py-1 text-[11px] font-bold text-stone-600 hover:text-stone-900 hover:bg-white rounded-lg transition cursor-pointer"
                        title={isAr ? 'إضافة 5' : '+5 units'}
                      >
                        +5
                      </button>
                      <button
                        onClick={() => handleQuickAdjust(item, 10)}
                        className="px-1.5 py-1 text-[11px] font-bold text-[#B4963C] hover:bg-white rounded-lg transition cursor-pointer"
                        title={isAr ? 'إضافة 10' : '+10 units'}
                      >
                        +10
                      </button>
                    </div>

                    {/* Fast Restock Button */}
                    <button
                      onClick={() => handleOpenRestockModal(item)}
                      className="px-2.5 py-1.5 rounded-xl bg-[#B4963C]/10 text-[#B4963C] hover:bg-[#B4963C] hover:text-white text-xs font-bold transition flex items-center gap-1 cursor-pointer"
                      title={isAr ? 'توريد دفعة كمية' : 'Restock Item'}
                    >
                      <PackageCheck className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">{isAr ? 'توريد' : 'Restock'}</span>
                    </button>

                    {/* Toggle Availability / Mark Sold Out */}
                    <button
                      onClick={() => handleToggleSoldOut(item)}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-bold transition cursor-pointer ${
                        item.available && stock > 0
                          ? 'bg-rose-50 hover:bg-rose-100 text-rose-700'
                          : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-700'
                      }`}
                      title={item.available ? (isAr ? 'إعلان نفاد الكمية' : 'Mark Sold Out') : (isAr ? 'إعادة الإتاحة' : 'Make Available')}
                    >
                      {item.available && stock > 0
                        ? (isAr ? 'تصفير' : 'Zero')
                        : (isAr ? 'تفعيل' : 'Enable')}
                    </button>

                    {/* Item Settings (Threshold / Unit) */}
                    <button
                      onClick={() => handleOpenSettingsModal(item)}
                      className="p-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-600 transition cursor-pointer"
                      title={isAr ? 'إعدادات حد التنبيه والوحدة' : 'Stock settings'}
                    >
                      <SlidersHorizontal className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ====================================================================
          MODAL: SINGLE ITEM RESTOCK
      ==================================================================== */}
      {restockModalItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full border border-stone-200 shadow-2xl p-6 space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center">
                  <PackageCheck className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-base">
                    {isAr ? 'تسجيل توريد مخزون' : 'Stock Restock Entry'}
                  </h3>
                  <p className="text-xs text-stone-500">
                    {restockModalItem.title[language]}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setRestockModalItem(null)}
                className="w-8 h-8 rounded-full bg-stone-100 text-stone-500 hover:text-stone-900 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {/* Current stock reminder */}
              <div className="bg-stone-50 p-3 rounded-2xl flex items-center justify-between text-xs">
                <span className="text-stone-500">{isAr ? 'المخزون الحالي:' : 'Current Stock:'}</span>
                <span className="font-bold font-mono text-stone-900 text-sm">
                  {restockModalItem.stockQuantity ?? 0} {restockModalItem.stockUnit || 'قطعة'}
                </span>
              </div>

              {/* Quantity to add */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  {isAr ? 'الكمية الموردة (+):' : 'Quantity to Add (+):'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    value={restockAmount}
                    onChange={(e) => setRestockAmount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-base font-bold font-mono text-stone-900 focus:outline-hidden focus:border-[#B4963C]"
                  />
                  <div className="flex items-center gap-1">
                    {[10, 20, 50, 100].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setRestockAmount(preset)}
                        className={`px-2.5 py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                          restockAmount === preset
                            ? 'bg-[#B4963C] text-white border-[#B4963C]'
                            : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        +{preset}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Resulting stock preview */}
              <div className="bg-emerald-50 text-emerald-800 p-3 rounded-2xl flex items-center justify-between text-xs font-bold">
                <span>{isAr ? 'المخزون بعد التوريد:' : 'New Stock after Restock:'}</span>
                <span className="text-base font-mono">
                  {(restockModalItem.stockQuantity ?? 0) + restockAmount} {restockModalItem.stockUnit || 'قطعة'}
                </span>
              </div>

              {/* Note / Supplier reference */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  {isAr ? 'ملاحظة التوريد / رقم إذن الاستلام:' : 'Restock Note / Receipt Ref:'}
                </label>
                <input
                  type="text"
                  value={restockNote}
                  onChange={(e) => setRestockNote(e.target.value)}
                  placeholder={isAr ? 'مثال: شحنة مخبز الصباح - الفرع الرئيسي' : 'e.g. Morning batch from central commissary'}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs text-stone-900 focus:outline-hidden focus:border-[#B4963C]"
                />
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setRestockModalItem(null)}
                className="flex-1 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-xs font-bold hover:bg-stone-50 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleSubmitRestock}
                className="flex-1 py-2.5 rounded-xl bg-[#B4963C] hover:bg-[#9E8232] text-white text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
              >
                {isAr ? 'تأكيد التوريد والترحيل' : 'Confirm & Save Stock'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          MODAL: BATCH RESTOCK LOW ITEMS
      ==================================================================== */}
      {showBatchRestockModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full border border-stone-200 shadow-2xl p-6 space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 text-amber-600 flex items-center justify-center">
                  <Boxes className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-base">
                    {isAr ? 'توريد مجمع لجميع النواقص' : 'Bulk Restock Low-Stock Items'}
                  </h3>
                  <p className="text-xs text-stone-500">
                    {isAr ? 'إضافة كمية دفعة واحدة لجميع الأصناف المنخفضة أو النافذة' : 'Quickly add units to all low and zero-stock items'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowBatchRestockModal(false)}
                className="w-8 h-8 rounded-full bg-stone-100 text-stone-500 hover:text-stone-900 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {/* Target Category */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  {isAr ? 'الفئة المستهدفة:' : 'Target Category:'}
                </label>
                <select
                  value={batchRestockCategory}
                  onChange={(e) => setBatchRestockCategory(e.target.value)}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-xs font-bold text-stone-800 focus:outline-hidden focus:border-[#B4963C]"
                >
                  <option value="all">{isAr ? 'جميع الفئات (كل الأصناف المنخفضة)' : 'All Categories (All low items)'}</option>
                  {ETOILE_CATEGORIES.filter((c) => c.id !== 'all').map((cat) => (
                    <option key={cat.id} value={cat.id}>
                      {cat.name[language]}
                    </option>
                  ))}
                </select>
              </div>

              {/* Units to add to each item */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  {isAr ? 'عدد الوحدات المضافة لكل صنف:' : 'Units to add to each low item:'}
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    min="1"
                    value={batchRestockAmount}
                    onChange={(e) => setBatchRestockAmount(Math.max(1, parseInt(e.target.value, 10) || 1))}
                    className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-base font-bold font-mono text-stone-900"
                  />
                  <div className="flex items-center gap-1">
                    {[10, 15, 25, 50].map((preset) => (
                      <button
                        key={preset}
                        type="button"
                        onClick={() => setBatchRestockAmount(preset)}
                        className={`px-2.5 py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                          batchRestockAmount === preset
                            ? 'bg-[#B4963C] text-white border-[#B4963C]'
                            : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                        }`}
                      >
                        +{preset}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="p-3 bg-amber-50 rounded-2xl border border-amber-200/60 text-xs text-amber-900 space-y-1">
                <span className="font-bold flex items-center gap-1.5">
                  <AlertTriangle className="w-4 h-4 text-amber-600" />
                  <span>{isAr ? 'معلومات التوريد التلقائي:' : 'Bulk Restock Info:'}</span>
                </span>
                <p className="leading-relaxed">
                  {isAr
                    ? `سيتم إضافة ${batchRestockAmount} وحدة إلى جميع الأصناف التي وصل مخزونها لحد التنبيه (≤ 5) وإعادة تفعيلها مباشرة للزبائن.`
                    : `Will add +${batchRestockAmount} units to all items currently at or below their alert threshold (≤ 5) and re-enable them for customers.`}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setShowBatchRestockModal(false)}
                className="flex-1 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-xs font-bold hover:bg-stone-50 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleBatchRestock}
                className="flex-1 py-2.5 rounded-xl bg-[#B4963C] hover:bg-[#9E8232] text-white text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
              >
                {isAr ? 'تنفيذ التوريد المجمع' : 'Execute Bulk Restock'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          MODAL: STOCK SETTINGS (Threshold, Unit, Track Toggle)
      ==================================================================== */}
      {settingsItem && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-md w-full border border-stone-200 shadow-2xl p-6 space-y-4 animate-scaleUp">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <SlidersHorizontal className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-base">
                    {isAr ? 'إعدادات مراقبة المخزون' : 'Stock Item Settings'}
                  </h3>
                  <p className="text-xs text-stone-500">
                    {settingsItem.title[language]}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setSettingsItem(null)}
                className="w-8 h-8 rounded-full bg-stone-100 text-stone-500 hover:text-stone-900 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3">
              {/* Track Stock Toggle */}
              <div className="flex items-center justify-between p-3 rounded-2xl bg-stone-50 border border-stone-200">
                <div>
                  <span className="text-xs font-bold text-stone-800 block">
                    {isAr ? 'تفعيل تتبع المخزون للصنف' : 'Track Inventory for Item'}
                  </span>
                  <span className="text-[11px] text-stone-500">
                    {isAr ? 'تعطيل الطلب تلقائياً عند نفاذ الكمية' : 'Disable orders when stock reaches 0'}
                  </span>
                </div>
                <button
                  type="button"
                  onClick={() => setSettingsTrackStock(!settingsTrackStock)}
                  className={`w-12 h-6 rounded-full transition-colors relative cursor-pointer ${
                    settingsTrackStock ? 'bg-[#B4963C]' : 'bg-stone-300'
                  }`}
                >
                  <span
                    className={`block w-5 h-5 rounded-full bg-white shadow-xs transition-transform transform ${
                      settingsTrackStock ? (isAr ? '-translate-x-6' : 'translate-x-6') : 'translate-x-0.5'
                    }`}
                  />
                </button>
              </div>

              {/* Low Stock Warning Threshold */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  {isAr ? 'حد تنبيه انخفاض المخزون (Low Stock Alert Threshold):' : 'Low Stock Alert Threshold:'}
                </label>
                <input
                  type="number"
                  min="1"
                  value={settingsThreshold}
                  onChange={(e) => setSettingsThreshold(Math.max(1, parseInt(e.target.value, 10) || 1))}
                  className="w-full bg-stone-50 border border-stone-200 rounded-xl px-3 py-2 text-sm font-bold font-mono text-stone-900 focus:outline-hidden focus:border-[#B4963C]"
                />
                <span className="text-[11px] text-stone-400 mt-1 block">
                  {isAr ? 'يتم إرسال تنبيه في الشاشة عندما يصل المخزون لهذا الرقم أو أقل' : 'Triggers an alert when stock reaches this amount or lower'}
                </span>
              </div>

              {/* Unit of measure */}
              <div>
                <label className="text-xs font-bold text-stone-700 block mb-1">
                  {isAr ? 'وحدة القياس:' : 'Stock Unit of Measure:'}
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {['قطعة', 'علبة', 'كجم'].map((u) => (
                    <button
                      key={u}
                      type="button"
                      onClick={() => setSettingsUnit(u)}
                      className={`py-2 rounded-xl text-xs font-bold border transition cursor-pointer ${
                        settingsUnit === u
                          ? 'bg-[#B4963C]/10 text-[#B4963C] border-[#B4963C]'
                          : 'bg-stone-50 text-stone-700 border-stone-200 hover:bg-stone-100'
                      }`}
                    >
                      {u}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-stone-100">
              <button
                type="button"
                onClick={() => setSettingsItem(null)}
                className="flex-1 py-2.5 rounded-xl border border-stone-200 text-stone-600 text-xs font-bold hover:bg-stone-50 cursor-pointer"
              >
                {isAr ? 'إلغاء' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleSaveSettings}
                className="flex-1 py-2.5 rounded-xl bg-stone-900 hover:bg-black text-white text-xs font-bold transition shadow-xs cursor-pointer active:scale-95"
              >
                {isAr ? 'حفظ الإعدادات' : 'Save Settings'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ====================================================================
          MODAL: STOCK AUDIT LOGS (History of adjustments)
      ==================================================================== */}
      {showLogsModal && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-2xl w-full border border-stone-200 shadow-2xl p-6 space-y-4 max-h-[85vh] flex flex-col animate-scaleUp">
            <div className="flex items-center justify-between border-b border-stone-100 pb-3">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 rounded-xl bg-stone-100 text-stone-700 flex items-center justify-center">
                  <History className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-bold text-stone-900 text-base">
                    {isAr ? 'سجل حركات وتوريدات المخزون' : 'Stock Audit & Movement Logs'}
                  </h3>
                  <p className="text-xs text-stone-500">
                    {isAr ? 'تتبع عمليات التوريد، مبيعات الطلبات، والتعديلات اليدوية' : 'Recent restocks, order deductions, and manual adjustments'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowLogsModal(false)}
                className="w-8 h-8 rounded-full bg-stone-100 text-stone-500 hover:text-stone-900 flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Logs List */}
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {stockLogs.length === 0 ? (
                <div className="p-8 text-center text-stone-400 text-xs">
                  <History className="w-8 h-8 mx-auto mb-2 text-stone-300" />
                  <span>{isAr ? 'لا توجد حركات مخزون مسجلة حتى الآن' : 'No stock logs recorded yet'}</span>
                </div>
              ) : (
                stockLogs.map((log) => {
                  const isPositive = log.delta > 0;
                  return (
                    <div
                      key={log.id}
                      className="p-3 rounded-2xl bg-stone-50 border border-stone-200/80 flex items-center justify-between text-xs"
                    >
                      <div className="space-y-0.5">
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-stone-900">{log.itemTitle[language]}</span>
                          <span
                            className={`px-1.5 py-0.5 rounded-md text-[10px] font-bold ${
                              log.reason === 'restock'
                                ? 'bg-emerald-100 text-emerald-800'
                                : log.reason === 'order_sale'
                                ? 'bg-blue-100 text-blue-800'
                                : 'bg-stone-200 text-stone-700'
                            }`}
                          >
                            {log.reason === 'restock'
                              ? (isAr ? 'توريد' : 'Restock')
                              : log.reason === 'order_sale'
                              ? (isAr ? 'طلب زبون' : 'Order Sale')
                              : (isAr ? 'تعديل يدوي' : 'Manual Edit')}
                          </span>
                        </div>
                        {log.note && <p className="text-stone-500 text-[11px]">{log.note}</p>}
                        <div className="flex items-center gap-1 text-[10px] text-stone-400">
                          <Clock className="w-3 h-3" />
                          <span>{new Date(log.timestamp).toLocaleString(isAr ? 'ar-EG' : 'en-US')}</span>
                        </div>
                      </div>

                      <div className="text-end">
                        <div
                          className={`font-mono font-bold text-sm ${
                            isPositive ? 'text-emerald-600' : 'text-rose-600'
                          }`}
                        >
                          {isPositive ? `+${log.delta}` : log.delta}
                        </div>
                        <div className="text-[10px] text-stone-400">
                          {log.previousStock} ➔ {log.newStock}
                        </div>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
              <button
                type="button"
                onClick={() => {
                  saveStockAdjustmentLogs([]);
                  showToast(isAr ? 'تم مسح السجل' : 'Logs cleared');
                  setShowLogsModal(false);
                }}
                className="text-rose-600 hover:text-rose-800 text-xs font-bold"
              >
                {isAr ? 'مسح سجل الحركات' : 'Clear Log History'}
              </button>
              <button
                type="button"
                onClick={() => setShowLogsModal(false)}
                className="px-5 py-2 rounded-xl bg-stone-900 text-white text-xs font-bold hover:bg-black"
              >
                {isAr ? 'إغلاق' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
