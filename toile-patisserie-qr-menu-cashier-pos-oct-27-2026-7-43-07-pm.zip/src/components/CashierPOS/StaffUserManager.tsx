import React, { useState } from 'react';
import {
  Users,
  UserPlus,
  Shield,
  KeyRound,
  Eye,
  EyeOff,
  Edit2,
  Trash2,
  CheckCircle2,
  AlertCircle,
  RotateCcw,
  LogIn,
  Check,
  X,
  Phone,
  Sparkles,
  Info,
} from 'lucide-react';
import { Language, StaffUser, StaffRole, StaffPermission } from '../../types';
import {
  ALL_STAFF_PERMISSIONS,
  ROLE_PRESETS,
  getStaffUsers,
  saveStaffUsers,
  createStaffUser,
  updateStaffUser,
  deleteStaffUser,
  resetDefaultStaffUsers,
  setCurrentStaffUser,
} from '../../services/staffUserService';

interface StaffUserManagerProps {
  currentUser: StaffUser | null;
  onUserChanged: (user: StaffUser) => void;
  language: Language;
}

const AVATAR_COLORS = [
  '#B4963C', // Étoile Gold
  '#0284c7', // Sky Blue
  '#ea580c', // Orange
  '#16a34a', // Emerald
  '#7c3aed', // Purple
  '#e11d48', // Rose
  '#0d9488', // Teal
  '#475569', // Slate
];

export const StaffUserManager: React.FC<StaffUserManagerProps> = ({
  currentUser,
  onUserChanged,
  language,
}) => {
  const isAr = language === 'ar';
  const [users, setUsers] = useState<StaffUser[]>(() => getStaffUsers());
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingUser, setEditingUser] = useState<StaffUser | null>(null);
  const [visiblePins, setVisiblePins] = useState<Record<string, boolean>>({});
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [actionErrorMsg, setActionErrorMsg] = useState<string | null>(null);

  // Form states for Add / Edit
  const [formNameAr, setFormNameAr] = useState('');
  const [formNameEn, setFormNameEn] = useState('');
  const [formPin, setFormPin] = useState('');
  const [formPhone, setFormPhone] = useState('');
  const [formRole, setFormRole] = useState<StaffRole>('cashier');
  const [formRoleTitleAr, setFormRoleTitleAr] = useState('');
  const [formRoleTitleEn, setFormRoleTitleEn] = useState('');
  const [formPermissions, setFormPermissions] = useState<StaffPermission[]>(['orders', 'kitchen']);
  const [formColor, setFormColor] = useState(AVATAR_COLORS[1]);
  const [formIsActive, setFormIsActive] = useState(true);

  const togglePinVisibility = (id: string) => {
    setVisiblePins((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const showNotification = (msg: string, isError = false) => {
    if (isError) {
      setActionErrorMsg(msg);
      setTimeout(() => setActionErrorMsg(null), 4000);
    } else {
      setActionSuccessMsg(msg);
      setTimeout(() => setActionSuccessMsg(null), 4000);
    }
  };

  // Open modal for new user
  const handleOpenAddModal = () => {
    setFormNameAr('');
    setFormNameEn('');
    setFormPin('');
    setFormPhone('');
    setFormRole('cashier');
    setFormRoleTitleAr(ROLE_PRESETS.cashier.title.ar);
    setFormRoleTitleEn(ROLE_PRESETS.cashier.title.en);
    setFormPermissions([...ROLE_PRESETS.cashier.defaultPermissions]);
    setFormColor(AVATAR_COLORS[1]);
    setFormIsActive(true);
    setShowAddModal(true);
  };

  // Open modal for editing user
  const handleOpenEditModal = (user: StaffUser) => {
    setEditingUser(user);
    setFormNameAr(user.name.ar);
    setFormNameEn(user.name.en);
    setFormPin(user.pin);
    setFormPhone(user.phone || '');
    setFormRole(user.role);
    setFormRoleTitleAr(user.roleTitle.ar);
    setFormRoleTitleEn(user.roleTitle.en);
    setFormPermissions([...user.permissions]);
    setFormColor(user.avatarColor || AVATAR_COLORS[0]);
    setFormIsActive(user.isActive);
  };

  // Role preset selection
  const handleRoleChange = (role: StaffRole) => {
    setFormRole(role);
    const preset = ROLE_PRESETS[role];
    if (preset) {
      setFormRoleTitleAr(preset.title.ar);
      setFormRoleTitleEn(preset.title.en);
      setFormPermissions([...preset.defaultPermissions]);
      setFormColor(preset.color);
    }
  };

  // Toggle permission in form
  const toggleFormPermission = (permId: StaffPermission) => {
    setFormPermissions((prev) =>
      prev.includes(permId) ? prev.filter((p) => p !== permId) : [...prev, permId]
    );
  };

  // Save new user
  const handleSaveNewUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formNameAr.trim() || !formPin.trim()) {
      showNotification(isAr ? 'يرجى إدخال اسم الموظف ورمز PIN' : 'Please enter staff name and PIN', true);
      return;
    }

    if (!/^\d{4}$/.test(formPin.trim())) {
      showNotification(isAr ? 'يجب أن يتكون رمز PIN من 4 أرقام' : 'PIN must be exactly 4 digits', true);
      return;
    }

    const res = createStaffUser({
      name: {
        ar: formNameAr.trim(),
        en: formNameEn.trim() || formNameAr.trim(),
      },
      pin: formPin.trim(),
      phone: formPhone.trim() || undefined,
      role: formRole,
      roleTitle: {
        ar: formRoleTitleAr.trim() || ROLE_PRESETS[formRole].title.ar,
        en: formRoleTitleEn.trim() || ROLE_PRESETS[formRole].title.en,
      },
      permissions: formPermissions,
      avatarColor: formColor,
      isActive: formIsActive,
    });

    if (res.success && res.user) {
      setUsers(getStaffUsers());
      setShowAddModal(false);
      showNotification(isAr ? `تم إضافة المستخدم "${res.user.name.ar}" بنجاح` : `User "${res.user.name.en}" added successfully`);
    } else {
      showNotification(res.error || (isAr ? 'فشلت إضافة المستخدم' : 'Failed to add user'), true);
    }
  };

  // Save edited user
  const handleSaveEditUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingUser) return;

    if (!formNameAr.trim() || !formPin.trim()) {
      showNotification(isAr ? 'يرجى إدخال اسم الموظف ورمز PIN' : 'Please enter staff name and PIN', true);
      return;
    }

    const res = updateStaffUser(editingUser.id, {
      name: {
        ar: formNameAr.trim(),
        en: formNameEn.trim() || formNameAr.trim(),
      },
      pin: formPin.trim(),
      phone: formPhone.trim() || undefined,
      role: formRole,
      roleTitle: {
        ar: formRoleTitleAr.trim() || ROLE_PRESETS[formRole].title.ar,
        en: formRoleTitleEn.trim() || ROLE_PRESETS[formRole].title.en,
      },
      permissions: formPermissions,
      avatarColor: formColor,
      isActive: formIsActive,
    });

    if (res.success && res.user) {
      setUsers(getStaffUsers());
      if (currentUser?.id === res.user.id) {
        onUserChanged(res.user);
      }
      setEditingUser(null);
      showNotification(isAr ? `تم تحديث بيانات "${res.user.name.ar}"` : `User "${res.user.name.en}" updated`);
    } else {
      showNotification(res.error || (isAr ? 'فشل تحديث البيانات' : 'Failed to update user'), true);
    }
  };

  // Delete user
  const handleDeleteUser = (user: StaffUser) => {
    if (user.pin === '9283') {
      showNotification(isAr ? 'لا يمكن حذف الحساب الإداري الرئيسي (9283)' : 'Cannot delete primary admin account', true);
      return;
    }

    if (window.confirm(isAr ? `هل أنت متأكد من حذف حساب "${user.name.ar}"؟` : `Are you sure you want to delete "${user.name.en}"?`)) {
      const res = deleteStaffUser(user.id);
      if (res.success) {
        setUsers(getStaffUsers());
        showNotification(isAr ? 'تم حذف المستخدم بنجاح' : 'User deleted successfully');
      } else {
        showNotification(res.error || 'Failed to delete user', true);
      }
    }
  };

  // Switch to this user immediately
  const handleSwitchToUser = (user: StaffUser) => {
    setCurrentStaffUser(user);
    onUserChanged(user);
    showNotification(isAr ? `تم التبديل إلى: ${user.name.ar}` : `Switched active session to: ${user.name.en}`);
  };

  // Reset defaults
  const handleResetDefaults = () => {
    if (window.confirm(isAr ? 'هل تريد استعادة الحسابات الافتراضية للفرع؟' : 'Reset all staff users to factory defaults?')) {
      const defs = resetDefaultStaffUsers();
      setUsers(defs);
      onUserChanged(defs[0]);
      showNotification(isAr ? 'تمت استعادة حسابات الموظفين الافتراضية' : 'Default staff users restored');
    }
  };

  return (
    <div className="space-y-6 animate-fadeIn pb-12">
      {/* Top Banner */}
      <div className="bg-white rounded-2xl sm:rounded-3xl p-5 sm:p-6 border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center shrink-0 border border-[#B4963C]/20 shadow-2xs">
            <Users className="w-6 h-6 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg sm:text-xl font-black text-stone-900 font-serif">
                {isAr ? 'إدارة موظفي الكاشير والصلاحيات' : 'Staff Users & Role-Based Access Control'}
              </h2>
              <span className="px-2.5 py-0.5 rounded-full bg-[#B4963C]/10 text-[#B4963C] text-xs font-mono font-bold border border-[#B4963C]/30">
                {users.length} {isAr ? 'موظفين' : 'Staff'}
              </span>
            </div>
            <p className="text-xs text-stone-500 mt-0.5">
              {isAr
                ? 'تخصيص أذونات الوصول للوحة الكاشير (المخزون، المنيو، التقارير، شاشة المطبخ، والطلبات) لكل موظف برمز PIN خاص'
                : 'Configure access permissions (Stock, Menu, Sales Analytics, KDS, Orders) per staff member via secure PIN'}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleResetDefaults}
            className="px-3.5 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold transition flex items-center gap-1.5 cursor-pointer"
            title={isAr ? 'استعادة الحسابات الأصلية' : 'Reset Defaults'}
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isAr ? 'استعادة الافتراضي' : 'Reset Defaults'}</span>
          </button>

          <button
            onClick={handleOpenAddModal}
            className="px-4 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 shadow-md shadow-[#B4963C]/20 cursor-pointer"
          >
            <UserPlus className="w-4 h-4" />
            <span>{isAr ? 'إضافة موظف جديد' : 'Add New Staff'}</span>
          </button>
        </div>
      </div>

      {/* Notifications */}
      {actionSuccessMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-emerald-800 text-xs font-bold flex items-center gap-2 animate-fadeIn">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{actionSuccessMsg}</span>
        </div>
      )}

      {actionErrorMsg && (
        <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-bold flex items-center gap-2 animate-fadeIn">
          <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
          <span>{actionErrorMsg}</span>
        </div>
      )}

      {/* Permissions Overview Legend */}
      <div className="bg-stone-50 border border-stone-200/90 rounded-2xl p-4">
        <h4 className="text-xs font-bold text-stone-700 flex items-center gap-1.5 mb-2.5">
          <Shield className="w-3.5 h-3.5 text-[#B4963C]" />
          <span>{isAr ? 'صلاحيات الوصول المتاحة في النظام:' : 'System Access Permissions Guide:'}</span>
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2 text-xs">
          {ALL_STAFF_PERMISSIONS.map((perm) => (
            <div
              key={perm.id}
              className="p-2 bg-white rounded-xl border border-stone-200 flex flex-col justify-between shadow-2xs"
            >
              <div className="font-bold text-stone-800">{perm.label[language]}</div>
              <div className="text-[10px] text-stone-500 mt-0.5 line-clamp-2 leading-relaxed">
                {perm.description[language]}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Users Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {users.map((user) => {
          const isCurrentUser = currentUser?.id === user.id;
          const isPinVisible = visiblePins[user.id] ?? false;

          return (
            <div
              key={user.id}
              className={`bg-white rounded-2xl sm:rounded-3xl border transition-all duration-200 p-5 flex flex-col justify-between space-y-4 shadow-xs hover:shadow-md ${
                isCurrentUser
                  ? 'border-2 border-[#B4963C] ring-2 ring-[#B4963C]/10'
                  : 'border-stone-200'
              }`}
            >
              {/* Header: Avatar, Name & Current User Badge */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-2xl text-white font-bold font-serif text-lg flex items-center justify-center shrink-0 shadow-sm"
                    style={{ backgroundColor: user.avatarColor || '#B4963C' }}
                  >
                    {user.name.ar.charAt(0)}
                  </div>
                  <div>
                    <div className="flex items-center gap-1.5">
                      <h3 className="text-sm sm:text-base font-black text-stone-900">
                        {user.name[language] || user.name.ar}
                      </h3>
                      {isCurrentUser && (
                        <span className="px-1.5 py-0.2 rounded-md bg-[#B4963C] text-white text-[9px] font-bold">
                          {isAr ? 'نشط الآن' : 'Current'}
                        </span>
                      )}
                    </div>
                    <span
                      className="inline-block mt-0.5 px-2 py-0.5 rounded-full text-[10px] font-bold text-white shadow-2xs"
                      style={{ backgroundColor: user.avatarColor || '#B4963C' }}
                    >
                      {user.roleTitle[language] || user.roleTitle.ar}
                    </span>
                  </div>
                </div>

                {/* PIN Code Box */}
                <div className="flex items-center gap-1 bg-stone-50 border border-stone-200 px-2 py-1 rounded-xl">
                  <KeyRound className="w-3.5 h-3.5 text-[#B4963C]" />
                  <span className="font-mono font-bold text-xs text-stone-800">
                    {isPinVisible ? user.pin : '••••'}
                  </span>
                  <button
                    onClick={() => togglePinVisibility(user.id)}
                    className="text-stone-400 hover:text-stone-700 p-0.5 cursor-pointer"
                    title={isPinVisible ? 'Hide PIN' : 'Show PIN'}
                  >
                    {isPinVisible ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                  </button>
                </div>
              </div>

              {/* Contact info if any */}
              {user.phone && (
                <div className="flex items-center gap-1.5 text-xs text-stone-500 font-mono">
                  <Phone className="w-3.5 h-3.5 text-stone-400" />
                  <span>{user.phone}</span>
                </div>
              )}

              {/* Assigned Permissions Tags */}
              <div className="space-y-1.5 pt-2 border-t border-stone-100">
                <span className="text-[10px] uppercase font-bold text-stone-400 block tracking-wider">
                  {isAr ? 'الصلاحيات الممنوحة:' : 'Assigned Permissions:'}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {ALL_STAFF_PERMISSIONS.map((perm) => {
                    const hasPerm = user.permissions.includes(perm.id) || user.role === 'admin';
                    return (
                      <span
                        key={perm.id}
                        className={`px-2 py-0.8 rounded-lg text-[10px] font-bold flex items-center gap-1 transition ${
                          hasPerm
                            ? 'bg-amber-50 text-[#876E27] border border-[#B4963C]/30'
                            : 'bg-stone-100/60 text-stone-400 border border-stone-200 line-through opacity-50'
                        }`}
                      >
                        {hasPerm && <Check className="w-2.5 h-2.5 text-[#B4963C]" />}
                        <span>{perm.label[language]}</span>
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Actions Footer */}
              <div className="pt-3 border-t border-stone-100 flex items-center justify-between gap-2">
                {!isCurrentUser ? (
                  <button
                    onClick={() => handleSwitchToUser(user)}
                    className="flex-1 py-2 px-3 bg-stone-100 hover:bg-[#B4963C] hover:text-white text-stone-700 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <LogIn className="w-3.5 h-3.5" />
                    <span>{isAr ? 'دخول بهذا الحساب' : 'Switch Session'}</span>
                  </button>
                ) : (
                  <div className="flex-1 text-xs font-bold text-[#B4963C] flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" />
                    <span>{isAr ? 'جلستك الحالية' : 'Active Session'}</span>
                  </div>
                )}

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => handleOpenEditModal(user)}
                    className="p-2 text-stone-500 hover:text-[#B4963C] hover:bg-stone-100 rounded-xl transition cursor-pointer"
                    title={isAr ? 'تعديل البيانات والصلاحيات' : 'Edit User & Permissions'}
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>

                  {user.pin !== '9283' && (
                    <button
                      onClick={() => handleDeleteUser(user)}
                      className="p-2 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition cursor-pointer"
                      title={isAr ? 'حذف الحساب' : 'Delete User'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ========================================================
          ADD NEW USER MODAL
      ======================================================== */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-lg bg-white border border-stone-200 rounded-3xl shadow-2xl p-5 sm:p-6 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setShowAddModal(false)}
              className="absolute top-4 end-4 p-1.5 rounded-full text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-stone-100">
              <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center">
                <UserPlus className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-stone-900">
                  {isAr ? 'إضافة موظف جديد وتحديد الصلاحيات' : 'Add Staff Member & Permissions'}
                </h3>
                <p className="text-xs text-stone-500">
                  {isAr ? 'أدخل تفاصيل الحساب ورمز PIN واضبط الصلاحيات المسموحة' : 'Enter user info, set 4-digit PIN and permissions'}
                </p>
              </div>
            </div>

            <form onSubmit={handleSaveNewUser} className="space-y-4 text-xs">
              {/* Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'الاسم باللغة العربية *' : 'Name (Arabic) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formNameAr}
                    onChange={(e) => setFormNameAr(e.target.value)}
                    placeholder={isAr ? 'مثال: محمود عثمان' : 'e.g. Mahmoud Osman'}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C]"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'الاسم بالإنجليزية' : 'Name (English)'}
                  </label>
                  <input
                    type="text"
                    value={formNameEn}
                    onChange={(e) => setFormNameEn(e.target.value)}
                    placeholder="e.g. Mahmoud Osman"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C]"
                  />
                </div>
              </div>

              {/* PIN & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'رمز PIN السري (4 أرقام) *' : 'Secret PIN (4 Digits) *'}
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    required
                    value={formPin}
                    onChange={(e) => setFormPin(e.target.value.replace(/\D/g, ''))}
                    placeholder="1234"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 font-mono font-bold tracking-widest text-center text-sm outline-none focus:border-[#B4963C]"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'رقم الهاتف (اختياري)' : 'Phone Number (Optional)'}
                  </label>
                  <input
                    type="tel"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    placeholder="01XXXXXXXXX"
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 font-mono outline-none focus:border-[#B4963C]"
                  />
                </div>
              </div>

              {/* Role Presets */}
              <div>
                <label className="font-bold text-stone-700 block mb-1.5">
                  {isAr ? 'القالب الوظيفي المقترح:' : 'Role Preset:'}
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {(Object.keys(ROLE_PRESETS) as StaffRole[]).map((r) => {
                    const preset = ROLE_PRESETS[r];
                    const isSelected = formRole === r;
                    return (
                      <button
                        key={r}
                        type="button"
                        onClick={() => handleRoleChange(r)}
                        className={`p-2 rounded-xl border text-start transition cursor-pointer ${
                          isSelected
                            ? 'border-[#B4963C] bg-[#B4963C]/10 text-[#876E27] font-bold shadow-2xs'
                            : 'border-stone-200 bg-stone-50 text-stone-600 hover:border-stone-300'
                        }`}
                      >
                        <span className="block truncate">{preset.title[language]}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Granular Permissions Checkboxes */}
              <div className="space-y-2 pt-2 border-t border-stone-100">
                <label className="font-bold text-stone-700 block">
                  {isAr ? 'تحديد الصلاحيات الدقيقة:' : 'Granular Permissions Selection:'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {ALL_STAFF_PERMISSIONS.map((perm) => {
                    const isChecked = formPermissions.includes(perm.id);
                    return (
                      <label
                        key={perm.id}
                        onClick={() => toggleFormPermission(perm.id)}
                        className={`p-2.5 rounded-xl border flex items-start gap-2.5 cursor-pointer transition select-none ${
                          isChecked
                            ? 'bg-amber-50/70 border-[#B4963C]/50 text-stone-900 shadow-2xs'
                            : 'bg-stone-50 border-stone-200 text-stone-500 hover:border-stone-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="mt-0.5 rounded text-[#B4963C] focus:ring-[#B4963C]"
                        />
                        <div>
                          <span className="font-bold text-xs block">{perm.label[language]}</span>
                          <span className="text-[10px] text-stone-500 block leading-tight mt-0.5">
                            {perm.description[language]}
                          </span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Avatar Color Picker */}
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                <label className="font-bold text-stone-700">
                  {isAr ? 'لون الهوية / الشارة:' : 'Badge Color:'}
                </label>
                <div className="flex items-center gap-1.5">
                  {AVATAR_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormColor(c)}
                      className={`w-6 h-6 rounded-full transition-transform cursor-pointer ${
                        formColor === c ? 'scale-125 ring-2 ring-offset-2 ring-stone-400' : 'hover:scale-110'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-stone-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-bold cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl font-bold shadow-md shadow-[#B4963C]/20 cursor-pointer"
                >
                  {isAr ? 'حفظ وإضافة الموظف' : 'Save & Add Staff'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================
          EDIT USER MODAL
      ======================================================== */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-fadeIn">
          <div className="w-full max-w-lg bg-white border border-stone-200 rounded-3xl shadow-2xl p-5 sm:p-6 relative max-h-[90vh] overflow-y-auto">
            <button
              onClick={() => setEditingUser(null)}
              className="absolute top-4 end-4 p-1.5 rounded-full text-stone-400 hover:text-stone-800 hover:bg-stone-100 transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-2.5 mb-5 pb-3 border-b border-stone-100">
              <div className="w-10 h-10 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center">
                <Edit2 className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-base sm:text-lg font-black text-stone-900">
                  {isAr ? `تعديل حساب: ${editingUser.name.ar}` : `Edit Account: ${editingUser.name.en}`}
                </h3>
                <p className="text-xs text-stone-500">
                  {isAr ? 'تعديل رمز PIN والصلاحيات المعينة' : 'Update secret PIN and access rights'}
                </p>
              </div>
            </div>

            <form onSubmit={handleSaveEditUser} className="space-y-4 text-xs">
              {/* Names */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'الاسم باللغة العربية *' : 'Name (Arabic) *'}
                  </label>
                  <input
                    type="text"
                    required
                    value={formNameAr}
                    onChange={(e) => setFormNameAr(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C]"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'الاسم بالإنجليزية' : 'Name (English)'}
                  </label>
                  <input
                    type="text"
                    value={formNameEn}
                    onChange={(e) => setFormNameEn(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 outline-none focus:border-[#B4963C]"
                  />
                </div>
              </div>

              {/* PIN & Phone */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'رمز PIN السري (4 أرقام) *' : 'Secret PIN (4 Digits) *'}
                  </label>
                  <input
                    type="text"
                    maxLength={4}
                    required
                    value={formPin}
                    onChange={(e) => setFormPin(e.target.value.replace(/\D/g, ''))}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 font-mono font-bold tracking-widest text-center text-sm outline-none focus:border-[#B4963C]"
                  />
                </div>
                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    {isAr ? 'رقم الهاتف (اختياري)' : 'Phone Number (Optional)'}
                  </label>
                  <input
                    type="tel"
                    value={formPhone}
                    onChange={(e) => setFormPhone(e.target.value)}
                    className="w-full px-3 py-2 bg-stone-50 border border-stone-200 rounded-xl text-stone-900 font-mono outline-none focus:border-[#B4963C]"
                  />
                </div>
              </div>

              {/* Granular Permissions Checkboxes */}
              <div className="space-y-2 pt-2 border-t border-stone-100">
                <label className="font-bold text-stone-700 block">
                  {isAr ? 'تعديل الصلاحيات الممنوحة:' : 'Update Assigned Permissions:'}
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  {ALL_STAFF_PERMISSIONS.map((perm) => {
                    const isChecked = formPermissions.includes(perm.id);
                    return (
                      <label
                        key={perm.id}
                        onClick={() => toggleFormPermission(perm.id)}
                        className={`p-2.5 rounded-xl border flex items-start gap-2.5 cursor-pointer transition select-none ${
                          isChecked
                            ? 'bg-amber-50/70 border-[#B4963C]/50 text-stone-900 shadow-2xs'
                            : 'bg-stone-50 border-stone-200 text-stone-500 hover:border-stone-300'
                        }`}
                      >
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="mt-0.5 rounded text-[#B4963C] focus:ring-[#B4963C]"
                        />
                        <div>
                          <span className="font-bold text-xs block">{perm.label[language]}</span>
                          <span className="text-[10px] text-stone-500 block leading-tight mt-0.5">
                            {perm.description[language]}
                          </span>
                        </div>
                      </label>
                    );
                  })}
                </div>
              </div>

              {/* Avatar Color Picker */}
              <div className="pt-2 border-t border-stone-100 flex items-center justify-between">
                <label className="font-bold text-stone-700">
                  {isAr ? 'لون الشارة:' : 'Badge Color:'}
                </label>
                <div className="flex items-center gap-1.5">
                  {AVATAR_COLORS.map((c) => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setFormColor(c)}
                      className={`w-6 h-6 rounded-full transition-transform cursor-pointer ${
                        formColor === c ? 'scale-125 ring-2 ring-offset-2 ring-stone-400' : 'hover:scale-110'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="pt-4 border-t border-stone-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setEditingUser(null)}
                  className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl font-bold cursor-pointer"
                >
                  {isAr ? 'إلغاء' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white rounded-xl font-bold shadow-md shadow-[#B4963C]/20 cursor-pointer"
                >
                  {isAr ? 'تأكيد التعديلات' : 'Update Staff Account'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
