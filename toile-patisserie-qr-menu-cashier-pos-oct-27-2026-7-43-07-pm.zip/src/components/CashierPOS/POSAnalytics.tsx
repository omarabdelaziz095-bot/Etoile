import React from 'react';
import {
  TrendingUp,
  DollarSign,
  ShoppingBag,
  Download,
  Award,
  BarChart,
  PieChart,
} from 'lucide-react';
import { Order, Language } from '../../types';

interface POSAnalyticsProps {
  orders: Order[];
  language: Language;
}

export const POSAnalytics: React.FC<POSAnalyticsProps> = ({ orders, language }) => {
  const isAr = language === 'ar';

  // Calculate metrics
  const totalSales = orders.reduce((sum, o) => sum + (o.status !== 'cancelled' ? o.total : 0), 0);
  const totalTax = orders.reduce((sum, o) => sum + (o.status !== 'cancelled' ? o.tax : 0), 0);
  const completedOrders = orders.filter((o) => o.status === 'completed');
  const avgTicket = orders.length > 0 ? Math.round(totalSales / orders.length) : 0;

  // Dine in vs Takeaway breakdown
  const dineInCount = orders.filter((o) => o.diningMode === 'dine_in').length;
  const takeawayCount = orders.filter((o) => o.diningMode === 'takeaway').length;

  // Hourly distribution for SVG chart (0 to 23 hours)
  const hourlyData: Record<number, number> = {};
  for (let i = 8; i <= 23; i++) {
    hourlyData[i] = 0;
  }
  orders.forEach((o) => {
    const hour = new Date(o.createdAt).getHours();
    if (hourlyData[hour] !== undefined) {
      hourlyData[hour] += o.total;
    } else {
      hourlyData[hour] = o.total;
    }
  });

  const maxHourlySales = Math.max(...Object.values(hourlyData), 100);

  // Top selling items
  const itemCounts: Record<string, { count: number; title: string; revenue: number }> = {};
  orders.forEach((o) => {
    o.items.forEach((item) => {
      const key = item.itemId;
      if (!itemCounts[key]) {
        itemCounts[key] = {
          count: 0,
          title: item.title[language],
          revenue: 0,
        };
      }
      itemCounts[key].count += item.quantity;
      itemCounts[key].revenue += item.totalPrice;
    });
  });

  const topItems = Object.values(itemCounts)
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Export Data to CSV (without payment method)
  const handleExportCSV = () => {
    const headers = ['Invoice', 'Date', 'Time', 'Dining Mode', 'Table/Customer', 'Items Count', 'Subtotal', 'Tax (14%)', 'Total (EGP)', 'Status'];
    const rows = orders.map((o) => [
      o.invoiceNumber,
      new Date(o.createdAt).toLocaleDateString(),
      new Date(o.createdAt).toLocaleTimeString(),
      o.diningMode,
      o.diningMode === 'dine_in' ? `Table ${o.tableNumber}` : o.customerName || 'Takeaway',
      o.items.reduce((acc, i) => acc + i.quantity, 0),
      o.subtotal,
      o.tax,
      o.total,
      o.status,
    ]);

    const csvContent =
      '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Etoile_Sales_Report_${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Top Controls: Title & CSV Export */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-stone-200 shadow-xs">
        <div>
          <h2 className="text-xl font-black text-stone-900 flex items-center gap-2">
            <BarChart className="w-5 h-5 text-[#B4963C]" />
            <span>{isAr ? 'لوحة تقارير وإحصائيات المبيعات' : 'Sales Analytics & Revenue'}</span>
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            {isAr ? 'متابعة حية للإيرادات ومتوسط الفاتورة وحركة الصالة والتيك أواي' : 'Live overview of revenue, average ticket, and dining breakdown'}
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2.5 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-xl text-xs sm:text-sm transition cursor-pointer shadow-md shadow-[#B4963C]/20 active:scale-95"
        >
          <Download className="w-4 h-4 stroke-[2.5]" />
          <span>{isAr ? 'تصدير شيت المبيعات (CSV / Excel)' : 'Export Sales to CSV'}</span>
        </button>
      </div>

      {/* 4 Key Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total Sales */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-bold uppercase tracking-wider">
              {isAr ? 'إجمالي المبيعات' : 'Total Revenue'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-[#B4963C]/10 text-[#B4963C] flex items-center justify-center">
              <DollarSign className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black font-mono text-stone-900">
              {totalSales.toLocaleString()} <span className="text-xs text-[#B4963C] font-bold">{isAr ? 'ج.م' : 'EGP'}</span>
            </div>
            <p className="text-[11px] text-emerald-600 font-medium mt-1">
              +14% {isAr ? 'شامل القيمة المضافة' : 'incl. VAT'} ({totalTax} {isAr ? 'ج.م' : 'EGP'})
            </p>
          </div>
        </div>

        {/* Total Orders */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-bold uppercase tracking-wider">
              {isAr ? 'إجمالي عدد الطلبات' : 'Total Orders'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <ShoppingBag className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black font-mono text-stone-900">
              {orders.length}
            </div>
            <p className="text-[11px] text-stone-500 mt-1">
              {completedOrders.length} {isAr ? 'طلب مكتمل ومسلم' : 'orders completed'}
            </p>
          </div>
        </div>

        {/* Average Ticket Size */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-bold uppercase tracking-wider">
              {isAr ? 'متوسط قيمة الفاتورة' : 'Average Ticket'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="text-2xl sm:text-3xl font-black font-mono text-[#B4963C]">
              {avgTicket} <span className="text-xs text-stone-500 font-bold">{isAr ? 'ج.م' : 'EGP'}</span>
            </div>
            <p className="text-[11px] text-stone-500 mt-1">
              {isAr ? 'لكل عملية طلب' : 'per customer order'}
            </p>
          </div>
        </div>

        {/* Dining Distribution */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs text-stone-500 font-bold uppercase tracking-wider">
              {isAr ? 'حركة الصالة والتيك أواي' : 'Dining Channels'}
            </span>
            <div className="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <PieChart className="w-5 h-5" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-3 text-sm font-bold">
              <span className="text-[#B4963C]">🍽 {dineInCount} {isAr ? 'صالة' : 'Dine-In'}</span>
              <span className="text-stone-300">/</span>
              <span className="text-blue-600">🛍 {takeawayCount} {isAr ? 'تيك أواي' : 'Takeaway'}</span>
            </div>
            <div className="w-full bg-stone-100 h-2 rounded-full overflow-hidden flex mt-2">
              <div
                style={{ width: `${orders.length ? (dineInCount / orders.length) * 100 : 50}%` }}
                className="bg-[#B4963C] h-full"
              ></div>
              <div
                style={{ width: `${orders.length ? (takeawayCount / orders.length) * 100 : 50}%` }}
                className="bg-blue-500 h-full"
              ></div>
            </div>
          </div>
        </div>
      </div>

      {/* Graphical Dashboard: Hourly Sales Chart + Top Items */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Hourly Sales Bar Chart (SVG) */}
        <div className="lg:col-span-2 bg-white p-5 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                {isAr ? 'توزيع المبيعات على مدار ساعات العمل (ج.م)' : 'Hourly Sales Distribution (EGP)'}
              </h3>
              <p className="text-xs text-stone-500">
                {isAr ? 'من 8:00 صباحاً حتى 12:00 منتصف الليل' : 'From 8:00 AM to 12:00 Midnight'}
              </p>
            </div>
          </div>

          {/* SVG Bar Chart */}
          <div className="pt-4">
            <div className="h-44 flex items-end gap-1.5 sm:gap-3 px-2 border-b border-stone-200">
              {Object.entries(hourlyData).map(([hour, val]) => {
                const heightPercent = Math.max(8, (val / maxHourlySales) * 100);
                return (
                  <div key={hour} className="flex-1 flex flex-col items-center gap-1.5 group relative">
                    {/* Tooltip */}
                    <div className="absolute -top-8 bg-stone-900 text-[#B4963C] text-[10px] font-mono font-bold px-1.5 py-0.5 rounded opacity-0 group-hover:opacity-100 transition pointer-events-none whitespace-nowrap shadow-md z-10">
                      {val} ج.م
                    </div>
                    {/* Bar */}
                    <div
                      style={{ height: `${heightPercent}%` }}
                      className={`w-full rounded-t-lg transition-all duration-300 ${
                        val > 0
                          ? 'bg-gradient-to-t from-[#9E8232] to-[#B4963C] group-hover:brightness-110'
                          : 'bg-stone-100'
                      }`}
                    ></div>
                    {/* Label */}
                    <span className="text-[9px] text-stone-500 font-mono font-medium">
                      {hour}:00
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Top Selling Pastries & Items */}
        <div className="bg-white p-5 rounded-3xl border border-stone-200 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
              <Award className="w-4 h-4 text-[#B4963C]" />
              <span>{isAr ? 'الأكثر طلباً ومبيعاً' : 'Top Selling Items'}</span>
            </h3>
          </div>

          <div className="space-y-2.5">
            {topItems.length === 0 ? (
              <p className="text-xs text-stone-400 text-center py-8 font-medium">
                {isAr ? 'لا توجد بيانات كافية بعد' : 'No sales data yet'}
              </p>
            ) : (
              topItems.map((item, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-3 bg-stone-50 rounded-2xl border border-stone-200/80"
                >
                  <div className="flex items-center gap-2.5">
                    <span className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-black font-mono ${
                      idx === 0
                        ? 'bg-[#B4963C] text-white shadow-2xs'
                        : idx === 1
                        ? 'bg-stone-200 text-stone-800'
                        : 'bg-stone-100 text-stone-600'
                    }`}>
                      #{idx + 1}
                    </span>
                    <div>
                      <h4 className="text-xs font-bold text-stone-900 line-clamp-1">
                        {item.title}
                      </h4>
                      <span className="text-[10px] text-stone-500 font-medium">
                        {item.count} {isAr ? 'طلب' : 'sold'}
                      </span>
                    </div>
                  </div>

                  <span className="text-xs font-bold font-mono text-[#B4963C]">
                    {item.revenue} {isAr ? 'ج.م' : 'EGP'}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
