import React, { useState, useEffect } from 'react';
import {
  Clock,
  Printer,
  CookingPot,
  CheckCircle,
  Search,
  UtensilsCrossed,
  ShoppingBag,
  User,
  Phone,
  FileText,
  Flame,
  Check,
  Eye,
  X,
  Sparkles,
} from 'lucide-react';
import { Order, OrderStatus, Language } from '../../types';
import { updateOrderStatus } from '../../services/firebaseService';
import { audioService } from '../../services/audioService';
import { printThermalReceipt, printKitchenSlip } from '../../services/printService';

interface OrderStreamProps {
  orders: Order[];
  language: Language;
  onOpenThermalReceipt: (order: Order) => void;
  onOpenKitchenDisplay: (order: Order) => void;
}

export const OrderStream: React.FC<OrderStreamProps> = ({
  orders,
  language,
  onOpenThermalReceipt,
  onOpenKitchenDisplay,
}) => {
  const isAr = language === 'ar';

  // Quick-filter tabs state: 'all' | 'new' | 'preparing' | 'completed'
  const [statusFilter, setStatusFilter] = useState<'all' | OrderStatus>('all');
  const [diningFilter, setDiningFilter] = useState<'all' | 'dine_in' | 'takeaway'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [lastKnownOrderCount, setLastKnownOrderCount] = useState<number>(orders.length);
  const [transitioningOrderId, setTransitioningOrderId] = useState<string | null>(null);

  // Trigger audio alert when a brand new order comes in
  useEffect(() => {
    const newOrders = orders.filter((o) => o.status === 'new');
    if (orders.length > lastKnownOrderCount && newOrders.length > 0) {
      audioService.playNewOrderAlert();
    }
    setLastKnownOrderCount(orders.length);
  }, [orders, lastKnownOrderCount]);

  // Handle status transitions inline WITHOUT changing open tab or force-opening intrusive modals
  const handleTransitionStatus = async (order: Order, nextStatus: OrderStatus) => {
    setTransitioningOrderId(order.id);
    try {
      await updateOrderStatus(order.id, nextStatus);

      if (nextStatus === 'preparing') {
        audioService.playKitchenBell();
      } else if (nextStatus === 'completed') {
        audioService.playSuccessChime();
      }
    } finally {
      setTransitioningOrderId(null);
    }
  };

  // Direct fast print without leaving screen or opening modal
  const handleFastPrintThermal = (order: Order, e: React.MouseEvent) => {
    e.stopPropagation();
    printThermalReceipt(order, language);
  };

  const handleFastPrintKitchen = (order: Order, e: React.MouseEvent) => {
    e.stopPropagation();
    printKitchenSlip(order, language);
  };

  // Filter orders according to active quick-filter tab, dining mode, and search
  const filteredOrders = orders.filter((order) => {
    // 1. Status Filter Tab
    if (statusFilter !== 'all' && order.status !== statusFilter) {
      return false;
    }

    // 2. Dining Mode Filter
    if (diningFilter !== 'all' && order.diningMode !== diningFilter) {
      return false;
    }

    // 3. Search Query Filter
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      const matchInv = order.invoiceNumber.toLowerCase().includes(q);
      const matchTable = !!order.tableNumber && order.tableNumber.toLowerCase().includes(q);
      const matchName = !!order.customerName && order.customerName.toLowerCase().includes(q);
      const matchPhone = !!order.customerPhone && order.customerPhone.includes(q);
      const matchItem = order.items.some(
        (it) => it.title.ar?.toLowerCase().includes(q) || it.title.en?.toLowerCase().includes(q)
      );
      if (!matchInv && !matchTable && !matchName && !matchPhone && !matchItem) {
        return false;
      }
    }

    return true;
  });

  const countByStatus = {
    all: orders.length,
    new: orders.filter((o) => o.status === 'new').length,
    preparing: orders.filter((o) => o.status === 'preparing').length,
    completed: orders.filter((o) => o.status === 'completed').length,
  };

  const countByDining = {
    dine_in: orders.filter((o) => o.diningMode === 'dine_in').length,
    takeaway: orders.filter((o) => o.diningMode === 'takeaway').length,
  };

  return (
    <div className="space-y-4">
      {/* ========================================================
          TOP QUICK-FILTER TABS BAR (Kitchen & Cashier Flow)
          Allows quick filtering by New, Preparing, and Completed
          without changing open tabs or navigating away
      ======================================================== */}
      <div className="bg-white p-3.5 sm:p-4 rounded-3xl border border-stone-200 shadow-xs space-y-3">
        {/* Main Quick-Filter Status Tabs */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="flex items-center gap-1.5 p-1 bg-stone-100 rounded-2xl border border-stone-200/90 overflow-x-auto no-scrollbar">
            {/* Tab: ALL */}
            <button
              onClick={() => setStatusFilter('all')}
              className={`flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-stone-900 text-white shadow-sm'
                  : 'text-stone-600 hover:text-stone-900 hover:bg-stone-200/60'
              }`}
            >
              <span>{isAr ? 'جميع الطلبات' : 'All Orders'}</span>
              <span
                className={`text-[11px] px-1.5 py-0.5 rounded-md font-mono font-bold ${
                  statusFilter === 'all' ? 'bg-white/20 text-white' : 'bg-stone-200 text-stone-700'
                }`}
              >
                {countByStatus.all}
              </span>
            </button>

            {/* Tab: NEW (RED) */}
            <button
              onClick={() => setStatusFilter('new')}
              className={`flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer ${
                statusFilter === 'new'
                  ? 'bg-rose-600 text-white shadow-md shadow-rose-600/30 ring-2 ring-rose-400'
                  : 'text-rose-700 hover:bg-rose-50'
              }`}
            >
              {countByStatus.new > 0 && (
                <span className="w-2.5 h-2.5 rounded-full bg-rose-400 animate-ping"></span>
              )}
              <span>{isAr ? 'طلبات جديدة (وارد)' : 'New Orders'}</span>
              <span
                className={`text-[11px] px-1.5 py-0.5 rounded-md font-mono font-bold ${
                  statusFilter === 'new' ? 'bg-white/20 text-white' : 'bg-rose-100 text-rose-700'
                }`}
              >
                {countByStatus.new}
              </span>
            </button>

            {/* Tab: PREPARING (GREEN) */}
            <button
              onClick={() => setStatusFilter('preparing')}
              className={`flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer ${
                statusFilter === 'preparing'
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30 ring-2 ring-emerald-400'
                  : 'text-emerald-700 hover:bg-emerald-50'
              }`}
            >
              <CookingPot className="w-4 h-4" />
              <span>{isAr ? 'قيد التجهيز بالمطبخ' : 'In Prep'}</span>
              <span
                className={`text-[11px] px-1.5 py-0.5 rounded-md font-mono font-bold ${
                  statusFilter === 'preparing'
                    ? 'bg-white/20 text-white'
                    : 'bg-emerald-100 text-emerald-700'
                }`}
              >
                {countByStatus.preparing}
              </span>
            </button>

            {/* Tab: COMPLETED (GRAY / GOLD) */}
            <button
              onClick={() => setStatusFilter('completed')}
              className={`flex-1 sm:flex-none px-3.5 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center justify-center gap-2 whitespace-nowrap cursor-pointer ${
                statusFilter === 'completed'
                  ? 'bg-[#B4963C] text-white shadow-md shadow-[#B4963C]/30 ring-2 ring-[#B4963C]/40'
                  : 'text-stone-600 hover:bg-stone-200/60'
              }`}
            >
              <CheckCircle className="w-4 h-4" />
              <span>{isAr ? 'مكتمل ومنتهي' : 'Completed'}</span>
              <span
                className={`text-[11px] px-1.5 py-0.5 rounded-md font-mono font-bold ${
                  statusFilter === 'completed'
                    ? 'bg-white/20 text-white'
                    : 'bg-stone-200 text-stone-700'
                }`}
              >
                {countByStatus.completed}
              </span>
            </button>
          </div>

          {/* Search Input */}
          <div className="relative w-full sm:w-72">
            <Search className="w-4 h-4 text-stone-400 absolute inset-y-0 start-3 my-auto pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isAr
                  ? 'بحث بالفاتورة (#1001)، طاولة، هاتف...'
                  : 'Search by invoice #, table, phone...'
              }
              className="w-full ps-9 pe-8 py-2.5 bg-stone-50 border border-stone-200 rounded-xl text-xs sm:text-sm text-stone-900 placeholder-stone-400 focus:border-[#B4963C] focus:bg-white outline-none transition"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute inset-y-0 end-2.5 my-auto text-stone-400 hover:text-stone-700 p-1 rounded-md"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Sub-bar: Dining mode filter & Queue speed indicators */}
        <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-stone-100 text-xs">
          <div className="flex items-center gap-1.5">
            <span className="text-[11px] font-bold text-stone-400 uppercase tracking-wider me-1">
              {isAr ? 'نوع الطلب:' : 'Dining:'}
            </span>
            <button
              onClick={() => setDiningFilter('all')}
              className={`px-2.5 py-1 rounded-lg font-bold transition cursor-pointer ${
                diningFilter === 'all'
                  ? 'bg-stone-800 text-white'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              {isAr ? 'الكل' : 'All'}
            </button>
            <button
              onClick={() => setDiningFilter('dine_in')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                diningFilter === 'dine_in'
                  ? 'bg-[#B4963C] text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              <UtensilsCrossed className="w-3 h-3" />
              <span>{isAr ? 'صالة' : 'Dine-In'}</span>
              <span className="text-[10px] opacity-75 font-mono">({countByDining.dine_in})</span>
            </button>
            <button
              onClick={() => setDiningFilter('takeaway')}
              className={`px-2.5 py-1 rounded-lg font-bold transition flex items-center gap-1 cursor-pointer ${
                diningFilter === 'takeaway'
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-stone-100 text-stone-600 hover:bg-stone-200'
              }`}
            >
              <ShoppingBag className="w-3 h-3" />
              <span>{isAr ? 'تيك أواي' : 'Takeaway'}</span>
              <span className="text-[10px] opacity-75 font-mono">({countByDining.takeaway})</span>
            </button>
          </div>

          <div className="flex items-center gap-3 text-stone-500 font-medium">
            <span className="flex items-center gap-1">
              <Flame className="w-3.5 h-3.5 text-[#B4963C]" />
              <span>
                {isAr ? 'طابور المطبخ النشط:' : 'Kitchen Queue:'}{' '}
                <strong className="text-stone-900 font-mono">
                  {countByStatus.new + countByStatus.preparing}
                </strong>
              </span>
            </span>
            <span>•</span>
            <span className="text-emerald-700 font-semibold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>{isAr ? 'تحديث لحظي مباشر' : 'Live Sync'}</span>
            </span>
          </div>
        </div>
      </div>

      {/* ========================================================
          ORDERS STREAM GRID
      ======================================================== */}
      {filteredOrders.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-stone-200 shadow-xs space-y-3">
          <div className="w-16 h-16 rounded-3xl bg-stone-100 text-stone-400 flex items-center justify-center mx-auto">
            <UtensilsCrossed className="w-8 h-8 text-[#B4963C]" />
          </div>
          <h3 className="text-base font-bold text-stone-800">
            {isAr ? 'لا توجد طلبات في هذا القسم' : 'No orders in this filter'}
          </h3>
          <p className="text-xs text-stone-500">
            {isAr
              ? 'الطلبات الواردة من منيو الـ QR يتم تحديثها تلقائياً بدون الحاجة لتحديث الصفحة'
              : 'Incoming QR menu orders update automatically in real-time without page reload'}
          </p>
          {(statusFilter !== 'all' || diningFilter !== 'all' || searchQuery) && (
            <button
              onClick={() => {
                setStatusFilter('all');
                setDiningFilter('all');
                setSearchQuery('');
              }}
              className="px-4 py-2 bg-[#B4963C] hover:bg-[#9E8232] text-white text-xs font-bold rounded-xl transition cursor-pointer shadow-xs"
            >
              {isAr ? 'إعادة ضبط الفلاتر وعرض الكل' : 'Reset Filters & Show All'}
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredOrders.map((order) => {
            const isNew = order.status === 'new';
            const isPrep = order.status === 'preparing';
            const isCompleted = order.status === 'completed';
            const isTransitioning = transitioningOrderId === order.id;

            let cardClasses = '';
            let badgeClasses = '';
            let statusLabel = '';

            if (isNew) {
              cardClasses =
                'bg-rose-50/90 border-2 border-rose-500 text-rose-950 shadow-md shadow-rose-100';
              badgeClasses = 'bg-rose-600 text-white font-bold';
              statusLabel = isAr ? 'طلب جديد وارد 🔔' : 'New Order';
            } else if (isPrep) {
              cardClasses =
                'bg-emerald-50/90 border-2 border-emerald-500 text-emerald-950 shadow-md shadow-emerald-100';
              badgeClasses = 'bg-emerald-600 text-white font-bold';
              statusLabel = isAr ? 'قيد التجهيز بالمطبخ 👨‍🍳' : 'In Preparation';
            } else {
              cardClasses = 'bg-white border border-stone-200 text-stone-800 shadow-xs';
              badgeClasses = 'bg-stone-100 text-stone-700 border border-stone-200';
              statusLabel = isAr ? 'مكتمل ومسلم ✔' : 'Completed';
            }

            const minutesAgo = Math.floor((Date.now() - order.createdAt) / 60000);

            return (
              <div
                key={order.id}
                className={`rounded-3xl p-5 transition-all flex flex-col justify-between gap-4 ${cardClasses} ${
                  isTransitioning ? 'opacity-70 pointer-events-none' : ''
                }`}
              >
                {/* Order Top Ribbon */}
                <div>
                  <div className="flex items-start justify-between gap-2 border-b border-black/10 pb-3">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-2xl font-black font-mono tracking-wider text-stone-900">
                          {order.invoiceNumber}
                        </span>
                        <span
                          className={`text-[11px] px-2.5 py-0.5 rounded-lg uppercase tracking-wide ${badgeClasses}`}
                        >
                          {statusLabel}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-stone-500 mt-1 font-medium">
                        <Clock className="w-3.5 h-3.5 text-[#B4963C]" />
                        <span>
                          {new Date(order.createdAt).toLocaleTimeString([], {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </span>
                        <span>•</span>
                        <span className={`font-bold ${minutesAgo > 15 ? 'text-rose-600 animate-pulse' : ''}`}>
                          {minutesAgo === 0
                            ? isAr
                              ? 'الآن'
                              : 'Just now'
                            : `${minutesAgo} ${isAr ? 'دقيقة مضت' : 'm ago'}`}
                        </span>
                      </div>
                    </div>

                    {/* Mode Tag */}
                    <div className="text-end">
                      <span
                        className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-xl text-xs font-bold ${
                          order.diningMode === 'dine_in'
                            ? 'bg-[#B4963C]/10 text-[#B4963C] border border-[#B4963C]/30'
                            : 'bg-blue-50 text-blue-700 border border-blue-200'
                        }`}
                      >
                        {order.diningMode === 'dine_in' ? (
                          <>
                            <UtensilsCrossed className="w-3.5 h-3.5" />
                            <span>{isAr ? 'صالة' : 'Dine-In'}</span>
                          </>
                        ) : (
                          <>
                            <ShoppingBag className="w-3.5 h-3.5" />
                            <span>{isAr ? 'تيك أواي' : 'Takeaway'}</span>
                          </>
                        )}
                      </span>
                    </div>
                  </div>

                  {/* Customer / Table Info */}
                  <div className="py-2.5 px-3 bg-white/80 rounded-2xl my-3 text-xs space-y-1 border border-black/5 shadow-2xs">
                    {order.diningMode === 'dine_in' ? (
                      <div className="flex items-center gap-1.5 font-bold text-stone-900 text-sm">
                        <span className="text-[#B4963C]">{isAr ? 'طاولة رقم:' : 'Table #:'}</span>
                        <span className="font-mono text-base bg-[#B4963C] text-white px-2.5 py-0.5 rounded-lg font-bold">
                          {order.tableNumber || '-'}
                        </span>
                      </div>
                    ) : (
                      <div className="space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-stone-900">
                          <User className="w-3.5 h-3.5 text-[#B4963C]" />
                          <span>{order.customerName || (isAr ? 'عميل تيك أواي' : 'Guest')}</span>
                        </div>
                        {order.customerPhone && (
                          <div className="flex items-center gap-1.5 text-stone-600 font-mono">
                            <Phone className="w-3.5 h-3.5 text-[#B4963C]" />
                            <a href={`tel:${order.customerPhone}`} className="hover:underline">
                              {order.customerPhone}
                            </a>
                          </div>
                        )}
                      </div>
                    )}

                    {order.specialNotes && (
                      <div className="pt-1 border-t border-black/5 flex items-start gap-1 text-[11px] text-[#B4963C] font-semibold italic">
                        <FileText className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                        <span>{order.specialNotes}</span>
                      </div>
                    )}
                  </div>

                  {/* Items List */}
                  <div className="space-y-1.5 max-h-48 overflow-y-auto pe-1">
                    {order.items.map((line, idx) => (
                      <div
                        key={idx}
                        className="flex items-center justify-between text-xs py-1.5 px-2.5 rounded-xl bg-white/70 border border-black/5"
                      >
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#B4963C] bg-[#B4963C]/10 px-1.5 py-0.5 rounded text-xs">
                            {line.quantity}×
                          </span>
                          <span className="font-bold text-stone-900">
                            {line.title[language] || line.title.ar}
                          </span>
                          {line.selectedSize && (
                            <span className="text-[10px] text-stone-500 font-medium">
                              ({line.selectedSize})
                            </span>
                          )}
                        </div>
                        <span className="font-mono font-bold text-stone-800">
                          {line.totalPrice} {isAr ? 'ج.م' : 'EGP'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Card Bottom: Total & Status Action Button */}
                <div className="pt-3 border-t border-black/10 space-y-3">
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs text-stone-500 font-semibold">
                      {isAr ? 'إجمالي الفاتورة (شامل الضريبة):' : 'Grand Total:'}
                    </span>
                    <div className="text-lg font-black font-mono text-[#B4963C]">
                      {order.total} {isAr ? 'ج.م' : 'EGP'}
                    </div>
                  </div>

                  {/* Workflow Action Buttons (Inline transitions without changing open tabs) */}
                  <div className="space-y-2">
                    {isNew && (
                      <button
                        onClick={() => handleTransitionStatus(order, 'preparing')}
                        disabled={isTransitioning}
                        className="w-full py-3 px-4 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white font-bold rounded-2xl text-sm transition shadow-md shadow-rose-600/25 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                      >
                        <CookingPot className="w-4 h-4" />
                        <span>
                          {isAr ? 'استلام الطلب وتحويله للمطبخ (Receive)' : 'Receive & Send to Kitchen'}
                        </span>
                      </button>
                    )}

                    {isPrep && (
                      <button
                        onClick={() => handleTransitionStatus(order, 'completed')}
                        disabled={isTransitioning}
                        className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold rounded-2xl text-sm transition shadow-md shadow-emerald-600/25 flex items-center justify-center gap-2 cursor-pointer active:scale-95"
                      >
                        <CheckCircle className="w-4 h-4" />
                        <span>
                          {isAr
                            ? 'تم التجهيز والتسليم للعميل (Ready -> Done)'
                            : 'Mark Prepared & Deliver'}
                        </span>
                      </button>
                    )}

                    {isCompleted && (
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => handleFastPrintThermal(order, e)}
                          className="flex-1 py-2.5 px-3 bg-[#B4963C] hover:bg-[#9E8232] text-white font-bold rounded-xl text-xs transition flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                        >
                          <Printer className="w-3.5 h-3.5" />
                          <span>{isAr ? 'طباعة الفاتورة 80mm' : 'Print Receipt'}</span>
                        </button>
                      </div>
                    )}

                    {/* Secondary printer and slip triggers (Direct Fast Print & Modal Previews) */}
                    <div className="flex items-center justify-between text-[11px] pt-1 px-1">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => handleFastPrintKitchen(order, e)}
                          className="text-stone-600 hover:text-[#B4963C] font-semibold flex items-center gap-1 cursor-pointer"
                          title={isAr ? 'طباعة بون المطبخ مباشرة' : 'Direct Print Kitchen Slip'}
                        >
                          <CookingPot className="w-3 h-3 text-[#B4963C]" />
                          <span>{isAr ? 'طباعة بون' : 'Print Slip'}</span>
                        </button>
                        <span className="text-stone-300">|</span>
                        <button
                          onClick={() => onOpenKitchenDisplay(order)}
                          className="text-stone-500 hover:text-stone-800 flex items-center gap-1 cursor-pointer font-medium"
                          title={isAr ? 'معاينة بون المطبخ KDS' : 'Preview KDS Slip'}
                        >
                          <Eye className="w-3 h-3 text-stone-400" />
                          <span>{isAr ? 'معاينة' : 'Preview'}</span>
                        </button>
                      </div>

                      <div className="flex items-center gap-2">
                        <button
                          onClick={(e) => handleFastPrintThermal(order, e)}
                          className="text-stone-600 hover:text-[#B4963C] font-semibold flex items-center gap-1 cursor-pointer"
                          title={isAr ? 'طباعة الإيصال الحراري مباشرة' : 'Direct Print Thermal'}
                        >
                          <Printer className="w-3 h-3 text-[#B4963C]" />
                          <span>{isAr ? 'إيصال 80mm' : 'Thermal'}</span>
                        </button>
                        <span className="text-stone-300">|</span>
                        <button
                          onClick={() => onOpenThermalReceipt(order)}
                          className="text-stone-500 hover:text-stone-800 flex items-center gap-1 cursor-pointer font-medium"
                          title={isAr ? 'معاينة الإيصال الحراري' : 'Preview Receipt'}
                        >
                          <Eye className="w-3 h-3 text-stone-400" />
                          <span>{isAr ? 'معاينة' : 'Preview'}</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
