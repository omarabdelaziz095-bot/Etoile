export type Language = 'ar' | 'en';

export type DiningMode = 'dine_in' | 'takeaway';

export type OrderStatus = 'new' | 'preparing' | 'completed' | 'cancelled';

export interface ItemSizeVariation {
  id: string;
  name: {
    ar: string;
    en: string;
  };
  price: number;
}

export interface MenuItem {
  id: string;
  title: {
    ar: string;
    en: string;
  };
  description: {
    ar: string;
    en: string;
  };
  category: string;
  subCategory?: string;
  price: number;
  originalPrice?: number;
  image: string;
  rating: number;
  ratingCount: number;
  available: boolean;
  badge?: {
    ar: string;
    en: string;
    type?: 'discount' | 'bestseller' | 'new';
  };
  sizes?: ItemSizeVariation[];
  prepTimeMinutes?: number;
  // Stock / Inventory Management
  trackStock?: boolean;
  stockQuantity?: number;
  lowStockThreshold?: number;
  stockUnit?: string;
  lastRestockedAt?: number;
}

export type StockAdjustmentReason =
  | 'restock'
  | 'order_sale'
  | 'manual_adjustment'
  | 'damage_or_waste'
  | 'initial_count';

export interface StockAdjustmentLog {
  id: string;
  itemId: string;
  itemTitle: {
    ar: string;
    en: string;
  };
  delta: number;
  previousStock: number;
  newStock: number;
  reason: StockAdjustmentReason;
  note?: string;
  timestamp: number;
}

export interface CartItem {
  id: string; // unique cart entry key
  menuItem: MenuItem;
  quantity: number;
  selectedSize?: ItemSizeVariation;
  specialInstructions?: string;
  unitPrice: number;
}

export interface OrderLineItem {
  itemId: string;
  title: {
    ar: string;
    en: string;
  };
  quantity: number;
  unitPrice: number;
  totalPrice: number;
  selectedSize?: string;
  notes?: string;
}

export interface Order {
  id: string; // Firebase or unique key
  invoiceNumber: string; // e.g. "#1001"
  sequenceNumber: number;
  diningMode: DiningMode;
  tableNumber?: string;
  customerName?: string;
  customerPhone?: string;
  specialNotes?: string;
  items: OrderLineItem[];
  subtotal: number;
  tax: number; // 14% VAT
  total: number;
  status: OrderStatus;
  createdAt: number;
  updatedAt: number;
  paymentMethod?: string;
}

export interface CategoryInfo {
  id: string;
  name: {
    ar: string;
    en: string;
  };
  icon: string;
  color?: string;
}

export interface BranchInfo {
  id: string;
  name: {
    ar: string;
    en: string;
  };
  address: {
    ar: string;
    en: string;
  };
  phone: string;
  hours: {
    ar: string;
    en: string;
  };
}

export type StaffPermission =
  | 'orders'
  | 'kitchen'
  | 'analytics'
  | 'inventory'
  | 'stock'
  | 'ai_studio'
  | 'users';

export type StaffRole =
  | 'admin'
  | 'cashier'
  | 'kitchen'
  | 'stock_manager'
  | 'accountant'
  | 'custom';

export interface StaffUser {
  id: string;
  name: {
    ar: string;
    en: string;
  };
  pin: string;
  role: StaffRole;
  roleTitle: {
    ar: string;
    en: string;
  };
  permissions: StaffPermission[];
  avatarColor: string;
  phone?: string;
  isActive: boolean;
  createdAt: number;
  lastLoginAt?: number;
}

