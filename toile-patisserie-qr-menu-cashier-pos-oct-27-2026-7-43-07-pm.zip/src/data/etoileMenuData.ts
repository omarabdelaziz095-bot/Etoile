import { MenuItem, CategoryInfo, BranchInfo } from '../types';

export const ETOILE_CATEGORIES: CategoryInfo[] = [
  { id: 'all', name: { ar: 'الكل', en: 'All' }, icon: 'Sparkles' },
  { id: 'discounts', name: { ar: 'العروض والتوفير', en: 'Special Offers' }, icon: 'Percent', color: 'text-rose-500' },
  { id: 'oriental', name: { ar: 'حلويات شرقية', en: 'Oriental Desserts' }, icon: 'Sun' },
  { id: 'western', name: { ar: 'تورت وجاتوه', en: 'Tortes & Gateaux' }, icon: 'Cake' },
  { id: 'mix_sweet', name: { ar: 'مكس سويت وقشطوطة', en: 'Mix Sweet & Qashtoota' }, icon: 'Heart' },
  { id: 'bakery', name: { ar: 'مخبوزات وفطير مشلتت', en: 'Bakery & Feteer' }, icon: 'Wheat' },
  { id: 'savory_feteer', name: { ar: 'فطير حادق', en: 'Savory Feteer' }, icon: 'Flame' },
  { id: 'pasta_pizza', name: { ar: 'باستا وبيتزا', en: 'Pasta & Pizza' }, icon: 'Utensils' },
  { id: 'crepe_hawawshi', name: { ar: 'كريب وحواوشي', en: 'Crepes & Hawawshi' }, icon: 'Sandwich' },
  { id: 'ice_cream', name: { ar: 'آيس كريم وجيلاتو', en: 'Ice Cream' }, icon: 'IceCream' },
  { id: 'beverages', name: { ar: 'عصائر ومشروبات', en: 'Beverages' }, icon: 'Coffee' },
];

export const INITIAL_MENU_ITEMS: MenuItem[] = [
  // --- SPECIAL OFFERS & DISCOUNTS ---
  {
    id: 'disc-01',
    title: { ar: 'بوكس السعادة الشرقي مكس', en: 'Oriental Happiness Mix Box' },
    description: {
      ar: 'تشكيلة فاخرة من بسبوسة بالمكسرات، كنافة عثمانلي، أصابع جلاش، وبقلاوة بالسمن البلدي (1 كيلو)',
      en: 'Luxury mix of hazelnut basbousa, Osmanli kunafa, goulash fingers, and pure ghee baklava (1 Kg)'
    },
    category: 'discounts',
    subCategory: 'Dis Mix sweet',
    price: 260,
    originalPrice: 320,
    image: 'https://images.unsplash.com/photo-1579372786545-d24232daf58c?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 312,
    available: true,
    badge: { ar: 'خصم 20%', en: '20% OFF', type: 'discount' },
    prepTimeMinutes: 5,
  },
  {
    id: 'disc-02',
    title: { ar: 'عرض ديوتو تورتة مقاس 24 + 4 كنز', en: 'Duetto Torte Size 24 + 4 Sodas' },
    description: {
      ar: 'نصف نوتيلا وشوكولاتة بلجيكية فاخرة ونصف فواكه طازجة غنية مع 4 مشروبات غازية',
      en: 'Half premium Belgian Nutella chocolate and half fresh seasonal fruits with 4 soft drinks'
    },
    category: 'discounts',
    subCategory: 'Dis Tart',
    price: 490,
    originalPrice: 580,
    image: 'https://images.unsplash.com/photo-1535141192574-5d4897c13136?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 198,
    available: true,
    badge: { ar: 'عرض التوفير', en: 'Combo Deal', type: 'discount' },
    prepTimeMinutes: 10,
  },
  {
    id: 'disc-03',
    title: { ar: 'كومبو فطير حادق سجق + فطير كاسترد حلو', en: 'Sojouk Savory Feteer + Sweet Custard Feteer' },
    description: {
      ar: 'فطيرة حادقة سجق بلدي كيري كبيرة + فطيرة كاسترد وسكر وحليب ساخن وسط',
      en: 'Large Oriental sausage & Kiri cheese savory feteer + medium sweet custard & hot milk pie'
    },
    category: 'discounts',
    subCategory: 'Dis Bakery',
    price: 240,
    originalPrice: 295,
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 164,
    available: true,
    badge: { ar: 'عرض العائلة', en: 'Family Combo', type: 'discount' },
    prepTimeMinutes: 15,
  },

  // --- ORIENTAL DESSERTS ---
  {
    id: 'ori-01',
    title: { ar: 'بسبوسة إيتوال سادة بالسمن البلدي', en: 'Étoile Plain Basbousa' },
    description: {
      ar: 'البسبوسة الأصلية الذهبية بالسمن البلدي الفاخر وشربات السكر الخفيف الموزون بحرفية',
      en: 'Golden traditional Egyptian semolina cake baked with pure farm ghee and balanced syrup'
    },
    category: 'oriental',
    subCategory: 'Basbousa',
    price: 95,
    image: 'https://images.unsplash.com/photo-1541781774459-bb2af2f05b55?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 420,
    available: true,
    badge: { ar: 'الأكثر طلباً', en: 'Top Seller', type: 'bestseller' },
    sizes: [
      { id: 'half', name: { ar: 'نصف كيلو (علبة)', en: '1/2 Kg Box' }, price: 95 },
      { id: 'kilo', name: { ar: '1 كيلو (علبة لوكس)', en: '1 Kg Luxury Box' }, price: 180 },
    ],
    prepTimeMinutes: 5,
  },
  {
    id: 'ori-02',
    title: { ar: 'بسبوسة بالمكسرات الفاخرة (بندق ولوز)', en: 'Basbousa with Hazelnuts & Almonds' },
    description: {
      ar: 'بسبوسة غنية مغطاة بطبقة وفيرة من حبات البندق المحمص واللوز المقرمش',
      en: 'Rich moist basbousa generously topped with roasted whole hazelnuts and sliced almonds'
    },
    category: 'oriental',
    subCategory: 'Basbousa',
    price: 140,
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 388,
    available: true,
    sizes: [
      { id: 'half', name: { ar: 'نصف كيلو', en: '1/2 Kg' }, price: 140 },
      { id: 'kilo', name: { ar: '1 كيلو', en: '1 Kg' }, price: 270 },
    ],
    prepTimeMinutes: 5,
  },
  {
    id: 'ori-03',
    title: { ar: 'كنافة عثمانلي بالقشطة البلدي', en: 'Osmanli Kunafa with Rich Cream' },
    description: {
      ar: 'طبقات الكنافة المقرمشة المحمصة بالسمن الفلاحي محشوة بطبقة قشطة طازجة حريرية',
      en: 'Crispy golden kunafa layers baked in pure ghee, filled with velvety fresh dairy cream'
    },
    category: 'oriental',
    subCategory: 'Kunafa',
    price: 130,
    image: 'https://images.unsplash.com/photo-1576618148400-f54bed99fcfd?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 290,
    available: true,
    prepTimeMinutes: 5,
  },
  {
    id: 'ori-04',
    title: { ar: 'كنافة بورمة بالبندق المقرمش', en: 'Kunafa Borma with Crunchy Hazelnuts' },
    description: {
      ar: 'رولات الكنافة البورمة الذهبية المقرمشة والمحشوة بأجود حبات البندق التركي الفاخر',
      en: 'Golden rolled spiral kunafa generously packed with whole premium Turkish hazelnuts'
    },
    category: 'oriental',
    subCategory: 'Kunafa',
    price: 245,
    image: 'https://images.unsplash.com/photo-1601050690597-df0568f70950?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 175,
    available: true,
    prepTimeMinutes: 5,
  },
  {
    id: 'ori-05',
    title: { ar: 'كنافة بالمانجو الطبيعية والقشطة', en: 'Fresh Mango Cream Kunafa' },
    description: {
      ar: 'الكنافة الصيفية الشهيرة بطبقات الكريمة المخفوقة وقطع المانجو الفريش الطبيعية والشربات',
      en: 'Signature kunafa bowl layered with whipped chantilly cream and chunks of sweet fresh mango'
    },
    category: 'oriental',
    subCategory: 'Kunafa',
    price: 165,
    image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&w=800&q=80',
    rating: 5.0,
    ratingCount: 512,
    available: true,
    badge: { ar: 'الأكثر مبيعاً', en: 'Best Seller', type: 'bestseller' },
    prepTimeMinutes: 8,
  },
  {
    id: 'ori-06',
    title: { ar: 'مشكل جلاش وبقلاوة مكسرات', en: 'Assorted Goulash & Baklava with Nuts' },
    description: {
      ar: 'أصابع جلاش مقرمشة، وربات بالقشطة، ومثلثات بقلاوة بالفستق والبندق بالسمن الطبيعي',
      en: 'Crispy phyllo goulash fingers, cream warbat, and baklava triangles with pistachios and hazelnuts'
    },
    category: 'oriental',
    subCategory: 'Goulash',
    price: 195,
    image: 'https://images.unsplash.com/photo-1519869325930-281384150729?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    ratingCount: 140,
    available: true,
    prepTimeMinutes: 5,
  },

  // --- WESTERN CAKES & TORTES ---
  {
    id: 'wes-01',
    title: { ar: 'تورتة فور سيزونز مقاس 24', en: 'Four Seasons Torte Size 24' },
    description: {
      ar: '4 أرباع مميزة: ربع نوتيلا، ربع لوتس مقرمش، ربع فواكه طبيعية، وربع كيندر بوينو',
      en: '4 signature quarters: Nutella chocolate, crunchy Lotus Biscoff, fresh fruit, and Kinder Bueno'
    },
    category: 'western',
    subCategory: 'Torte Size 24',
    price: 480,
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 630,
    available: true,
    badge: { ar: 'المفضلة للمناسبات', en: 'Party Favorite', type: 'bestseller' },
    sizes: [
      { id: 's18', name: { ar: 'مقاس 18 (تكفي 6-8)', en: 'Size 18 (6-8 pax)' }, price: 340 },
      { id: 's24', name: { ar: 'مقاس 24 (تكفي 10-12)', en: 'Size 24 (10-12 pax)' }, price: 480 },
      { id: 's28', name: { ar: 'مقاس 28 (تكفي 16-18)', en: 'Size 28 (16-18 pax)' }, price: 620 },
    ],
    prepTimeMinutes: 10,
  },
  {
    id: 'wes-02',
    title: { ar: 'تورتة مكس نوتيلا وكيندر مقاس 18', en: 'Kinder & Nutella Torte Size 18' },
    description: {
      ar: 'كيك الشوكولاتة الفادج البلجيكي الغني بكريمة النوتيلا وحبات شوكولاتة كيندر وبندق',
      en: 'Rich Belgian fudge chocolate sponge layered with Nutella mousse and topped with Kinder chocolates'
    },
    category: 'western',
    subCategory: 'Torte Size 18',
    price: 330,
    image: 'https://images.unsplash.com/photo-1588195538326-c5b1e9f80a1b?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 245,
    available: true,
    prepTimeMinutes: 10,
  },
  {
    id: 'wes-03',
    title: { ar: 'تورتة ريد فيلفيت الإيطالية', en: 'Classic Italian Red Velvet Torte' },
    description: {
      ar: 'طبقات الكيك المخملي الأحمر الرائع محشوة بكريمة الجبن التشيزكيك الغنية وتوت العليق',
      en: 'Silky red velvet sponge layered with tangy cream cheese frosting and raspberry coulis'
    },
    category: 'western',
    subCategory: 'Torte Size 24',
    price: 420,
    image: 'https://images.unsplash.com/photo-1586788680434-30d324b2d46f?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 180,
    available: true,
    prepTimeMinutes: 10,
  },
  {
    id: 'wes-04',
    title: { ar: 'قطعة جاتوه ميلفي كراميل فاخر', en: 'Caramel Mille-feuille Gateau' },
    description: {
      ar: 'رقائق الميلفي المقرمشة الهشة المخبوزة بعناية محشوة بكريمة الباتيسيير وصوص الكراميل',
      en: 'Crisp flaky puff pastry layered with silky vanilla diplomat cream and salted caramel'
    },
    category: 'western',
    subCategory: 'Gateau',
    price: 38,
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 310,
    available: true,
    prepTimeMinutes: 3,
  },
  {
    id: 'wes-05',
    title: { ar: 'قطعة جاتوه فيريرو روشيه', en: 'Ferrero Rocher Gateau' },
    description: {
      ar: 'موس شوكولاتة البندق مع جناش الروشيه المقرمش بالبندق المكرمل وشوكولاتة الحليب',
      en: 'Hazelnut chocolate mousse encased in crunchy rocher praline glaze and roasted nuts'
    },
    category: 'western',
    subCategory: 'Gateau',
    price: 40,
    image: 'https://images.unsplash.com/photo-1579372786545-d24232daf58c?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 450,
    available: true,
    prepTimeMinutes: 3,
  },
  {
    id: 'wes-06',
    title: { ar: 'علبة جاتوه سواريه مشكل (24 قطعة)', en: 'Gateau Soiree Mini Box (24 Pcs)' },
    description: {
      ar: 'تشكيلة ميني سواريه راقية: تارت فواكه، شوكولاتة، كراميل، ريد فيلفيت، وإكلير',
      en: 'Sophisticated bite-sized petit fours: fruit tarts, chocolate ganache, red velvet, and eclairs'
    },
    category: 'western',
    subCategory: 'Gateau Soiree',
    price: 240,
    image: 'https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 340,
    available: true,
    badge: { ar: 'مثالية للضيافة', en: 'Party Choice', type: 'bestseller' },
    prepTimeMinutes: 8,
  },

  // --- MIX SWEET & MODERN TREND (قشطوطة وديلولو وطواجن) ---
  {
    id: 'mix-01',
    title: { ar: 'قشطوطة لوتس (تريس ليتشيز)', en: 'Lotus Tres Leches (Qashtoota)' },
    description: {
      ar: 'كيكة الحليب الثلاثي المشبعة المغمورة بالحليب والقشطة والمغطاة بزبدة وبسكويت اللوتس الأصلي',
      en: 'Tender milk-soaked sponge smothered in fresh cream and premium Belgian Lotus Biscoff spread'
    },
    category: 'mix_sweet',
    subCategory: 'Tres Leches',
    price: 75,
    image: 'https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&w=800&q=80',
    rating: 5.0,
    ratingCount: 820,
    available: true,
    badge: { ar: 'تريند إيتوال', en: 'Viral Hit', type: 'bestseller' },
    prepTimeMinutes: 5,
  },
  {
    id: 'mix-02',
    title: { ar: 'قشطوطة مانجو قطع طبيعية', en: 'Fresh Mango Qashtoota' },
    description: {
      ar: 'كيكة التريس ليتشيز مسقية حليب مكثف مغطاة بكريمة غنية ومكعبات المانجو السكرية الطازجة',
      en: 'Luscious milk-soaked sponge topped with fresh clotted cream and sweet Egyptian mango chunks'
    },
    category: 'mix_sweet',
    subCategory: 'Tres Leches',
    price: 85,
    image: 'https://images.unsplash.com/photo-1551024709-8f23befc6f87?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 610,
    available: true,
    prepTimeMinutes: 5,
  },
  {
    id: 'mix-03',
    title: { ar: 'ديلولو شوكولاتة وكيندر', en: 'Dilolo Kinder Chocolate Cup' },
    description: {
      ar: 'ابتكار إيتوال الخاص: طبقات كيك فادج مع شوكولاتة كيندر سايحة وصوص نوتيلا وبسكويت مقرمش',
      en: 'Étoile exclusive creation: warm fudge layers, melted Kinder chocolate sauce, and crisp pearls'
    },
    category: 'mix_sweet',
    subCategory: 'Dilolo',
    price: 80,
    image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 290,
    available: true,
    badge: { ar: 'جديد إيتوال', en: 'New', type: 'new' },
    prepTimeMinutes: 6,
  },
  {
    id: 'mix-04',
    title: { ar: 'طاجن السعادة نوتيلا وأوريو ساخن', en: 'Hot Nutella & Oreo Happiness Tajine' },
    description: {
      ar: 'طاجن فخار ساخن مخبوز بالكيك الغني وصوص النوتيلا المذاب مع بسكويت أوريو وبندق محمص',
      en: 'Warm clay pot baked chocolate fudge smothered with melted Nutella, Oreo crumbs, and hazelnuts'
    },
    category: 'mix_sweet',
    subCategory: 'Tajine',
    price: 90,
    image: 'https://images.unsplash.com/photo-1606313564200-e75d5e30476c?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 410,
    available: true,
    prepTimeMinutes: 8,
  },
  {
    id: 'mix-05',
    title: { ar: 'خلية النحل بالجبنة الكيري والعسل', en: 'El Khalyia Cream Cheese Honey Bun' },
    description: {
      ar: 'كرات العجين القطنية الذهبية الهشة المحشوة بجبنة كيري الكريمية والمسقية بعسل النحل الصافي',
      en: 'Fluffy golden pull-apart brioche buns filled with velvety Kiri cream cheese and drizzled with pure honey'
    },
    category: 'mix_sweet',
    subCategory: 'EL Khalyia',
    price: 95,
    image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    ratingCount: 195,
    available: true,
    prepTimeMinutes: 10,
  },

  // --- BAKERY & FETEER MESHALTET ---
  {
    id: 'bak-01',
    title: { ar: 'فطير مشلتت بلدي بالسمن الفلاحي', en: 'Baladi Feteer Meshaltet (Pure Ghee)' },
    description: {
      ar: 'الفطير المشلتت المصري الأصيل المورق بأكثر من 40 طبقة رقيقة ومخبوز بالسمن الفلاحي 100%',
      en: 'Authentic Egyptian flaky layered pastry baked to golden perfection with 100% natural farm butter'
    },
    category: 'bakery',
    subCategory: 'Feteer',
    price: 135,
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 520,
    available: true,
    badge: { ar: 'سمن بلدي 100%', en: 'Pure Ghee', type: 'bestseller' },
    sizes: [
      { id: 'med', name: { ar: 'وسط (مع عسل وقشطة)', en: 'Medium (Honey & Cream)' }, price: 135 },
      { id: 'lrg', name: { ar: 'كبير جامبو (عسل، جبنة قديمة، وقشطة)', en: 'Jumbo Large (Full Sides)' }, price: 195 },
    ],
    prepTimeMinutes: 15,
  },
  {
    id: 'bak-02',
    title: { ar: 'كرواسون زبدة فرنسي بالجبنة الرومي', en: 'French Butter Croissant with Roumy Cheese' },
    description: {
      ar: 'كرواسون مورق ومقرمش بالزبدة الطبيعية محشو بجبن الرومي المصري المعتق اللذيذ',
      en: 'Flaky golden French butter croissant generously filled with sharp aged Egyptian Roumy cheese'
    },
    category: 'bakery',
    subCategory: 'Pieces',
    price: 36,
    image: 'https://images.unsplash.com/photo-1555507036-ab1f4038808a?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 220,
    available: true,
    prepTimeMinutes: 3,
  },
  {
    id: 'bak-03',
    title: { ar: 'علبة ساليزون وباتون ساليه مشكل', en: 'Assorted Salézon & Batons Salés Box' },
    description: {
      ar: 'مخبوزات سواريه حادقة بالجبن، البسطرمة، التونة، والزيتون مع أصابع الكمون والسمسم (1/2 كيلو)',
      en: 'Mini cocktail savory pastries with pastrami, smoked meats, tuna and cumin cheese sticks (500g)'
    },
    category: 'bakery',
    subCategory: 'Soiree',
    price: 160,
    image: 'https://images.unsplash.com/photo-1589367920969-ab8e050bbb04?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 170,
    available: true,
    prepTimeMinutes: 5,
  },

  // --- SAVORY FETEER (RESTAURANT) ---
  {
    id: 'sav-01',
    title: { ar: 'فطير حادق سجق بلدي إسكندراني كيري', en: 'Alexandrian Sojouk & Kiri Savory Feteer' },
    description: {
      ar: 'فطيرة مورقة محشوة بالسجق البلدي المتبل، جبنة كيري غنية، موتزاريلا، فلفل، وزيتون',
      en: 'Flaky pie stuffed with spiced Alexandrian sausage, creamy Kiri cheese, mozzarella, and olives'
    },
    category: 'savory_feteer',
    subCategory: 'Savory Feteer',
    price: 165,
    image: 'https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 470,
    available: true,
    badge: { ar: 'الأكثر طلباً بالفرع', en: 'Top Dine-In', type: 'bestseller' },
    sizes: [
      { id: 'med', name: { ar: 'وسط', en: 'Medium' }, price: 165 },
      { id: 'lrg', name: { ar: 'كبير', en: 'Large' }, price: 215 },
    ],
    prepTimeMinutes: 18,
  },
  {
    id: 'sav-02',
    title: { ar: 'فطير حادق كواترو فورماجي (مكس أجبان)', en: 'Quattro Formaggi Cheese Feteer' },
    description: {
      ar: 'موتزاريلا طبيعية، شيدر أحمر، جبنة كيري، وجبنة رومي قديمة مع رشة سمسم وحبة البركة',
      en: 'Four rich cheeses blend: mozzarella, sharp aged cheddar, Kiri cream cheese, and old Roumy'
    },
    category: 'savory_feteer',
    subCategory: 'Savory Feteer',
    price: 155,
    image: 'https://images.unsplash.com/photo-1593560708920-61dd98c46a4e?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 310,
    available: true,
    sizes: [
      { id: 'med', name: { ar: 'وسط', en: 'Medium' }, price: 155 },
      { id: 'lrg', name: { ar: 'كبير', en: 'Large' }, price: 200 },
    ],
    prepTimeMinutes: 16,
  },
  {
    id: 'sav-03',
    title: { ar: 'فطير حادق دجاج باربكيو رانش', en: 'BBQ Chicken & Ranch Savory Feteer' },
    description: {
      ar: 'قطع صدور دجاج متبلة، صوص الباربكيو المدخن، صوص الرانش الغني، فلفل ألوان، وجبنة موتزاريلا',
      en: 'Tender seasoned chicken breast, smoky BBQ swirl, creamy ranch drizzle, sweet peppers, and cheese'
    },
    category: 'savory_feteer',
    subCategory: 'Savory Feteer',
    price: 175,
    image: 'https://images.unsplash.com/photo-1574071318508-1cdbab80d002?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 230,
    available: true,
    prepTimeMinutes: 18,
  },

  // --- PASTA & PIZZA ---
  {
    id: 'pas-01',
    title: { ar: 'طاجن مكرونة نجرسكو دجاج إيتوال', en: 'Signature Chicken Negresco Pasta' },
    description: {
      ar: 'مكرونة فيتوتشيني مع قطع الدجاج المشوي، مشروم طازج، صوص البشاميل الكريمي وجبنة موتزاريلا ذائبة',
      en: 'Fettuccine pasta tossed with grilled chicken, fresh mushrooms, velvety béchamel, and gratinated mozzarella'
    },
    category: 'pasta_pizza',
    subCategory: 'Pasta',
    price: 135,
    image: 'https://images.unsplash.com/photo-1621996346565-e3d5d628178d?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 395,
    available: true,
    badge: { ar: 'طلب ساخن', en: 'Hot Special', type: 'bestseller' },
    prepTimeMinutes: 15,
  },
  {
    id: 'pas-02',
    title: { ar: 'بيتزا إيتوال بيبروني إيطالي', en: 'Italian Beef Pepperoni Pizza' },
    description: {
      ar: 'عجينة بيتزا هشة مخبوزة على الحجر مع صوص الطماطم الإيطالي، شرائح بيبروني بقري، وموتزاريلا',
      en: 'Stone-baked thin crust pizza topped with Italian marinara sauce, beef pepperoni, and shredded mozzarella'
    },
    category: 'pasta_pizza',
    subCategory: 'Pizza',
    price: 145,
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    ratingCount: 260,
    available: true,
    sizes: [
      { id: 'med', name: { ar: 'وسط 28 سم', en: 'Medium 28cm' }, price: 145 },
      { id: 'lrg', name: { ar: 'كبير 34 سم', en: 'Large 34cm' }, price: 185 },
    ],
    prepTimeMinutes: 15,
  },
  {
    id: 'pas-03',
    title: { ar: 'باستا بيني أرابياتا حارة', en: 'Penne all\'Arrabbiata' },
    description: {
      ar: 'مكرونة بيني إيطالية مع صوص الطماطم الحار وزيت الزيتون البكر والثوم والريحان الطازج',
      en: 'Al dente penne pasta in spicy garlic-infused Italian tomato sauce, chili flakes, and fresh basil'
    },
    category: 'pasta_pizza',
    subCategory: 'Pasta',
    price: 95,
    image: 'https://images.unsplash.com/photo-1551183053-bf91a1d81141?auto=format&fit=crop&w=800&q=80',
    rating: 4.6,
    ratingCount: 140,
    available: true,
    prepTimeMinutes: 12,
  },

  // --- CREPES & HAWAWSHI ---
  {
    id: 'crp-01',
    title: { ar: 'حواوشي إيتوال الإيطالي بالموتزاريلا', en: 'Etoile Italian Mozzarella Hawawshi' },
    description: {
      ar: 'لحم بلدي متبل بخلطة بهارات إيتوال السرية داخل خبز بلدي مقرمش مغطى بوش جبنة موتزاريلا وفلفل وزيتون',
      en: 'Spiced Egyptian minced beef in crispy bread topped with a rich layer of melted mozzarella and peppers'
    },
    category: 'crepe_hawawshi',
    subCategory: 'Italian Hawawshi',
    price: 85,
    image: 'https://images.unsplash.com/photo-1528735602780-2552fd46c7af?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 540,
    available: true,
    badge: { ar: 'سوبر ستار إيتوال', en: 'Étoile Star', type: 'bestseller' },
    prepTimeMinutes: 12,
  },
  {
    id: 'crp-02',
    title: { ar: 'كريب كرسبي دجاج سوبريم', en: 'Crispy Chicken Supreme Crepe' },
    description: {
      ar: 'كريب مقرمش محشو بقطع الدجاج الكرسبي الذهبي، بطاطس مقلية، جبن شيدر وموتزاريلا، وصوص الرانش والمايونيز',
      en: 'Crispy golden crepe stuffed with crunchy chicken tenders, fries, cheddar, mozzarella, and special ranch'
    },
    category: 'crepe_hawawshi',
    subCategory: 'Crepe',
    price: 95,
    image: 'https://images.unsplash.com/photo-1519676867240-f03562e64548?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 380,
    available: true,
    prepTimeMinutes: 12,
  },
  {
    id: 'crp-03',
    title: { ar: 'حواوشي إيتوال بلدي كلاسيك سمنة بلدي', en: 'Classic Egyptian Ghee Hawawshi' },
    description: {
      ar: 'رغيف الحواوشي البلدي التقليدي المقمر بالسمنة الفلاحي والبهارات الشرقية الأصيلة',
      en: 'Crisp rustic pita loaf stuffed with herb-infused minced beef brushed with fragrant Egyptian ghee'
    },
    category: 'crepe_hawawshi',
    subCategory: 'Etoile Hawawshi',
    price: 65,
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    ratingCount: 310,
    available: true,
    prepTimeMinutes: 10,
  },

  // --- ICE CREAM & GELATO ---
  {
    id: 'ice-01',
    title: { ar: 'تورتة آيس كريم لوتس وكراميل', en: 'Lotus Caramel Ice Cream Torte' },
    description: {
      ar: 'طبقات من جيلاتو الفانيليا الإيطالي وجيلاتو الكراميل وبسكويت اللوتس المطحون صوص وفير',
      en: 'Layers of Italian vanilla gelato and rich salted caramel ice cream on a crunchy Lotus crust'
    },
    category: 'ice_cream',
    subCategory: 'Ice Cream Torte',
    price: 360,
    image: 'https://images.unsplash.com/photo-1563805042-7684c019e1cb?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 220,
    available: true,
    badge: { ar: 'انتعاش الصيف', en: 'Summer Chill', type: 'bestseller' },
    prepTimeMinutes: 5,
  },
  {
    id: 'ice-02',
    title: { ar: 'كاس جيلاتو فواكه طبيعية مشكل', en: 'Artisan Gelato Sundae Cup' },
    description: {
      ar: 'ثلاث بولات جيلاتو طبيعي (مانجو إسماعيلية، فراولة بلدي، وشوكولاتة بلجيكية) مع كريمة وصوص',
      en: '3 scoops of natural gelato (Ismailia mango, local strawberry, Belgian dark chocolate) with toppings'
    },
    category: 'ice_cream',
    subCategory: 'Ice Cream Torte',
    price: 65,
    image: 'https://images.unsplash.com/photo-1497034825429-c343d7c6a68f?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 190,
    available: true,
    prepTimeMinutes: 4,
  },

  // --- BEVERAGES ---
  {
    id: 'bev-01',
    title: { ar: 'عصير مانجو طبيعي فريش 100%', en: '100% Fresh Natural Mango Juice' },
    description: {
      ar: 'عصير مانجو مانجاوي مركز وطبيعي بدون إضافات مصنع من أجود محاصيل الإسماعيلية',
      en: 'Thick, chilled 100% natural Egyptian mango nectar made fresh daily'
    },
    category: 'beverages',
    subCategory: 'Beverages',
    price: 45,
    image: 'https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 460,
    available: true,
    prepTimeMinutes: 3,
  },
  {
    id: 'bev-02',
    title: { ar: 'ميلك شيك لوتس كراميل مثلج', en: 'Lotus Biscoff Thick Milkshake' },
    description: {
      ar: 'ميلك شيك سميك ومثلج مخلوط بجيلاتو الفانيليا وبسكويت وزبدة اللوتس مع طبقة كريمة مخفوقة',
      en: 'Thick creamy milkshake blended with vanilla ice cream, rich Lotus spread, and topped with whip'
    },
    category: 'beverages',
    subCategory: 'Beverages',
    price: 65,
    image: 'https://images.unsplash.com/photo-1572490122747-3968b75cc699?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 310,
    available: true,
    prepTimeMinutes: 4,
  },
  {
    id: 'bev-03',
    title: { ar: 'قهوة تركي بن إيتوال محوج بالحبهان', en: 'Étoile Turkish Cardamom Coffee' },
    description: {
      ar: 'فنجان قهوة تركية بوش كريمي كثيف من حبوب البن الفاخرة المحوجة بالهيل والقرنفل',
      en: 'Traditional Turkish coffee with velvety crema brewed with aromatic cardamom and cloves'
    },
    category: 'beverages',
    subCategory: 'Beverages',
    price: 32,
    image: 'https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    ratingCount: 290,
    available: true,
    prepTimeMinutes: 5,
  },
  {
    id: 'bev-04',
    title: { ar: 'ليمون نعناع فريش مثلج', en: 'Iced Fresh Lemon Mint' },
    description: {
      ar: 'عصير الليمون المنعش مع أوراق النعناع الطازجة والثلج المجروش لقمة الانتعاش',
      en: 'Crushed iced refresher crafted with fresh Mediterranean lemons and garden mint'
    },
    category: 'beverages',
    subCategory: 'Beverages',
    price: 38,
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    ratingCount: 180,
    available: true,
    prepTimeMinutes: 3,
  },
];

export const ETOILE_BRANCHES: BranchInfo[] = [
  {
    id: 'b-01',
    name: { ar: 'فرع مدينة نصر - مكرم عبيد', en: 'Nasr City - Makram Ebeid' },
    address: { ar: 'شارع مكرم عبيد الرئيسي أمام سيتي سنتر، مدينة نصر، القاهرة', en: 'Main Makram Ebeid St, opposite City Centre, Nasr City, Cairo' },
    phone: '16312',
    hours: { ar: 'يومياً: 8:00 ص - 2:00 ص', en: 'Daily: 8:00 AM - 2:00 AM' },
  },
  {
    id: 'b-02',
    name: { ar: 'فرع مصر الجديدة - الميرغني', en: 'Heliopolis - El Merghany' },
    address: { ar: 'شارع الميرغني عمارات السبع عمارات، مصر الجديدة، القاهرة', en: 'El Merghany St, 7 Buildings, Heliopolis, Cairo' },
    phone: '16312',
    hours: { ar: 'يومياً: 8:00 ص - 2:00 ص', en: 'Daily: 8:00 AM - 2:00 AM' },
  },
  {
    id: 'b-03',
    name: { ar: 'فرع التجمع الخامس - مول مكسيم', en: 'New Cairo - Maxim Mall' },
    address: { ar: 'التجمع الخامس، أمام الجامعة الأمريكية، القاهرة الجديدة', en: '5th Settlement, opposite AUC, New Cairo' },
    phone: '16312',
    hours: { ar: 'يومياً: 9:00 ص - 1:00 ص', en: 'Daily: 9:00 AM - 1:00 AM' },
  },
  {
    id: 'b-04',
    name: { ar: 'فرع الدقي والمهندسين', en: 'Dokki & Mohandessin' },
    address: { ar: 'شارع التحرير، ميدان الدقي، الجيزة', en: 'Tahrir Street, Dokki Square, Giza' },
    phone: '16312',
    hours: { ar: 'يومياً: 8:30 ص - 2:30 ص', en: 'Daily: 8:30 AM - 2:30 AM' },
  },
  {
    id: 'b-05',
    name: { ar: 'فرع وسط البلد - شارع 26 يوليو', en: 'Downtown Cairo - 26th July St' },
    address: { ar: 'شارع 26 يوليو أمام دار القضاء العالي، وسط البلد، القاهرة', en: '26th of July St, opp. High Court, Downtown Cairo' },
    phone: '16312',
    hours: { ar: 'يومياً: 8:00 ص - 2:00 ص', en: 'Daily: 8:00 AM - 2:00 AM' },
  },
  {
    id: 'b-06',
    name: { ar: 'فرع الإسكندرية - سموحة', en: 'Alexandria - Smouha' },
    address: { ar: 'ميدان فيكتور عمانويل، سموحة، الإسكندرية', en: 'Victor Emmanuel Sq, Smouha, Alexandria' },
    phone: '16312',
    hours: { ar: 'يومياً: 9:00 ص - 1:30 ص', en: 'Daily: 9:00 AM - 1:30 AM' },
  },
];

export const ETOILE_BRAND = {
  name: { ar: 'حلواني إيتوال', en: 'Étoile Patisserie & Bakery' },
  slogan: { ar: 'صناع السعادة منذ 1999', en: 'Makers of Happiness Since 1999' },
  hotline: '16312',
  whatsapp: '201016312000',
  social: {
    facebook: 'https://facebook.com/etoileeg',
    instagram: 'https://instagram.com/etoile.eg',
    tiktok: 'https://tiktok.com/@etoile.eg',
    website: 'https://etoileeg.online',
  },
  vatRate: 0.14, // 14% Egypt VAT
};
