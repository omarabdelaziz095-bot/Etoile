import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));

// Initialize Google GenAI
const apiKey = process.env.GEMINI_API_KEY;
const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;

// Multi-turn Gemini Chat endpoint for Étoile AI Concierge
app.post('/api/chat', async (req, res) => {
  try {
    const { messages, language = 'ar' } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required' });
    }

    if (!ai) {
      // Graceful fallback if GEMINI_API_KEY is not set yet
      return res.json({
        reply: language === 'ar'
          ? "أهلاً بك في حلواني إيتوال! نوصيك بتجربة بسبوسة إيتوال المخصوصة، قشطوطة اللوتس، وتورتة الفورسيزونز الشهيرة. هل ترغب في اقتراح لعدد معين من الأشخاص؟"
          : "Welcome to Étoile Patisserie! We highly recommend our Special Basbousa, Lotus Qashtoota, and the signature Four Seasons Torte. How many people are you ordering for?"
      });
    }

    const systemInstruction = `You are "Chef Étoile" (الشيف إيتوال الذكي), the master pastry sommelier and concierge for "حلواني إيتوال" (Étoile Patisserie & Bakery Egypt).
Brand motto: "صناع السعادة منذ 1999" (Makers of Happiness since 1999).
Hotline: 16312.
You have expert knowledge of Étoile's specialties:
1. Oriental Sweets: Basbousa (plain, hazelnut, cream), Kunafa (Osmanli, Borma with nuts, Mango Kunafa), Goulash, Baklava.
2. Western Cakes: Tortes (Kinder, Four Seasons, Duetto Nutella & Fruits, Red Velvet), Gateaux (Mille-feuille caramel, Rocher, Soirée boxes).
3. Mix Sweet / Modern: Qashtoota / Tres Leches (Lotus, Pistachio, Mango, Nutella), Dilolo, Tajines (Nutella, Oreo, Pistachio), El Khalyia.
4. Savory & Restaurant: Savory Feteer (Sojouk Kiri, Mix Cheese, Chicken BBQ), Italian Hawawshi, Negresco Pasta, Pizza, Crepes.
5. Feteer Meshaltet with honey & qeshta.

Guidelines:
- Match the user's language (Arabic or English). If Arabic, speak in warm, welcoming, polite Egyptian Arabic mixed with standard Arabic.
- Be enthusiastic, helpful, and concise (2-4 sentences max per recommendation unless asked for details).
- Help customers select ideal treats for their occasions (birthdays, family gatherings, Ramadan, Eid, office celebrations).
- If they ask for prices or sizes, provide realistic Egyptian Pound (EGP) estimates based on Étoile's menu.
- Recommend popular beverage pairings (Turkish coffee with Oriental sweets, Iced Karak or Milkshake with Western gateau).`;

    // Format conversation history for Gemini
    const contents = messages.map((m: { role: string; content: string }) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.content }]
    }));

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents,
      config: {
        systemInstruction,
        temperature: 0.7,
      }
    });

    const reply = response.text || '';
    return res.json({ reply });
  } catch (error: any) {
    console.error('Gemini Chat error:', error);
    return res.status(500).json({
      error: 'Failed to generate response',
      details: error.message
    });
  }
});

// Image Generation / Editing endpoint using gemini-nano-banana-2.1
app.post('/api/generate-image', async (req, res) => {
  try {
    const { prompt, language = 'ar' } = req.body;
    if (!prompt) {
      return res.status(400).json({ error: 'Prompt is required' });
    }

    if (!ai) {
      return res.status(500).json({
        error: 'Gemini API Key is not configured in environment'
      });
    }

    const enhancedPrompt = `Professional high-end patisserie food photography for Étoile Egypt: ${prompt}, exquisite presentation, bakery showcase lighting, luxury pastry aesthetics, photorealistic, 4k.`;

    const response = await ai.models.generateContent({
      model: 'gemini-nano-banana-2.1',
      contents: enhancedPrompt,
    });

    // Check for inline image data in parts
    const candidates = response.candidates || [];
    let imageBase64 = null;
    let mimeType = 'image/png';

    for (const candidate of candidates) {
      for (const part of candidate.content?.parts || []) {
        if (part.inlineData) {
          imageBase64 = part.inlineData.data;
          mimeType = part.inlineData.mimeType || 'image/png';
          break;
        }
      }
    }

    if (imageBase64) {
      return res.json({
        imageUrl: `data:${mimeType};base64,${imageBase64}`
      });
    }

    return res.json({
      description: response.text || 'Image created based on your design request.'
    });
  } catch (error: any) {
    console.error('Image Generation error:', error);
    return res.status(500).json({
      error: 'Image generation failed',
      details: error.message
    });
  }
});

// In-memory persistent orders store and Server-Sent Events (SSE) broadcaster
const serverOrders: any[] = [];
const sseClients = new Set<express.Response>();

function broadcastOrderEvent(eventData: any) {
  const payload = `data: ${JSON.stringify(eventData)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(payload);
    } catch {
      sseClients.delete(client);
    }
  }
}

// 1. Real-time Server-Sent Events (SSE) Stream for Instant Cross-Device Detection
app.get('/api/orders/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache, no-transform');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders?.();

  // Send current orders upon initial connection
  res.write(`data: ${JSON.stringify({ type: 'initial', orders: serverOrders })}\n\n`);

  sseClients.add(res);

  // Keep-alive heartbeat ping every 15 seconds
  const heartbeat = setInterval(() => {
    try {
      res.write(': keepalive\n\n');
    } catch {
      clearInterval(heartbeat);
      sseClients.delete(res);
    }
  }, 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    sseClients.delete(res);
  });
});

// 2. Fetch all orders
app.get('/api/orders', (req, res) => {
  res.json({ orders: serverOrders });
});

// 3. Create or update an order
app.post('/api/orders', (req, res) => {
  const order = req.body;
  if (!order || !order.id) {
    return res.status(400).json({ error: 'Valid order is required' });
  }

  const existingIdx = serverOrders.findIndex((o) => o.id === order.id);
  if (existingIdx !== -1) {
    serverOrders[existingIdx] = { ...serverOrders[existingIdx], ...order, updatedAt: Date.now() };
  } else {
    serverOrders.unshift(order);
  }

  // Broadcast instantly to all connected cashier POS panels without any page reload
  broadcastOrderEvent({ type: 'new_order', order, orders: serverOrders });
  return res.json({ success: true, order });
});

// 4. Update order status
app.patch('/api/orders/:id', (req, res) => {
  const { id } = req.params;
  const updates = req.body;

  const idx = serverOrders.findIndex((o) => o.id === id);
  if (idx !== -1) {
    serverOrders[idx] = { ...serverOrders[idx], ...updates, updatedAt: Date.now() };
    broadcastOrderEvent({ type: 'order_updated', order: serverOrders[idx], orders: serverOrders });
    return res.json({ success: true, order: serverOrders[idx] });
  }

  return res.status(404).json({ error: 'Order not found' });
});

// Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    brand: 'Étoile Patisserie & Bakery',
    connectedClients: sseClients.size,
    ordersCount: serverOrders.length,
    time: new Date().toISOString(),
  });
});

// Accessible direct URL for Cashier POS
app.get(['/pos', '/pos/', '/cashier', '/admin'], (req, res) => {
  res.redirect('/?view=cashier#pos');
});

// Setup Vite middleware in dev or static serving in production
async function startServer() {
  if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  } else {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: process.env.DISABLE_HMR !== 'true' },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  server.on('error', (err) => {
    console.error('Express server listen error:', err);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
